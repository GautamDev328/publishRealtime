﻿using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.HIRINGOPENINGDETAILSCORE
{
         // [Authorize]
          public class InterviewApplicationFormCoreController : Controller
          {
                    List<Department> lstdepartment = new List<Department>();
                    List<DesignationModel> lstdesignationmodel = new List<DesignationModel>();
                    List<HigherQualificationModel> lsthighqualificaiton = new List<HigherQualificationModel>();
                    List<HRQUESTIONMODEL> lsthrquestion = new List<HRQUESTIONMODEL>();
                    public OpenPositonAppliedModelcs objopenpositon=new OpenPositonAppliedModelcs();

                    private string localUrl = "https://localhost:44384";
                  //  public string localUrl = "http://localhost:5007";

                    public IActionResult InterviewApplicationFormView(int page = 1)
                    {  //LOCAL VARIABLE 
                              List<InterviewApplicationFormModel> listOpen = new List<InterviewApplicationFormModel>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/InterviewApplicationFomAPI/Alllistinterviewapplication").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listOpen = JsonConvert.DeserializeObject<List<InterviewApplicationFormModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listOpen.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listOpen.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList); 
                    }




                    //CREATE FUNCTIONALITY CODE
                    [HttpGet]
                    public async Task<IActionResult> AddInterviewApplicationForm(int id)
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Fetch all required data
                                                  HttpResponseMessage departmentResponse = await client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment");
                                                  HttpResponseMessage designationResponse = await client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation");
                                                  HttpResponseMessage qualificationResponse = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                                                  HttpResponseMessage hrQuestionResponse = await client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION");
                                                  HttpResponseMessage positionDetailsResponse = await client.GetAsync("https://localhost:44384/api/OpenPositonAppliedAPI/DetailsOpenPosition?id={id}");

                                                  if (departmentResponse.IsSuccessStatusCode &&
                                                      designationResponse.IsSuccessStatusCode &&
                                                      qualificationResponse.IsSuccessStatusCode &&
                                                      hrQuestionResponse.IsSuccessStatusCode &&
                                                      positionDetailsResponse.IsSuccessStatusCode)
                                                  {
                                                            // Deserialize all responses
                                                            var departments = JsonConvert.DeserializeObject<List<Department>>(await departmentResponse.Content.ReadAsStringAsync());
                                                            var designations = JsonConvert.DeserializeObject<List<DesignationModel>>(await designationResponse.Content.ReadAsStringAsync());
                                                            var qualifications = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(await qualificationResponse.Content.ReadAsStringAsync());
                                                            var hrQuestions = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(await hrQuestionResponse.Content.ReadAsStringAsync());
                                                            var positionDetails = JsonConvert.DeserializeObject<OpenPositonAppliedModelcs>(await positionDetailsResponse.Content.ReadAsStringAsync());

                                                            // Pass data to ViewBag
                                                            ViewBag.Customlstdepartment = new SelectList(departments, "Dep_Name", "Dep_Name");
                                                            ViewBag.Customlstdesignation = new SelectList(designations, "DesigName", "DesigName");
                                                            ViewBag.CustomHighQualification = new SelectList(qualifications, "HigherQualificaiton", "HigherQualificaiton");
                                                            ViewBag.Customlsthrquestion = new SelectList(hrQuestions, "HrQuestionKey", "HrQuestionKey");

                                                            // Pass First Name from position details
                                                            ViewBag.FirstName = positionDetails.FirstName;
                                                            ViewBag.MiddleName=positionDetails.MiddleName;
                                                            ViewBag.LastName = positionDetails.LastName;
                                                            ViewBag.EmailAddress=positionDetails.EmailAddress;
                                                            ViewBag.Address=positionDetails.Address;          
                                                            ViewBag.DateOfBirth=positionDetails.DateOfBirth;
                                                            ViewBag.Gender=positionDetails.Gender;
                                                            ViewBag.MobileNumber=positionDetails.MobileNumber;
                                                            ViewBag.TotalExperience=positionDetails.TotalExperience;
                                                            ViewBag.RelevantExperience=positionDetails.RelevantExperience;
                                                            ViewBag.HighEducation=positionDetails.HIGHEREDUCATION;
                                                            ViewBag.HighPercentage=positionDetails.HIgherPercentage;
                                                            ViewBag.CurrentCtc=positionDetails.CurrentCTC;
                                                            ViewBag.ExpectedCtc = positionDetails.ExpectedCTC;
                                                            ViewBag.technicalskill=positionDetails.Skill;
                                                            ViewBag.Reasonchangethecompany=positionDetails.Reasonchangethecompany;
                                                            ViewBag.pancardnumber=positionDetails.PANCARDNUMBER;
                                                            ViewBag.photo=positionDetails.image;
                                                            ViewBag.Resume=positionDetails.Resume_CV;
                                                            ViewBag.positionfeedback=positionDetails.PositionFeedback;
                                                            
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = "Error fetching data from APIs.";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              return View();
                    }
                    //[HttpGet]
                    //public IActionResult AddInterviewApplicationForm(int id)//int id
                    //{
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                    //                              HttpResponseMessage httpResponse = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                    //                              HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                    //                              HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;
                    //                              //HttpResponseMessage response = client.GetAsync($"api/OpenPositonAppliedAPI/DetailsOpenPosition?id={id}").Result;

                    //                              //&& httpResponse.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode
                    //                              if (responseMessage.IsSuccessStatusCode && httpResponse.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                    //                                        lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data);//lstdesignationmodel
                    //                                        string data1 = httpResponse.Content.ReadAsStringAsync().Result;
                    //                                        lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(data1);
                    //                                        string data2 = responseMessage1.Content.ReadAsStringAsync().Result;
                    //                                        lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data2);
                    //                                        string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                    //                                        lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);
                    //                              }
                    //                              ///{ httpResponse.ReasonPhrase}/{ responseMessage1.ReasonPhrase}
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}{httpResponse.ReasonPhrase}/{responseMessage1.ReasonPhrase}/{responseMessage2.ReasonPhrase}";
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //          }

                    //          ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                    //          ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                    //          ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                    //                                                                                                                                ////                                                                                                                      //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));
                    //          ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assuming CustomerExtraUser is the property to display

                    //          return View();
                    //}

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddInterviewApplicationForm(InterviewApplicationFormModel model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/InterviewApplicationFomAPI/CreateInterviewApplication", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "InterviewApplicationForm saved successfully!";
                                                                      return RedirectToAction("InterviewApplicationFormView");
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server-side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }

                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage httpResponse1 = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                                                  HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;

                                                  //&& httpResponse1.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode
                                                  if (responseMessage.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode)
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data);
                                                            string data1 = await httpResponse1.Content.ReadAsStringAsync();
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(data1);
                                                            string data2 = await responseMessage1.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data2);
                                                            string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assuming CustomerExtraUser is the property to display

                              return View(model);
                    }

                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    //public async Task<IActionResult> AddInterviewApplicationForm(InterviewApplicationFormModel model)
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri(localUrl);
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                                        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/InterviewApplicationFomAPI/CreateInterviewApplication", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  TempData["AlertMessage"] = "InterviewApplicationForm saved successfully!";

                    //                                                  // Clear the form by reloading the view with a fresh model
                    //                                                  return RedirectToAction(nameof(AddInterviewApplicationForm));
                    //                                        }
                    //                                        else
                    //                                        {
                    //                                                  ModelState.AddModelError(string.Empty, "Server-side error: " + response.ReasonPhrase);
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                    //                    }
                    //          }

                    //          // Reload the ViewBag data when returning the view to show the form again
                    //       //   await ReloadDropdownData();

                    //          return View(model);
                    //}

                    //// Helper method to reload dropdown data
                    //private async Task ReloadDropdownData(int id)
                    //{
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage positionDetailsResponse = await client.GetAsync($"https://localhost:44384/api/OpenPositonAppliedAPI/DetailsOpenPosition?id={id}");


                    //                              if (positionDetailsResponse.IsSuccessStatusCode )

                    //                              {
                    //                                        var positionDetails = JsonConvert.DeserializeObject<OpenPositonAppliedModelcs>(await positionDetailsResponse.Content.ReadAsStringAsync());

                    //                                        //// Pass data to ViewBag
                    //                                        //ViewBag.Customlstdepartment = new SelectList(departments, "Dep_Name", "Dep_Name");
                    //                                        //ViewBag.Customlstdesignation = new SelectList(designations, "DesigName", "DesigName");
                    //                                        //ViewBag.CustomHighQualification = new SelectList(qualifications, "HigherQualificaiton", "HigherQualificaiton");
                    //                                        //ViewBag.Customlsthrquestion = new SelectList(hrQuestions, "HrQuestionKey", "HrQuestionKey");

                    //                                        // Pass First Name from position details
                    //                                        ViewBag.FirstName = positionDetails.FirstName;
                    //                                        ViewBag.MiddleName = positionDetails.MiddleName;
                    //                                        ViewBag.LastName = positionDetails.LastName;
                    //                                        ViewBag.EmailAddress = positionDetails.EmailAddress;
                    //                                        ViewBag.Address = positionDetails.Address;
                    //                                        ViewBag.DateOfBirth = positionDetails.DateOfBirth;
                    //                                        ViewBag.Gender = positionDetails.Gender;
                    //                                        ViewBag.MobileNumber = positionDetails.MobileNumber;
                    //                                        ViewBag.TotalExperience = positionDetails.TotalExperience;
                    //                                        ViewBag.RelevantExperience = positionDetails.RelevantExperience;
                    //                                        ViewBag.HighEducation = positionDetails.HIGHEREDUCATION;
                    //                                        ViewBag.HighPercentage = positionDetails.HIgherPercentage;
                    //                                        ViewBag.CurrentCtc = positionDetails.CurrentCTC;
                    //                                        ViewBag.ExpectedCtc = positionDetails.ExpectedCTC;
                    //                                        ViewBag.technicalskill = positionDetails.Skill;
                    //                                        ViewBag.Reasonchangethecompany = positionDetails.Reasonchangethecompany;
                    //                                        ViewBag.pancardnumber = positionDetails.PANCARDNUMBER;
                    //                                        ViewBag.photo = positionDetails.image;
                    //                                        ViewBag.Resume = positionDetails.Resume_CV;
                    //                                        ViewBag.positionfeedback = positionDetails.PositionFeedback;
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = "Error fetching dropdown data.";
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //          }
                    //}



                    //UPDATE

                    [HttpGet] 
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid InterviewApplicationForm id");
                              }

                              try
                              {
                                        InterviewApplicationFormModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/InterviewApplicationFomAPI/DetailsInterviewApplcation?id={id}");
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage httpResponse1 = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;

                                                  if (response.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<InterviewApplicationFormModel>(result);
                                                           var result1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            lstdepartment = JsonConvert.DeserializeObject<List<Department>>(result1);
                                                            var result2 = await httpResponse1.Content.ReadAsStringAsync();
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(result2);

                                                            var result3 = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(result3);
                                                            string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage.IsSuccessStatusCode}/{responseMessage1.IsSuccessStatusCode}/{httpResponse1.IsSuccessStatusCode}/{responseMessage2.IsSuccessStatusCode}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("InterviewApplicationForm not found");
                                        }

                                        ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(InterviewApplicationFormModel models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync("https://localhost:44384/api/InterviewApplicationFomAPI/UpdateIntervieweApplication", content);

                                                            if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {





                                                                      TempData["AlertMessage"] = "InterviewApplicationForm Data Update Successfully ";

                                                                      return RedirectToAction("InterviewApplicationFormView"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage httpResponse1 = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;

                                                  if (responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode)
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                                                            var result1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            lstdepartment = JsonConvert.DeserializeObject<List<Department>>(result1);
                                                            var result2 = await httpResponse1.Content.ReadAsStringAsync();
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(result2);
                                                            string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);

                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assuming CustomerExtraUser is the property to display

                              //   return View(model);
                              return View(models);
                    }

                    //DetailsData

                    [HttpGet]
                    public async Task<IActionResult> DetailsData(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid InterviewApplicationForm id");
                              }

                              try
                              {
                                        InterviewApplicationFormModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/InterviewApplicationFomAPI/DetailsInterviewApplcation?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<InterviewApplicationFormModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("InterviewApplicationForm not found");
                                        }

                                        InterviewApplicationFormModel viewModel = new InterviewApplicationFormModel()
                                        {
                                            
                                                  interviewApplicationId = model.interviewApplicationId,
                                                  FirstName = model.FirstName,
                                                  MiddleName = model.MiddleName,
                                                  LastName = model.LastName,
                                                  EmailAddress = model.EmailAddress,
                                                  Address = model.Address,
                                                  DateOfBirth = model.DateOfBirth,
                                                  Gender = model.Gender,
                                                  MobileNumber = model.MobileNumber,
                                                  InterviewerName =model.InterviewerName,
                                                  InterviewSchedue=model.InterviewSchedue,
                                                  PositionApplied_DesignationName=model.PositionApplied_DesignationName,
                                                  Department=model.Department,

                                                  TotalExperience = model.TotalExperience,
                                                  RelevantExperience = model.RelevantExperience,
                                                  Skill = model.Skill,
                                                  Matricthpercentage=model.Matricthpercentage,
                                                  Interpercentag=model.Interpercentag,
                                                  GraduationPercentage=model.GraduationPercentage,
                                                  POSTGRADUATEPercentage=model.POSTGRADUATEPercentage,
                                                  HIGHEREDUCATION = model.HIGHEREDUCATION,
                                                  HighPercentage = model.HighPercentage,
                                                  CurrentCTC = model.CurrentCTC,
                                                  ExpectedCTC = model.ExpectedCTC,
                                                  Monthly_CTC =model.Monthly_CTC,
                                                  Monthly_Ectc = model.Monthly_Ectc,

                                                  NegotiationCTC = model.NegotiationCTC,
                                                  HrQUestion=model.HrQUestion,
                                                  HrquestonFeedback=model.HrquestonFeedback,
                                                  HrQuestionAccept_Reject = model.HrQuestionAccept_Reject,
                                                 // HrQuestionReject=model.HrQuestionReject,
                                                  Reject_AcceptReasonDate=model.Reject_AcceptReasonDate,

                                                 Reasonchangethecompany = model.Reasonchangethecompany,
                                                  EPFO_UANNUMBER = model.EPFO_UANNUMBER,
                                                  ESIC_IPNumber=model.ESIC_IPNumber,
                                                  AadharNumber=model.AadharNumber,
                                                  PancardNumber= model.PancardNumber,
                                                  photo=model.photo,
                                                  Resume = model.Resume,
                                                  PositionFeedback = model.PositionFeedback,




                                        };
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid InterviewApplicationForm id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/InterviewApplicationFomAPI/DeleteInterviewApplication?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "InterviewApplicationFormView Delete Successfully ";

                                                            return RedirectToAction("InterviewApplicationFormView");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("InterviewApplicationFormView");
                    }
                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/InterviewApplicationFomAPI/export-InterviewApplicationForm-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "interviewApplicationFormModels.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting interviewApplicationForm: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("InterviewApplicationFormView");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("InterviewApplicationFormView");
                              }
                    }


                    // Demo check 

          }

}

