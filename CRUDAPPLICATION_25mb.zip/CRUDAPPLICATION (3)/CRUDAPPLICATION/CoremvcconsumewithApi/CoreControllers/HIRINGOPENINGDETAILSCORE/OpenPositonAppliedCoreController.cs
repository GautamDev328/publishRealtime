﻿using CRUDAPPLICATION.APIControllers;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Math;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.HIRINGOPENINGDETAILSCORE
{
          //[Authorize]
          public class OpenPositonAppliedCoreController : Controller
          {
                    List<HigherQualificationModel> lsthighqualificaiton = new List<HigherQualificationModel>();
                    private string localUrl = "https://localhost:44384";

                  //  public string localUrl = "http://localhost:5007";


                    public IActionResult OpenPositonAppliedVIEW(int page = 1)
                    {
                              //LOCAL VARIABLE 
                              List<OpenPositonAppliedModelcs> listOpen = new List<OpenPositonAppliedModelcs>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/OpenPositonAppliedAPI/ALLDATAOpenPosition").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listOpen = JsonConvert.DeserializeObject<List<OpenPositonAppliedModelcs>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listOpen.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listOpen.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }


                    // CREATE FUNCTIONALITY CODE 
                    [HttpGet]
                    public IActionResult AddOpening()
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;

                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                                                                                                                                                    //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

                              return View();
                    }




                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddOpening(OpenPositonAppliedModelcs model)
                    {
                              if (ModelState.IsValid)
                              {

                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/OpenPositonAppliedAPI/CreateOpenPosition", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {


                                                                      TempData["AlertMessage"] = "ApplicationFormApplied  Data   Successfully ";
                                                                      return RedirectToAction("OpenPositonAppliedVIEW"); // U TempData["AlertMessage"] = "ApplicationFormApplied  Data   Successfully ";

                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                              return View(model);
                    }


                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    //public async Task<IActionResult> AddOpening(OpenPositonAppliedModelcs model, IFormFile Resume_CV)
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              // Handle file upload (Resume_CV)
                    //                              if (Resume_CV != null)
                    //                              {
                    //                                        var filePath = Path.Combine("wwwroot/resumes", Resume_CV.FileName);
                    //                                        using (var stream = new FileStream(filePath, FileMode.Create))
                    //                                        {
                    //                                                  await Resume_CV.CopyToAsync(stream);
                    //                                        }
                    //                                        model.Resume_CV = $"/resumes/{Resume_CV.FileName}"; // Assuming ResumePath is a property in your model
                    //                              }

                    //                              // HTTP POST to API
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri(localUrl);
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                                        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/OpenPositonAppliedAPI/CreateOpenPosition", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  TempData["AlertMessage"] = "Application Form Applied Successfully";
                    //                                                  return RedirectToAction("OpenPositonAppliedVIEW");
                    //                                        }
                    //                                        else
                    //                                        {
                    //                                                  ModelState.AddModelError(string.Empty, $"Server side error: {response.ReasonPhrase}");
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, $"Exception: {ex.Message}");
                    //                    }
                    //          }

                    //          // Reload ViewBag data when returning to the view
                    //          List<HigherQualificationModel> lsthighqualification = new List<HigherQualificationModel>();
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                    //                              if (responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = await responseMessage.Content.ReadAsStringAsync();
                    //                                        lsthighqualification = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = $"Error loading qualifications: {ex.Message}";
                    //          }

                    //          ViewBag.CustomHighQualification = new SelectList(lsthighqualification, "HigherQualificaiton", "HigherQualificaiton");

                    //          return View(model);
                    //}

                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    //public async Task<IActionResult> AddOpening(OpenPositonAppliedModelcs model,IFormFile Resume_CV)//, 
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              // Handle file upload (Resume_CV)
                    //                              if (Resume_CV != null)//Resume_CV
                    //                              {
                    //                                        // Define file path
                    //                                        var filePath = Path.Combine("wwwroot/resumes", Resume_CV.FileName); //

                    //                                        // Delete the existing file if it exists
                    //                                        if (!string.IsNullOrEmpty(model.Resume_CV) && System.IO.File.Exists(Path.Combine("wwwroot", model.Resume_CV.TrimStart('/'))))
                    //                                        {
                    //                                                  System.IO.File.Delete(Path.Combine("wwwroot", model.Resume_CV.TrimStart('/')));
                    //                                        }

                    //                                        // Save the new file
                    //                                        using (var stream = new FileStream(filePath, FileMode.Create))
                    //                                        {
                    //                                                  await Resume_CV.CopyToAsync(stream);
                    //                                        }

                    //                                        // Update model's ResumePath property
                    //                                        model.Resume_CV = $"/resumes/{Resume_CV.FileName}";
                    //                              }

                    //                              // HTTP POST to API
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri(localUrl);
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        // Serialize model to JSON
                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                                        // Send POST request
                    //                                        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/OpenPositonAppliedAPI/CreateOpenPosition", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  TempData["AlertMessage"] = "Application Form Applied Successfully";
                    //                                                  return RedirectToAction("OpenPositonAppliedVIEW");
                    //                                        }
                    //                                        else
                    //                                        {
                    //                                                  ModelState.AddModelError(string.Empty, $"Server side error: {response.ReasonPhrase}");
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, $"Exception: {ex.Message}");
                    //                    }
                    //          }


                    // Reload ViewBag data when returning to the view
                    //          List<HigherQualificationModel> lsthighqualification = new List<HigherQualificationModel>();
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              // Fetch qualifications from API
                    //                              HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                    //                              if (responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = await responseMessage.Content.ReadAsStringAsync();
                    //                                        lsthighqualification = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = $"Error loading qualifications: {ex.Message}";
                    //          }

                    //          // Populate ViewBag for dropdown
                    //          ViewBag.CustomHighQualification = new SelectList(lsthighqualification, "HigherQualificaiton", "HigherQualificaiton");

                    //          return View(model);
                    //}

                    //[HttpGet]
                    //public IActionResult AddOpening()
                    //{
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;

                    //                              if (responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                    //                                        lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //          }

                    //          ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton");

                    //          return View();
                    //}

                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    //public async Task<IActionResult> AddOpening(OpenPositonAppliedModelcs model, IFormFile Resume_CV)
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              // Handle file upload (Resume_CV)
                    //                              if (Resume_CV != null)
                    //                              {
                    //                                        // Define file path
                    //                                        var filePath = Path.Combine("wwwroot/resumes", Resume_CV.FileName);

                    //                                        // Delete the existing file if it exists
                    //                                        if (!string.IsNullOrEmpty(model.Resume_CV) && System.IO.File.Exists(Path.Combine("wwwroot", model.Resume_CV.TrimStart('/'))))
                    //                                        {
                    //                                                  System.IO.File.Delete(Path.Combine("wwwroot", model.Resume_CV.TrimStart('/')));
                    //                                        }

                    //                                        // Save the new file
                    //                                        using (var stream = new FileStream(filePath, FileMode.Create))
                    //                                        {
                    //                                                  await Resume_CV.CopyToAsync(stream);
                    //                                        }

                    //                                        // Update model's ResumePath property
                    //                                        model.Resume_CV = $"~/resumes/{Resume_CV.FileName}";
                    //                              }

                    //                              // HTTP POST to API
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri(localUrl);
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        // Serialize model to JSON
                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                                        // Send POST request
                    //                                        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/OpenPositonAppliedAPI/CreateOpenPosition", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  TempData["AlertMessage"] = "Application Form Applied Successfully";
                    //                                                  return RedirectToAction("OpenPositonAppliedVIEW");
                    //                                        }
                    //                                        else
                    //                                        {
                    //                                                  ModelState.AddModelError(string.Empty, $"Server side error: {response.ReasonPhrase}");
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, $"Exception: {ex.Message}");
                    //                    }
                    //          }

                    //          // Reload ViewBag data when returning to the view
                    //          List<HigherQualificationModel> lsthighqualification = new List<HigherQualificationModel>();
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              // Fetch qualifications from API
                    //                              HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                    //                              if (responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = await responseMessage.Content.ReadAsStringAsync();
                    //                                        lsthighqualification = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = $"Error loading qualifications: {ex.Message}";
                    //          }

                    //          // Populate ViewBag for dropdown
                    //          ViewBag.CustomHighQualification = new SelectList(lsthighqualification, "HigherQualificaiton", "HigherQualificaiton");

                    //          return View(model);
                    //}


                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid OpenPositonApplied id");
                              }

                              try
                              {
                                        OpenPositonAppliedModelcs objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/OpenPositonAppliedAPI/DetailsOpenPosition?id={id}");
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;

                                                  if (response.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<OpenPositonAppliedModelcs>(result);
                                                            var result1 = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(result1);

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/ {responseMessage.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("OpenPositonApplied not found");
                                        }

                                        ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }
                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(OpenPositonAppliedModelcs models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("api/OpenPositonAppliedAPI/UpdateOpenPosition", content);

                                                            if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {





                                                                      TempData["AlertMessage"] = "ApplicationFormApplied Data Update Successfully ";

                                                                      return RedirectToAction("OpenPositonAppliedVIEW"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                              //   return View(model);
                              return View(models);
                    }

                    //[HttpGet]
                    //public async Task<IActionResult> Edit(int id)
                    //{
                    //          if (id == 0)
                    //          {
                    //                    return BadRequest("Invalid OpenPositonApplied id");
                    //          }

                    //          try
                    //          {
                    //                    OpenPositonAppliedModelcs objPublisher = null;
                    //                    List<HigherQualificationModel> lstHighQualification = new List<HigherQualificationModel>();

                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri("https://localhost:44384/");
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              // Fetch details of the opening
                    //                              HttpResponseMessage response = await client.GetAsync($"api/OpenPositonAppliedAPI/DetailsOpenPosition?id={id}");
                    //                              // Fetch qualifications
                    //                              HttpResponseMessage qualificationResponse = await client.GetAsync("api/HighQualificationAPI/AllHighestQualification");

                    //                              if (response.IsSuccessStatusCode && qualificationResponse.IsSuccessStatusCode)
                    //                              {
                    //                                        // Deserialize details
                    //                                        string result = await response.Content.ReadAsStringAsync();
                    //                                        objPublisher = JsonConvert.DeserializeObject<OpenPositonAppliedModelcs>(result);

                    //                                        // Deserialize qualifications
                    //                                        string qualificationResult = await qualificationResponse.Content.ReadAsStringAsync();
                    //                                        lstHighQualification = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(qualificationResult);
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"{response.ReasonPhrase} / {qualificationResponse.ReasonPhrase}";
                    //                                        return View("Error");
                    //                              }
                    //                    }

                    //                    if (objPublisher == null)
                    //                    {
                    //                              return NotFound("OpenPositonApplied not found");
                    //                    }

                    //                    // Populate ViewBag for dropdown
                    //                    ViewBag.CustomHighQualification = new SelectList(lstHighQualification, "HigherQualificaiton", "HigherQualificaiton");

                    //                    return View(objPublisher);
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //                    return View("Error");
                    //          }
                    //}

                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    //public async Task<IActionResult> Edit(OpenPositonAppliedModelcs model, IFormFile Resume_CV)
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              // Handle file upload
                    //                              if (Resume_CV != null)
                    //                              {
                    //                                        string filePath = Path.Combine("wwwroot/resumes", Resume_CV.FileName);

                    //                                        // Delete existing file if needed
                    //                                        if (!string.IsNullOrEmpty(model.Resume_CV) && System.IO.File.Exists(Path.Combine("wwwroot", model.Resume_CV.TrimStart('/'))))
                    //                                        {
                    //                                                  System.IO.File.Delete(Path.Combine("wwwroot", model.Resume_CV.TrimStart('/')));
                    //                                        }

                    //                                        // Save the new resume
                    //                                        using (var stream = new FileStream(filePath, FileMode.Create))
                    //                                        {
                    //                                                  await Resume_CV.CopyToAsync(stream);
                    //                                        }

                    //                                        // Update the resume path
                    //                                        model.Resume_CV = $"/resumes/{Resume_CV.FileName}";
                    //                              }

                    //                              // Send the updated data to API
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri("https://localhost:44384/");
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                                        HttpResponseMessage response = await httpClient.PostAsync("api/OpenPositonAppliedAPI/UpdateOpenPosition", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  TempData["AlertMessage"] = "Application Form Data Updated Successfully";
                    //                                                  return RedirectToAction("OpenPositonAppliedVIEW");
                    //                                        }
                    //                                        else
                    //                                        {
                    //                                                  ModelState.AddModelError(string.Empty, $"Server side error: {response.ReasonPhrase}");
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, $"Exception: {ex.Message}");
                    //                    }
                    //          }

                    //          // Reload qualifications when returning to the view
                    //          List<HigherQualificationModel> lstHighQualification = new List<HigherQualificationModel>();
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri("https://localhost:44384/");
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage responseMessage = await client.GetAsync("api/HighQualificationAPI/AllHighestQualification");
                    //                              if (responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = await responseMessage.Content.ReadAsStringAsync();
                    //                                        lstHighQualification = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //          }

                    //          // Populate ViewBag for dropdown
                    //          ViewBag.CustomHighQualification = new SelectList(lstHighQualification, "HigherQualificaiton", "HigherQualificaiton");

                    //          return View(model);
                    //}



                    //DetailsData

                    [HttpGet]
                    public async Task<IActionResult> DetailsData(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid OpenPositonApplied id");
                              }

                              try
                              {
                                        OpenPositonAppliedModelcs model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/OpenPositonAppliedAPI/DetailsOpenPosition?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<OpenPositonAppliedModelcs>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("OpenPositonApplied not found");
                                        }

                                        OpenPositonAppliedModelcs viewModel = new OpenPositonAppliedModelcs()
                                        {
                                                  OpenpositionId = model.OpenpositionId,
                                                  FirstName = model.FirstName,
                                                  MiddleName = model.MiddleName,
                                                  LastName = model.LastName,
                                                  EmailAddress = model.EmailAddress,
                                                  Address = model.Address,
                                                  DateOfBirth = model.DateOfBirth,
                                                  Gender = model.Gender,
                                                  MobileNumber = model.MobileNumber,
                                                  TotalExperience = model.TotalExperience,
                                                  RelevantExperience=model.RelevantExperience,
                                                  HIGHEREDUCATION=model.HIGHEREDUCATION,
                                                  HIgherPercentage=model.HIgherPercentage,
                                                  CurrentCTC=model.CurrentCTC,
                                                  ExpectedCTC=model.ExpectedCTC,
                                                  Skill=model.Skill,
                                                  Reasonchangethecompany=model.Reasonchangethecompany,
                                                  PANCARDNUMBER=model.PANCARDNUMBER,
                                                  image=model.image,
                                                  Resume_CV= model.Resume_CV,
                                                  PositionFeedback= model.PositionFeedback          


                                        };
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid OpenPositonApplied id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/OpenPositonAppliedAPI/DeleteOpenPosition?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "OpenPositonApplied Delete Successfully ";

                                                            return RedirectToAction("OpenPositonAppliedVIEW");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("OpenPositonAppliedVIEW");
                    }
                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/OpenPositonAppliedAPI/export-OpenPosition-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "OpenPositonAppliedModelcs.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting OpenPositonApplied: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("OpenPositonAppliedVIEW");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("OpenPositonAppliedVIEW");
                              }
                    }
                    




          }

}
