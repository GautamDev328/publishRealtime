﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.HIRINGOPENINGDETAILSCORE
{
         // [Authorize]

          public class ReScheduleInterviewDateCoreController : Controller
          {
                    //public IActionResult Index()
                    //{
                    //          return View();
                    //}
                    private string localUrl = "https://localhost:44384";
                 //   public string localUrl = "http://localhost:5007";

                    List<HigherQualificationModel> lsthighqualificaiton = new List<HigherQualificationModel>();
                    List<DesignationModel> lstdesignationmodel = new List<DesignationModel>();
                     InterviewApplicationFormModel objinterviewapplication = new InterviewApplicationFormModel();
                    public IActionResult RescheduleView(int page = 1)
                    {
                              List<RescheduleDateInterviewOPENINGMODEL> listOpen = new List<RescheduleDateInterviewOPENINGMODEL>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/RescheduleDateInterviewOPENINGAPI/Alllistrescheudedate").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listOpen = JsonConvert.DeserializeObject<List<RescheduleDateInterviewOPENINGMODEL>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listOpen.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listOpen.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList); ;
                    }

                    [HttpGet]
                    public async Task<IActionResult> AddRescheduleDate(int id )//int id
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage httpResponse = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                                                  HttpResponseMessage response = await client.GetAsync($"api/InterviewApplicationFomAPI/DetailsInterviewApplcation?id={id}");

                                                  if (responseMessage1.IsSuccessStatusCode && httpResponse.IsSuccessStatusCode  && response.IsSuccessStatusCode)
                                                  {
                                                           
                                                            string data1 = httpResponse.Content.ReadAsStringAsync().Result;
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(data1);
                                                            string data2 = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data2);
                                                            var objinterviewapplicationdetaisl = JsonConvert.DeserializeObject<InterviewApplicationFormModel>(await response.Content.ReadAsStringAsync());

                                                            // Pass First Name from position details
                                                            ViewBag.FirstName = objinterviewapplicationdetaisl.FirstName;
                                                            ViewBag.MiddleName = objinterviewapplicationdetaisl.MiddleName;
                                                            ViewBag.LastName = objinterviewapplicationdetaisl.LastName;
                                                          //  ViewBag.EmailAddress = positionDetails.EmailAddress;
                                                            ViewBag.Address = objinterviewapplicationdetaisl.Address;
                                                          //  ViewBag.DateOfBirth = positionDetails.DateOfBirth;
                                                          //  ViewBag.Gender = positionDetails.Gender;
                                                            ViewBag.MobileNumber = objinterviewapplicationdetaisl.MobileNumber;
                                                            ViewBag.InterviewName = objinterviewapplicationdetaisl.InterviewerName;
                                                            ViewBag.InterviewerSchedule = objinterviewapplicationdetaisl.InterviewSchedue;
                                                            ViewBag.DesignationName = objinterviewapplicationdetaisl.PositionApplied_DesignationName;
                                                            ViewBag.TotalExperience = objinterviewapplicationdetaisl.TotalExperience;
                                                         //   ViewBag.RelevantExperience = positionDetails.RelevantExperience;
                                                            ViewBag.HighEducation = objinterviewapplicationdetaisl.HIGHEREDUCATION;
                                                            //ViewBag.HighPercentage = positionDetails.HIgherPercentage;
                                                            //ViewBag.CurrentCtc = positionDetails.CurrentCTC;
                                                            //ViewBag.ExpectedCtc = positionDetails.ExpectedCTC;
                                                            //ViewBag.technicalskill = positionDetails.Skill;
                                                            ViewBag.Reasonchangethecompany = objinterviewapplicationdetaisl.Reasonchangethecompany;
                                                           // ViewBag.InterviewReason=objinterviewapplicationdetaisl.inter
                                                            //ViewBag.pancardnumber = positionDetails.PANCARDNUMBER;
                                                            //ViewBag.photo = positionDetails.image;
                                                            //ViewBag.Resume = positionDetails.Resume_CV;
                                                            ViewBag.positionfeedback = objinterviewapplicationdetaisl.PositionFeedback;

                                                  }


                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage1.ReasonPhrase}/{httpResponse.ReasonPhrase}/{response.IsSuccessStatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                           
                              ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                                                                                                                                                    ////                                                                                                                      //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

                              return View();
                    }

                    //  testing 
                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddRescheduleDate(RescheduleDateInterviewOPENINGMODEL model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/RescheduleDateInterviewOPENINGAPI/Createrescheudedate", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "RescheduleDateInterviewOPENING saved successfully!";
                                                                      return RedirectToAction("RescheduleView");
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server-side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }



                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  //HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                                                 HttpResponseMessage httpResponse1 = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                                                  //   HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;

                                                  //&& httpResponse1.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode
                                                  //  responseMessage.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode
                                                  if ( responseMessage1.IsSuccessStatusCode  && httpResponse1.IsSuccessStatusCode)
                                                  {
                                                            //string data = await responseMessage.Content.ReadAsStringAsync();
                                                            //lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data);
                                                            string data1 = await httpResponse1.Content.ReadAsStringAsync();
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(data1);
                                                            string data2 = await responseMessage1.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data2);
                                                            //string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            //lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              //ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                            //  ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assuming CustomerExtraUser is the property to display

                              return View(model);
                    }
                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid ReScheduleInterviewDate id");
                              }

                              try
                              {
                                        RescheduleDateInterviewOPENINGMODEL objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/RescheduleDateInterviewOPENINGAPI/Detailsrescheudedate?id={id}");
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                                                  //HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage httpResponse1 = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  //HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;
                                                  if (response.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<RescheduleDateInterviewOPENINGMODEL>(result);
                                                            //var result1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            //lstdepartment = JsonConvert.DeserializeObject<List<Department>>(result1);
                                                            var result2 = await httpResponse1.Content.ReadAsStringAsync();
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(result2);

                                                            var result3 = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(result3);
                                                            //string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            //lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage.ReasonPhrase}/{httpResponse1.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("RescheduleDateInterviewOPENING NOT FOUND ");
                                        }

                                        //ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                                      //  ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assumin
                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(RescheduleDateInterviewOPENINGMODEL models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync("https://localhost:44384/api/RescheduleDateInterviewOPENINGAPI/UpdateRescheduleDate", content);
                                                            //     HttpResponseMessage responseMessage = httpClient.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                            if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {





                                                                      TempData["AlertMessage"] = "RescheduleDateInterviewOPENING Data Update Successfully ";

                                                                      return RedirectToAction("RescheduleView"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                                                  //HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage httpResponse1 = client.GetAsync("https://localhost:44384/api/Designation/ALLDATADesignation").Result;
                                                  //HttpResponseMessage responseMessage2 = client.GetAsync("https://localhost:44384/api/HRQUESTIONAPI/GetHRQUESTION").Result;
                                                  // && responseMessage1.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode

                                                  if (responseMessage.IsSuccessStatusCode && httpResponse1.IsSuccessStatusCode)
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                                                            //var result1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            //lstdepartment = JsonConvert.DeserializeObject<List<Department>>(result1);
                                                            var result2 = await httpResponse1.Content.ReadAsStringAsync();
                                                            lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(result2);
                                                            //string data3 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            //lsthrquestion = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(data3);

                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                              //ViewBag.Customlstdepartment = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Customlstdesignation = new SelectList(lstdesignationmodel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
                              //ViewBag.Customlsthrquestion = new SelectList(lsthrquestion, "HrQuestionKey", "HrQuestionKey"); // Assuming CustomerExtraUser is the property to display

                              //   return View(model);
                              return View(models);
                    }
          

                    //DetailsData

                    [HttpGet]
                    public async Task<IActionResult> Details(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid RescheduleDateInterviewOPENING id");
                              }

                              try
                              {
                                        RescheduleDateInterviewOPENINGMODEL model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/RescheduleDateInterviewOPENINGAPI/Detailsrescheudedate?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<RescheduleDateInterviewOPENINGMODEL>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("RescheduleDateInterviewOPENING not found");
                                        }

                                        RescheduleDateInterviewOPENINGMODEL viewModel = new RescheduleDateInterviewOPENINGMODEL()
                                        {
                                                  RescheduleId = model.RescheduleId,
                                                  FirstName = model.FirstName,
                                                  MiddleName = model.MiddleName,
                                                  LastName = model.LastName,
                                                  Address = model.Address,
                                                  MobileNumber = model.MobileNumber,
                                                  InterviewerName = model.InterviewerName,
                                                  InterviewSchedue = model.InterviewSchedue,
                                                  PositionApplied_DesignationName = model.PositionApplied_DesignationName,

                                                  TotalExperience = model.TotalExperience,
                                                  
                                                  HIGHEREDUCATION = model.HIGHEREDUCATION,
                                                  ReasonRescheduechangedatetime=model.ReasonRescheduechangedatetime,
                                                  interviewReasoncancelled=model.interviewReasoncancelled,
                                                  FEEBACK= model.FEEBACK




                                        };
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }
                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid RescheduleDateInterviewOPENING id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/RescheduleDateInterviewOPENINGAPI/DeleteRescheduleDate?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "RescheduleDateInterviewOPENING Delete Successfully ";

                                                            return RedirectToAction("RescheduleView");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("RescheduleView");
                    }
                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/RescheduleDateInterviewOPENINGAPI/export-rescheudledate-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "RescheduleDateInterviewOPENING.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting RescheduleDateInterviewOPENING FROM : {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("RescheduleView");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("RescheduleView");
                              }
                    }
          }
}
