﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.HIRINGOPENINGDETAILSCORE
{
          //[Authorize]

          public class TechnicalInterviewerDetailsCoreController : Controller
          {
                    private string localUrl = "https://localhost:44384";
                  //  public string localUrl = "http://localhost:5007";

                    List<HigherQualificationModel> lsthighqualificaiton = new List<HigherQualificationModel>();
                    RescheduleDateInterviewOPENINGMODEL objrescheduledta=new RescheduleDateInterviewOPENINGMODEL();
                    public IActionResult TechnicalInterviewerAppliedView(int page = 1)
                    
                              {  //LOCAL VARIABLE 
                                        List<Interviewer_applieddetail_Models> listOpen = new List<Interviewer_applieddetail_Models>();
                                        try
                                        {
                                                  using (HttpClient client = new HttpClient())
                                                  {
                                                            client.BaseAddress = new Uri(localUrl);
                                                            client.DefaultRequestHeaders.Accept.Clear();
                                                            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                            HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/Interviewer_applieddetailAPI/Alllistinterviewdetails").Result;
                                                            client.Dispose();
                                                            if (responseMessage.IsSuccessStatusCode)
                                                            {
                                                                      string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                                      listOpen = JsonConvert.DeserializeObject<List<Interviewer_applieddetail_Models>>(datalist);
                                                            }
                                                            else
                                                            {
                                                                      TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  TempData["expection"] = ex.Message;
                                        }

                                        int pageSize = 5; // Display 10 records per page
                                        int totalRecords = listOpen.Count();
                                        int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                                        var paginatedList = listOpen.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                                        ViewBag.TotalPages = totalPages;
                                        ViewBag.CurrentPage = page;

                                        return View(paginatedList); ;
                              }
                    //CREATE FUNCTIONALITY CODE
                    [HttpGet]
                    public async Task<IActionResult> AddTechnicalInterviewerApplied(int id )//int id
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;
                                                  HttpResponseMessage response = await client.GetAsync($"api/RescheduleDateInterviewOPENINGAPI/Detailsrescheudedate?id={id}");

                                                  if (responseMessage1.IsSuccessStatusCode && response.IsSuccessStatusCode)
                                                  {

                                                            //string data1 = httpResponse.Content.ReadAsStringAsync().Result;
                                                            //lstdesignationmodel = JsonConvert.DeserializeObject<List<DesignationModel>>(data1);
                                                            string data2 = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data2);
                                                            var objreschduledate = JsonConvert.DeserializeObject<RescheduleDateInterviewOPENINGMODEL>(await response.Content.ReadAsStringAsync());
                                                            ViewBag.FirstName = objreschduledate.FirstName;
                                                            ViewBag.MiddleName = objreschduledate.MiddleName;
                                                            ViewBag.LastName = objreschduledate.LastName;
                                                            //  ViewBag.EmailAddress = positionDetails.EmailAddress;--
                                                            ViewBag.Address = objreschduledate.Address;
                                                            //  ViewBag.DateOfBirth = positionDetails.DateOfBirth;
                                                           //   ViewBag.Gender = positionDetails.Gender;
                                                            ViewBag.MobileNumber = objreschduledate.MobileNumber;
                                                            ViewBag.InterviewName = objreschduledate.InterviewerName;
                                                           // ViewBag.InterviewerSchedule = objinterviewapplicationdetaisl.InterviewSchedue;
                                                           // ViewBag.DesignationName = objinterviewapplicationdetaisl.PositionApplied_DesignationName;
                                                           // ViewBag.TotalExperience = objinterviewapplicationdetaisl.TotalExperience;
                                                            //   ViewBag.RelevantExperience = positionDetails.RelevantExperience;
                                                            ViewBag.HighEducation = objreschduledate.HIGHEREDUCATION;
                                                            //ViewBag.HighPercentage = positionDetails.HIgherPercentage;
                                                            //ViewBag.CurrentCtc = positionDetails.CurrentCTC;
                                                            //ViewBag.ExpectedCtc = positionDetails.ExpectedCTC;
                                                           // ViewBag.technicalskill = positionDetails.Skill;--
                                                        //    ViewBag.Reasonchangethecompany = objinterviewapplicationdetaisl.Reasonchangethecompany;
                                                            // ViewBag.InterviewReason=objinterviewapplicationdetaisl.inter
                                                            //ViewBag.pancardnumber = positionDetails.PANCARDNUMBER;
                                                            //ViewBag.photo = positionDetails.image;
                                                            //ViewBag.Resume = positionDetails.Resume_CV;
                                                            ViewBag.positionfeedback = objreschduledate.FEEBACK;

                                                  }

                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage1.ReasonPhrase}/{response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                                                                                                                                                    ////                                                                                                                      //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

                              return View();
                    }

                    //  testing 
                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddTechnicalInterviewerApplied(Interviewer_applieddetail_Models model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/Interviewer_applieddetailAPI/Createinterviewdetails", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "TechnicalInterviewerApplied saved successfully!";
                                                                      return RedirectToAction("TechnicalInterviewerAppliedView");
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server-side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;

                                                 
                                                  if (responseMessage1.IsSuccessStatusCode )
                                                  {
                                                          
                                                          
                                                            string data2 = await responseMessage1.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data2);
                                                           
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                            
                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                              return View(model);
                    }

                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid TechnicalInterviewerApplied id");
                              }

                              try
                              {
                                    Interviewer_applieddetail_Models    objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/Interviewer_applieddetailAPI/Detailsinterviewdetails?id={id}");
                                                  HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification").Result;

                                                  if (response.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<Interviewer_applieddetail_Models>(result);
                                                            var result1 = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(result1);

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("TechnicalInterviewerApplied not found");
                                        }

                                        ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(Interviewer_applieddetail_Models models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                      HttpResponseMessage response = await httpClient.PutAsync("https://localhost:44384/api/Interviewer_applieddetailAPI/Updateinterviewdetailsn", content);
                                                            //     HttpResponseMessage responseMessage = httpClient.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                            if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {





                                                                      TempData["AlertMessage"] = "TechnicalInterviewerApplied Update Successfully ";

                                                                      return RedirectToAction("TechnicalInterviewerAppliedView"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44384/api/HighQualificationAPI/AllHighestQualification");
                                               

                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data);
                                                           
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display
                             
                              return View(models);
                    }

                    //DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> Details(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid TechnicalInterviewerApplied id");
                              }

                              try
                              {
                                        Interviewer_applieddetail_Models model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/Interviewer_applieddetailAPI/Detailsinterviewdetails?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<Interviewer_applieddetail_Models>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("TechnicalInterviewerApplied not found");
                                        }

                                        Interviewer_applieddetail_Models viewModel = new Interviewer_applieddetail_Models()
                                        {
                                                  interviewID = model.interviewID,
                                                  FirstName = model.FirstName,
                                                  MiddleName = model.MiddleName,
                                                  LastName = model.LastName,
                                                  EmailAddress = model.EmailAddress,
                                                  Address = model.Address,
                                                  HIGHEREDUCATION = model.HIGHEREDUCATION,
                                                  MobileNumber = model.MobileNumber,
                                                  InterviewerName = model.InterviewerName,
                                                  Skill = model.Skill,
                                                  InterviewerAccept_Reject = model.InterviewerAccept_Reject,
                                                  //InterviewerReJECT = model.InterviewerReJECT,
                                                  InterviewerStatus = model.InterviewerStatus,
                                                  lastestReschdueDate_time = model.lastestReschdueDate_time,
                                                  Resume_CV = model.Resume_CV,
                                                  fEEDBACK = model.fEEDBACK,
                                        };
                                        //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }
                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid TechnicalInterviewerApplied id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/Interviewer_applieddetailAPI/Deleteinterviewdetails?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "TechnicalInterviewerApplied Delete Successfully ";

                                                            return RedirectToAction("TechnicalInterviewerAppliedView");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("TechnicalInterviewerAppliedView");
                    }

                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri("https://localhost:44384/"); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/Interviewer_applieddetailAPI/export-interviewdetails-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Interviewer_applieddetail_Models.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting Interviewer_applieddetail_Models FROM : {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("TechnicalInterviewerAppliedView");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("TechnicalInterviewerAppliedView");
                              }
                    }

          }
}
