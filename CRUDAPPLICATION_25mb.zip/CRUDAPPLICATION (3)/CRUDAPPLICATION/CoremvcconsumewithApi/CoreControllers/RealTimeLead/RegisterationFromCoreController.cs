﻿
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
           using CRUDAPPLICATION.ModelDTO;
          using Microsoft.AspNetCore.Authentication;
          using Microsoft.AspNetCore.Authentication.Cookies;
           using Microsoft.AspNetCore.Authorization;
       
          using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

          using System.Net.Http.Headers;
                    using System.Security.Claims;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{


          public class RegisterationFromCoreController : Controller
          {
                    private string localUrl = "http://localhost:5007";



       



                    List<RegisterationForm> Registerations = new List<RegisterationForm>();

                    public IActionResult Index(int page = 1)
                    {
                              List<RegisterationForm> employees = new List<RegisterationForm>();

                              try
                              {

                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/RegisterationFormAPI/AllRegisterationForm").Result;

                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            employees = JsonConvert.DeserializeObject<List<RegisterationForm>>(data);


                                                  }

                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                                                  }
                                        }
                              }

                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }
                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = employees.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = employees.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;


                              if (User.Identity.IsAuthenticated)
                              {
                                        var username = User.Identity.Name;  // Get the username
                                        ViewBag.Username = username;  // Pass it to the view using ViewBag
                              }
                              return View(paginatedList);
                    }

                    [HttpGet]
                    public IActionResult RegisterationForm()
                    {

                              return View();

                    }
                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> RegisterationForm(RegisterationForm model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {


                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            model.CreateRegisterform = DateTime.Now;
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync($"api/RegisterationFormAPI/CreateRegisterationForm", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "RegisterationFromData  Add  Successfully ";

                                                                      return RedirectToAction("Login"); // Redirect to the Login action after successful registration
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }

                              return View(model);
                    }





                    //UPDATE
                    //[Authorize]
                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid RegisterationForm id");
                              }

                              try
                              {
                                        RegisterationForm objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/RegisterationFormAPI/DetailsRegisteration?id={id}");
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<RegisterationForm>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("RegisterationForm not found");
                                        }

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }
                    }

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(RegisterationForm models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync("api/RegisterationFormAPI/UpdateRegisteration", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "RegisterationFromData  Update  Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              return View(models);
                    }

                    // DetailsDataCity
                    [Authorize]

                    [HttpGet]
                    public async Task<IActionResult> Details(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid RegisterationForm id");
                              }

                              try
                              {
                                        RegisterationForm model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/RegisterationFormAPI/DetailsRegisteration?id={id}");
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<RegisterationForm>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("Country not found");
                                        }

                                        RegisterationForm viewModel = new RegisterationForm()
                                        {
                                                  id = model.id,
                                                  FullName = model.FullName,
                                                  Email = model.Email,
                                                  Password = model.Password,
                                                  ConformPassword = model.ConformPassword,
                                                  Username = model.Username,
                                                  Gender = model.Gender,
                                                  Photo = model.Photo,
                                                  LoginType = model.LoginType,

                                                  // only for hidden show   registerationcreateform  login form time 
                                                  CreateRegisterform = model.CreateRegisterform,
                                                  FirstLoginTime = model.FirstLoginTime,
                                                  LastLoginTime = model.LastLoginTime,
                                                  FirstLogOutTime = model.FirstLogOutTime,
                                                  LastLogOutTime = model.LastLogOutTime

                                                  //State_Name = model.State_Name
                                        };


                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }

                    // Delete Function
                    [Authorize]

                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid RegisterationForm id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/RegisterationFormAPI/DeleteRegisteration?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "RegisterationFromData  Delete   Successfully ";

                                                            return RedirectToAction("Index");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("Index");
                    }
                    //LOGIN 

                    [HttpGet]
                    public IActionResult Login()

                    {
                           
                              return View();
                    }

                    //[HttpPost]

                    //public async Task<IActionResult> Login(RegisterationFromDTO model)
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {

                    //                                        //model.FirstLoginTime = DateTime.Now;
                    //                                        //model.LastLoginTime = DateTime.Now;

                    //                                        httpClient.BaseAddress = new Uri(localUrl);
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                    //                                        HttpResponseMessage response = await httpClient.PostAsync($"api/RegisterationFormAPI/LoginPage", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {


                    //                                                  var result = await response.Content.ReadAsStringAsync();


                    //                                                  var userRoles = "User"; // Replace with actual role from result if available



                    //                                                  var claims = new List<Claim>
                    //{
                    //  //  new Claim(ClaimTypes.Name, model.FullName),
                    //    new Claim(ClaimTypes.Name, model.Username),
                    //    new Claim(ClaimTypes.Role, userRoles)  // Set roles or other claims as needed
                    //};

                    //                                                  // Create ClaimsIdentity
                    //                                                  var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                    //                                                  // Sign in the user
                    //                                                  await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));

                    //                                              //    return RedirectToAction("Add", "EmployeeProfile"); // Adjust the redirection as needed
                    //                                                                       return RedirectToAction("EmployeeDataDetail", "EmployeeProfile");

                    //                                        }
                    //                                        else
                    //                                        {


                    //                                                  var errorResponse = await response.Content.ReadAsStringAsync();

                    //                                                  // Username + Password both wrong
                    //                                                  if (errorResponse.Contains("Invalid username") && errorResponse.Contains("Invalid password"))
                    //                                                  {
                    //                                                            ModelState.AddModelError("Username", "Username is incorrect.");
                    //                                                            ModelState.AddModelError("Password", "Password is incorrect.");
                    //                                                  }
                    //                                                  // Username wrong only
                    //                                                  else if (errorResponse.Contains("Invalid username"))
                    //                                                  {
                    //                                                            ModelState.AddModelError("Username", "Username is incorrect.");
                    //                                                  }
                    //                                                  // Password wrong only
                    //                                                  else if (errorResponse.Contains("Invalid password"))
                    //                                                  {
                    //                                                            ModelState.AddModelError("Password", "Password is incorrect.");
                    //                                                  }
                    //                                                  // Other unknown error
                    //                                                  else
                    //                                                  {
                    //                                                            ModelState.AddModelError(string.Empty, $"Error: {errorResponse}");
                    //                                                  }



                    //                                        }
                    //                              }

                    //                    }



                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                    //                    }
                    //          }

                    //          return View(model);
                    //}


                    [HttpPost]
                    public async Task<IActionResult> Login(RegisterationFromDTO model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            var content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            var response = await httpClient.PostAsync("api/RegisterationFormAPI/LoginPage", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      var result = await response.Content.ReadAsStringAsync();
                                                                      dynamic loginData = JsonConvert.DeserializeObject(result);

                                                                      string username = loginData.User.Username;
                                                                      int empId = loginData.Employee.EmpId;   // ← EMPLOYEE ID RECEIVED

                                                                      // Create claims
                                                                      var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, username),
                        new Claim("EmpId", empId.ToString())
                    };

                                                                      var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                                                                      await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

                                                                      // Redirect to Employee Details Page with EmpId
                                                                      return RedirectToAction("EmployeeDataDetail", "EmployeeProfile", new { id = empId });
                                                            }
                                                            else
                                                            {
                                                                      var error = await response.Content.ReadAsStringAsync();

                                                                      if (error.Contains("Invalid username"))
                                                                                ModelState.AddModelError("Username", "Username is incorrect.");

                                                                      if (error.Contains("Invalid password"))
                                                                                ModelState.AddModelError("Password", "Password is incorrect.");

                                                                      if (error.Contains("Employee not found"))
                                                                                ModelState.AddModelError("", "Employee details not found for this user.");
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError("", "Error: " + ex.Message);
                                        }
                              }

                              return View(model);
                    }


                    // Checking data 
                    //Correct data 
                    //[HttpPost]
                    //public async Task<IActionResult> Login(RegisterationFromDTO model)
                    //{
                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {
                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri("https://localhost:44384");
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                    //                                        HttpResponseMessage response = await httpClient.PostAsync("/api/RegisterationFormAPI/LoginPage", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  // Extract result if needed (e.g., user roles or employee ID)
                    //                                                  var result = await response.Content.ReadAsStringAsync();

                    //                                                  // Here you should parse the result to extract the necessary details,
                    //                                                  // such as the employee ID. This is a placeholder; you'll need to adjust
                    //                                                  // based on your API response.
                    //                                                  var emp = "User";
                    //                                                  var userRoles = "User"; // Replace with actual role from result if available
                    //                                                 // int employeeId = userRoles. ; // Replace with actual employee ID from the result

                    //                                                  // Create claims
                    //                                                  var claims = new List<Claim>
                    //                                                            {
                    //                                                                new Claim(ClaimTypes.Name, model.Username),
                    //                                                                new Claim(ClaimTypes.Role, userRoles)  // Set roles or other claims as needed
                    //                                                            };

                    //                                                  // Create ClaimsIdentity
                    //                                                  var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                    //                                                  // Sign in the user
                    //                                                  await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));

                    //                                                  // Redirect to the Detail action of EmployeeProfile, passing the employee ID
                    //                                                  //      return RedirectToAction("EmployeeDataDetail", "EmployeeProfile", new { id = employeeId });
                    //                                                  return RedirectToAction("EmployeeDataDetail", "EmployeeProfile", new { eid = employeeId });

                    //                                        }
                    //                                        else
                    //                                        {
                    //                                                  var errorResponse = await response.Content.ReadAsStringAsync();
                    //                                                  ModelState.AddModelError(string.Empty, $"Invalid username or password. Error: {errorResponse}");
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                    //                    }
                    //          }

                    //          return View(model);
                    //}


                    //Logout function
                    public async Task<IActionResult> Logout()
                    {
                            
                              await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

                              return RedirectToAction("Login", "RegisterationFromCore");
                    }
                  
                    // forgetpassword check 

                    [HttpGet]
                    public IActionResult ForgetPassword()
                    {
                              return View();
                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> ForgetPassword(ForgetPasswordUserDto model)
                    {
                              //  if (!ModelState.IsValid)
                              if (ModelState.IsValid)
                              {
                                        try
                                        {


                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");


                                                            //          return View(model);

                                                            var response = await httpClient.PostAsync($"api/RegisterationFormAPI/ForgetPassword", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      //  TempData["AlertMessage"] = "RegisterationFromData  Add  Successfully ";

                                                                      return RedirectToAction("Login", "RegisterationFromCore");
                                                                     // return View ("Login", "RegisterationFromCore");
                                                            }
                                                            else
                                                            {
                                                                      //ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                                      ModelState.AddModelError(string.Empty, "Error Forget password. Please try again.");

                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              return View(model);

                    }

                    [HttpGet]
                    public IActionResult UserForget()
                    {
                              return View();
                    }
                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> UserForget(UserForget model)
                    {
                              //  if (!ModelState.IsValid)
                              if (ModelState.IsValid)
                              {
                                        try
                                        {


                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");


                                                            //          return View(model);

                                                            var response1 = await httpClient.PostAsync($"api/RegisterationFormAPI/UserForget", content);

                                                            if (response1.IsSuccessStatusCode)
                                                            {
                                                                      //  TempData["AlertMessage"] = "RegisterationFromData  Add  Successfully ";

                                                                        return RedirectToAction("Login", "RegisterationFromCore");
                                                                      //return View("Login", "RegisterationFromCore");
                                                            }
                                                            else
                                                            {
                                                                      //ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                                      ModelState.AddModelError(string.Empty, "Error ForgetUserName . Please try again.");

                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              return View(model);

                    }
          }
}












