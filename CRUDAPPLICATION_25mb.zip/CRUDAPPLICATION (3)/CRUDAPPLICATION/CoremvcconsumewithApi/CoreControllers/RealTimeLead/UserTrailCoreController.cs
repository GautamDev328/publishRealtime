﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{
          [Authorize]

          public class UserTrailCoreController : Controller
    {
        public string localUrl = "http://localhost:5007";

        public IActionResult Index(int page = 1)
        {
            List<UserTrailsModels> lstusertrail = new List<UserTrailsModels>();
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage respnose = client.GetAsync($"api/UserTrail/AllDatUsertrail").Result;
                    client.Dispose();
                    if (respnose.IsSuccessStatusCode)
                    {
                        string data = respnose.Content.ReadAsStringAsync().Result;
                        lstusertrail = JsonConvert.DeserializeObject<List<UserTrailsModels>>(data);

                    }
                    else
                    {
                        TempData["Error"] = $"{respnose.StatusCode}";

                    }
                }
            }
            catch (Exception ex)
            {
                TempData["exception"] = ex.Message;
            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = lstusertrail.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = lstusertrail.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }
        // Create Function
        [HttpGet]
        public IActionResult AddUser()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddUser(UserTrailsModels models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        // Check the current user count for the given CompanyId

                        // HttpResponseMessage countResponse = await httpClient.GetAsync($"api/UserTrail/SearchUserTrail?CompanyId={models.CompanyId}");
                        //HttpResponseMessage countResponse = await httpClient.GetAsync($"api/UserTrail/SearchUserTrail?id={models.Id}");

                        //if (countResponse.IsSuccessStatusCode)
                        //{
                        //    var countResult = await countResponse.Content.ReadAsStringAsync();
                        //    int userCount = int.Parse(countResult);

                        //    if (userCount >= 30)
                        //    {
                        //        ModelState.AddModelError(string.Empty, "Cannot create more than 30 users for this company.");
                        //        return View(models);
                        //    }
                        //}
                        //else
                        //{
                        //    ModelState.AddModelError(string.Empty, "Failed to retrieve user count: " + countResponse.ReasonPhrase);
                        //    return View(models);
                        //}

                        // Proceed to create a new user

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync("api/UserTrail/CreateUsertrail", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "UserTrailData  Add  Successfully ";

                                                                      return RedirectToAction("AddUser"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side CreateUserTrail error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid CreateUserTrail id");
            }

            try
            {
                UserTrailsModels objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/UserTrail/DetailsUsertrail?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<UserTrailsModels>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("CreateUserTrail not found");
                }

                return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(UserTrailsModels models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PutAsync($"api/UserTrail/UpdateUsertrail", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "UserTrailData  Update  Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }


        // DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid CreateUserTrail id");
            }

            try
            {
                UserTrailsModels model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/UserTrail/DetailsUsertrail?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<UserTrailsModels>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("CreateUserTrail not found");
                }

                UserTrailsModels viewModel = new UserTrailsModels()
                {
                    UsertrailId = model.UsertrailId,

                    CompanyId = model.CompanyId,

                    CompanyName = model.CompanyName,

                    CompanyAddress = model.CompanyAddress,

                    EmailAddress = model.EmailAddress,

                    PhoneNumber = model.PhoneNumber,

                    CorporateId = model.CorporateId,

                    UserName = model.UserName,

                    Password = model.Password,

                    Confrompassword = model.Confrompassword,

                    PartnerId = model.PartnerId,

                    DealerName = model.DealerName,

                    photodrop = model.photodrop,
                   




                    //Rel_RelationShip=model.Rel_RelationShip,


                    //State_Name = model.State_Name
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

        }


        // Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid CreateUserTrail id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/UserTrail/DeleteUsertrail?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "UserTrailData  Delete  Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }


    }
}
