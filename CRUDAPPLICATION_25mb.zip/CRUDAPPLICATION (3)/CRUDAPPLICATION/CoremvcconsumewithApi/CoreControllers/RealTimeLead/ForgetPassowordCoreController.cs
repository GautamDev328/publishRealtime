﻿//using Microsoft.AspNetCore.Mvc;

//namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
//{
//    public class ForgetPassowordCoreController : Controller
//    {
//        public IActionResult Index()
//        {
//            return View();
//        }


//public class AccountController : Controller
//    {
//        private readonly IUserService _userService;

//        public AccountController(IUserService userService)
//        {
//            _userService = userService;
//        }

//        [HttpGet("Profile")]
//        public IActionResult Profile()
//        {
//            // Example for getting user by email (assuming email is in session or claim)
//            var email = HttpContext.User.Identity.Name; // You may need to adjust based on how you store user email
//            var user = _userService.GetUserByEmail(email);
//            if (user == null)
//            {
//                return NotFound();
//            }
//            return View(user);
//        }

//        [HttpPost("UpdatePassword")]
//        public IActionResult UpdatePassword(string email, string newPassword)
//        {
//            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(newPassword))
//            {
//                ModelState.AddModelError(string.Empty, "Invalid input");
//                return View();
//            }

//            _userService.UpdatePassword(email, newPassword);
//            TempData["SuccessMessage"] = "Password updated successfully";
//            return RedirectToAction("Profile");
//        }
//    }

//}
//}


//@model User

//<h2>User Profile</h2>
//<p>Email: @Model.Email </ p >
//< p > Phone: @Model.Phone </ p >

//< form asp - action = "UpdatePassword" method = "post" >
//    < input type = "hidden" name = "email" value = "@Model.Email" />
//    < label for= "newPassword" > New Password:</ label >
//    < input type = "password" name = "newPassword" id = "newPassword" />
//    < button type = "submit" > Update Password </ button >
//</ form >
