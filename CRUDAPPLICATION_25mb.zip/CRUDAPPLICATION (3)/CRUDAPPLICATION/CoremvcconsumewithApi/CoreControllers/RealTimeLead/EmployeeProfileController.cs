﻿using System.Net.Http.Headers;
using System.Text;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using static System.Net.WebRequestMethods;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{
          [Authorize]

          public class EmployeeProfileController : Controller
    {
        List<City> cities=new List<City>();
        List<StateModel> liststate = new List<StateModel>();
          List<Department> lstdepartment = new List<Department>();
                  //  List<Department> lstdeparment = new List<Department>();

                    List<HigherQualificationModel> lsthighqualificaiton = new List<HigherQualificationModel>();
                    List<DesignationModel> lstdesignationModel = new List<DesignationModel>();
        private string localUrl = "http://localhost:5007";


     


        public IActionResult image()
        {
            return View();

        }
        public IActionResult Masters()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult Home()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }

        public IActionResult CustomerPricing()
        {


            List<CustomerPrice> customerPrices = new List<CustomerPrice>();

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage responseMessage = client.GetAsync($"api/CustomerPrices/GetAllData").Result;


                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        customerPrices = JsonConvert.DeserializeObject<List<CustomerPrice>>(data);

                        // Sorting customerPrices by Id (assuming Id is the property to sort by)
                        customerPrices = customerPrices.OrderBy(cp => cp.Id).ToList();
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
            }

            ViewBag.CustomerList = new SelectList(customerPrices, "CustomerExtraUser", "CustomerExtraUser"); // Assuming CustomerExtraUser is the property to display
            ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

            return View();
        }






        // ALL DATA SHOW FUNCTIONLITY CODE 
        public IActionResult Index(int page = 1)
        {
            List<EmployeeProfile> employees = new List<EmployeeProfile>();

            try
            {

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //HttpResponseMessage responseMessage = client.GetAsync("/EmployeeProfile/ListAllData").Result;
                    HttpResponseMessage responseMessage = client.GetAsync($"api/EmployeeProfile/ListAllData").Result;

                    client.Dispose();
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        employees = JsonConvert.DeserializeObject<List<EmployeeProfile>>(data);


                    }

                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                    }
                }
            }

            catch (Exception ex)
            {
                TempData["expection"] = ex.Message;
            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = employees.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = employees.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }

  

        // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Add()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage responseMessage = client.GetAsync($"api/City/ALLDATACITY").Result;
                    HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                  HttpResponseMessage responseMessage2 = client.GetAsync($"api/Department/ALLDATADepartment").Result;
                    HttpResponseMessage responseMessage3 = client.GetAsync($"api/Designation/ALLDATADesignation").Result;//localhost:44384/api/Designation/GetDesignationsByDepartment
                    HttpResponseMessage responseMessage4 = client.GetAsync($"api/HighQualificationAPI/AllHighestQualification").Result;

                 if (responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage3.IsSuccessStatusCode && responseMessage4.IsSuccessStatusCode)
                    {
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        cities = JsonConvert.DeserializeObject<List<City>>(data);
                        string data1 = responseMessage1.Content.ReadAsStringAsync().Result;
                        liststate = JsonConvert.DeserializeObject<List<StateModel>>(data1);
                       string data2 = responseMessage2.Content.ReadAsStringAsync().Result;
                       lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data2);
                           string data3 = responseMessage3.Content.ReadAsStringAsync().Result;
                          lstdesignationModel = JsonConvert.DeserializeObject<List<DesignationModel>>(data3);
                            string data4 = responseMessage4.Content.ReadAsStringAsync().Result;
                       lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data4);
                                
                                                  }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}/{responseMessage1.ReasonPhrase}/{responseMessage2.ReasonPhrase}/{responseMessage3.ReasonPhrase}/{responseMessage4.IsSuccessStatusCode}";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
            }

            ViewBag.CityList = new SelectList(cities, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display
           // ViewBag.states1 = new SelectList(liststate, "StateName", "StateId");

            ViewBag.states = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
            ViewBag.department1 = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
            ViewBag.Designation1 = new SelectList(lstdesignationModel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
           ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display


                              return View();
        }

        

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(EmployeeProfile models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync($"api/EmployeeProfile/CreateEmployee", content);

                        if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "EmployeeProfileData  Add  Successfully ";


                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side State error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage4 = client.GetAsync($"api/HighQualificationAPI/AllHighestQualification").Result;
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/City/ALLDATACITY").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                                                  HttpResponseMessage responseMessage2 = client.GetAsync($"api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage responseMessage3 = client.GetAsync($"api/Designation/ALLDATADesignation").Result;//l

                                                  //&& httpResponse1.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode
                                                  if (responseMessage4.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                                                  {

                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            cities = JsonConvert.DeserializeObject<List<City>>(data);
                                                            string data1 = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data1);
                                                            string data2 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data2);
                                                            string data3 = responseMessage3.Content.ReadAsStringAsync().Result;
                                                            lstdesignationModel = JsonConvert.DeserializeObject<List<DesignationModel>>(data3);
                                                            string data4 = await responseMessage4.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data4);
                                                          
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CityList = new SelectList(cities, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.states = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.department1 = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Designation1 = new SelectList(lstdesignationModel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }
            
        

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid EmployeeProfile id");
            }

            try
            {
                EmployeeProfile objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage response = await client.GetAsync($"api/EmployeeProfile/DetailsEmployee?id={id}");

                    HttpResponseMessage responseMessage = client.GetAsync($"api/City/ALLDATACITY").Result;
                    HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                    HttpResponseMessage responseMessage2 = client.GetAsync($"api/Department/ALLDATADepartment").Result;
                                                  //HttpResponseMessage responseMessage3 = client.GetAsync("https://localhost:44384/api/Designation/GetDesignationsByDepartment").Result;
                                                  HttpResponseMessage responseMessage3 = client.GetAsync($"api/Designation/ALLDATADesignation").Result; //localhost:44384/api/Designation/GetDesignationsByDepartment
                                                  HttpResponseMessage responseMessage4 = client.GetAsync($"api/HighQualificationAPI/AllHighestQualification").Result;


                                                  if (response.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage3.IsSuccessStatusCode && responseMessage4.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<EmployeeProfile>(result);
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        cities = JsonConvert.DeserializeObject<List<City>>(data);
                        string data1 = responseMessage1.Content.ReadAsStringAsync().Result;
                          liststate = JsonConvert.DeserializeObject<List<StateModel>>(data1);
                            string data2 = responseMessage2.Content.ReadAsStringAsync().Result;
                           lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data2);
                          string data3 = responseMessage3.Content.ReadAsStringAsync().Result;
                           lstdesignationModel = JsonConvert.DeserializeObject<List<DesignationModel>>(data3);
                         var result3 = await responseMessage4.Content.ReadAsStringAsync();
                          lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(result3);

                                                  }
                                                  else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage.ReasonPhrase}/{responseMessage1.ReasonPhrase}/{responseMessage2.ReasonPhrase}/{responseMessage3.ReasonPhrase}/{responseMessage4.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("EmployeeProfile not found");
                }
                ViewBag.CityList = new SelectList(cities, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display
                                                                                     //ViewBag.states1 = new SelectList(liststate, "Id", "StateId");

                          ViewBag.states = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                            ViewBag.department1 = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
              ViewBag.Designation1 = new SelectList(lstdesignationModel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display
          ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EmployeeProfile models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                        // HttpResponseMessage response = await httpClient.PostAsync("api/EmployeeProfile/UpdateEmployee", content);

                        HttpResponseMessage response = await httpClient.PutAsync($"api/EmployeeProfile/UpdateEmployee", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "EmployeeProfileData  Update  Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }

                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage4 = client.GetAsync($"api/HighQualificationAPI/AllHighestQualification").Result;
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/City/ALLDATACITY").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                                                  HttpResponseMessage responseMessage2 = client.GetAsync($"api/Department/ALLDATADepartment").Result;
                                                  HttpResponseMessage responseMessage3 = client.GetAsync($"api/Designation/ALLDATADesignation").Result;//l

                                                  //&& httpResponse1.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode
                                                  if (responseMessage4.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                                                  {

                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            cities = JsonConvert.DeserializeObject<List<City>>(data);
                                                            string data1 = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data1);
                                                            string data2 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            lstdepartment = JsonConvert.DeserializeObject<List<Department>>(data2);
                                                            string data3 = responseMessage3.Content.ReadAsStringAsync().Result;
                                                            lstdesignationModel = JsonConvert.DeserializeObject<List<DesignationModel>>(data3);
                                                            string data4 = await responseMessage4.Content.ReadAsStringAsync();
                                                            lsthighqualificaiton = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(data4);

                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CityList = new SelectList(cities, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.states = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.department1 = new SelectList(lstdepartment, "Dep_Name", "Dep_Name"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.Designation1 = new SelectList(lstdesignationModel, "DesigName", "DesigName"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.CustomHighQualification = new SelectList(lsthighqualificaiton, "HigherQualificaiton", "HigherQualificaiton"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }



                    // DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> Detail(int? id)
                    {
                              //if (id == null || id == 0)
                              //{
                              //    return BadRequest("Invalid EmployeeProfile id");
                              //}
                              if (id == null || id == 0)
                              {
                                        id = HttpContext.Session.GetInt32("LoggedEmpId");

                                        if (id == null || id == 0)
                                        {
                                                  return BadRequest("Invalid EmployeeProfile id");
                                        }
                              }

                              try
                              {
                                        EmployeeProfile model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage response = await client.GetAsync($"api/EmployeeProfile/DetailsEmployee?id={id}");

                                                  //  HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/EmployeeProfile/SeachById?id={id}");
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<EmployeeProfile>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("EmployeeProfile not found");
                                        }

                                        EmployeeProfile viewModel = new EmployeeProfile()
                                        {
                                                  EmpId = model.EmpId,
                                                  FirstName = model.FirstName,
                                                  LastName = model.LastName,
                                                  Designation = model.Designation,
                                                  Address = model.Address,
                                                  PinCode = model.PinCode,
                                                  StateName = model.StateName,

                                                  City = model.City,
                                                  //  PinCode = model.PinCode,
                                                  DepartmentName = model.DepartmentName,
                                                  DesignationName = model.DesignationName,
                                                  Mobile = model.Mobile,
                                                  Gender = model.Gender,
                                                  // DateOfBirth = model.DateOfBirth,
                                                  Age = model.Age

                                                  //Rel_RelationShip=model.Rel_RelationShip,


                                                  //State_Name = model.State_Name
                                        };

                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }

                    //[HttpGet]
                    //public async Task<IActionResult> Detail(int? id)
                    //{
                    //          // If id not received, get from session
                    //          if (id == null || id == 0)
                    //          {
                    //                    id = HttpContext.Session.GetInt32("LoggedEmpId");

                    //                    if (id == null || id == 0)
                    //                    {
                    //                              return BadRequest("Invalid EmployeeProfile id");
                    //                    }
                    //          }

                    //          int empId = id ?? 0;  // Convert nullable to non-nullable safely

                    //          try
                    //          {
                    //                    EmployeeProfile model = null;
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage response = await client.GetAsync($"api/EmployeeProfile/DetailsEmployee?id={empId}");
                    //                              if (response.IsSuccessStatusCode)
                    //                              {
                    //                                        var result = await response.Content.ReadAsStringAsync();
                    //                                        model = JsonConvert.DeserializeObject<EmployeeProfile>(result);
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                    //                                        return View("Error");
                    //                              }
                    //                    }

                    //                    if (model == null)
                    //                    {
                    //                              return NotFound("EmployeeProfile not found");
                    //                    }

                    //                    return View(model);
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //                    return View("Error");
                    //          }
                    //}

                    // Delete Function
                    public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid EmployeeProfile id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //HttpResponseMessage response = await client.DeleteAsync("https://localhost:44384/api/EmployeeProfile/DeleteEmployee?id={id}");

                    HttpResponseMessage response = await client.DeleteAsync($"api/EmployeeProfile/DeleteEmployee?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "EmployeeProfileData  Delete  Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

                



                //EmployeeId --E0021 code show the logic 
                    [HttpGet]
                    public async Task<IActionResult> EmployeeDataDetail(int eid)
                    {
                             
                              if (eid == null || eid == 0)
                              {
                                        return BadRequest("Invalid EmployeeData id");
                                        
                              }

                              try
                              {
                                        EmployeeDataDTO model = null; // Change the type to EmployeeDataDTO

                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get employee data
                                                  HttpResponseMessage response = await client.GetAsync($"api/EmployeeProfile/GetEmployeeDataFetch?empid={eid}");
                                                  Console.WriteLine($"API Call: {response.RequestMessage}");// checking data 

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<EmployeeDataDTO>(result); // Deserialize to EmployeeDataDTO
                                                  }
                                                  else
                                                  {
                                                            // Log the error response for debugging
                                                            var errorResponse = await response.Content.ReadAsStringAsync();// checking data 
                                                            Console.WriteLine($"Error: {response.StatusCode}, Response: {errorResponse}");//checking data
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("EmployeeProfile not found");
                                        }

                                        // Return the view with the EmployeeDataDTO model
                                        return View(model);
                              //}

                    }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }






                    }




                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/EmployeeProfile/export-EmployeeProfile-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "employeeProfiles.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting employeeProfiles: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }

          }



}
