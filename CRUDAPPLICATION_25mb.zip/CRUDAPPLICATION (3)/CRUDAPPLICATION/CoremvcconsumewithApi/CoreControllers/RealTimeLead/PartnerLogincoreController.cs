﻿//using CRUDAPPLICATION.Model;
//using CRUDAPPLICATION.ViewModel;
//using Microsoft.AspNetCore.Authentication.Cookies;
//using Microsoft.AspNetCore.Authentication;
//using Microsoft.AspNetCore.Mvc;
//using Newtonsoft.Json;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Security.Claims;
//using System.Text;
//using CRUDAPPLICATION.DATABASE;
//using Microsoft.EntityFrameworkCore;

//namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
//{
//	public class PartnerLogincoreController : Controller
//	{
//		public string localUrl = "https://localhost:44384";
//        EmployeeDbContext context;
//        //public PartnerLogincoreController(EmployeeDbContext _context)
//        //{
//        //this.context=_context;
                
//        //}

//        public IActionResult Index(int page = 1)
//		{
//			List<PartnerLogin> listpartners = new List<PartnerLogin>();
//			try
//			{
//				using (HttpClient client = new HttpClient())
//				{
//					client.BaseAddress = new Uri(localUrl);
//					client.DefaultRequestHeaders.Clear();
//					client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
//					HttpResponseMessage httpResponseMessage = client.GetAsync("https://localhost:44384/api/PartnerLogin/GetPartnerLogin").Result;
//					client.Dispose();
//					if (httpResponseMessage.IsSuccessStatusCode)
//					{
//						string datalist = httpResponseMessage.Content.ReadAsStringAsync().Result;
//						listpartners = JsonConvert.DeserializeObject<List<PartnerLogin>>(datalist);

//					}
//					else
//					{
//						TempData["ErrorMessage"] = $"{httpResponseMessage.StatusCode}";
//					}
//				}
//			}
//			catch (Exception ex)
//			{
//				TempData["exception"] = ex.Message;

//			}

//            int pageSize = 5; // Display 10 records per page
//            int totalRecords =listpartners.Count();
//            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

//            var paginatedList = listpartners.Skip((page - 1) * pageSize).Take(pageSize).ToList();

//            ViewBag.TotalPages = totalPages;
//            ViewBag.CurrentPage = page;

//            return View(paginatedList);
//        }

//        // CREATE FUNCTIONALITY CODE 
//        [HttpGet]
//        public IActionResult AddPartnerLogin()
//        {
//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> AddPartnerLogin(PartnerLogin model)
//        {
//            if (ModelState.IsValid)
//            {
//                try
//                {
//                    using (HttpClient httpClient = new HttpClient())
//                    {
//                        httpClient.BaseAddress = new Uri(localUrl);
//                        httpClient.DefaultRequestHeaders.Accept.Clear();
//                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//                        string json = JsonConvert.SerializeObject(model);
//                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

//                        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/PartnerLogin/CreatePartnerLogin", content);

//                        if (response.IsSuccessStatusCode)
//                        {
//                            return RedirectToAction("Index"); // Update this with your actual action
//                        }
//                        else
//                        {
//                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
//                }
//            }
//            return View(model);
//        }
//        //UPDATE

//        [HttpGet]
//        public async Task<IActionResult> Edit(int id)
//        {
//            if (id == 0)
//            {
//                return BadRequest("Invalid partnerlogin id");
//            }

//            try
//            {
//                PartnerLogin objpublisher = null;
//                using (HttpClient client = new HttpClient())
//                {
//                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
//                    client.DefaultRequestHeaders.Accept.Clear();
//                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//                    HttpResponseMessage response = await client.GetAsync($"api/PartnerLogin/SearchPartnerLogin?id={id}");
//                    if (response.IsSuccessStatusCode)
//                    {
//                        var result = await response.Content.ReadAsStringAsync();
//                        objpublisher = JsonConvert.DeserializeObject<PartnerLogin>(result);
//                    }
//                    else
//                    {
//                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
//                        return View("Error");
//                    }
//                }

//                if (objpublisher == null)
//                {
//                    return NotFound("Partnerlogin not found");
//                }

//                return View(objpublisher);
//            }
//            catch (Exception ex)
//            {
//                TempData["Exception"] = ex.Message;
//                return View("Error");
//            }
//        }
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Edit(PartnerLogin models)
//        {
//            if (ModelState.IsValid)
//            {
//                try
//                {
//                    using (HttpClient httpClient = new HttpClient())
//                    {
//                        httpClient.BaseAddress = new Uri("https://localhost:44384");
//                        httpClient.DefaultRequestHeaders.Accept.Clear();
//                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//                        string json = JsonConvert.SerializeObject(models);
//                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

//                        HttpResponseMessage response = await httpClient.PutAsync("https://localhost:44384/api/PartnerLogin/UpdatePartnerLogin", content);

//                        if (response.IsSuccessStatusCode)
//                        {
//                            return RedirectToAction("Index"); // Update this with your actual action
//                        }
//                        else
//                        {
//                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
//                }
//            }
//            return View(models);
//        }
//        // DetailsDataCity

//        [HttpGet]
//        public async Task<IActionResult> DetailsDataPartnerLogin(int? id)
//        {
//            if (id == null || id == 0)
//            {
//                return BadRequest("Invalid Partnerlogin id");
//            }

//            try
//            {
//                PartnerLogin model = null;
//                using (HttpClient client = new HttpClient())
//                {
//                    client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
//                    client.DefaultRequestHeaders.Accept.Clear();
//                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//                    HttpResponseMessage response = await client.GetAsync($"api/PartnerLogin/SearchPartnerLogin?id={id}");
//                    if (response.IsSuccessStatusCode)
//                    {
//                        var result = await response.Content.ReadAsStringAsync();
//                        model = JsonConvert.DeserializeObject<PartnerLogin>(result);
//                    }
//                    else
//                    {
//                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
//                        return View("Error");
//                    }
//                }

//                if (model == null)
//                {
//                    return NotFound("Partnerlogin not found");
//                }

//                PartnerLogin viewModel = new PartnerLogin()
//                {
//                    PartnerId = model.PartnerId,
//                    UserName = model.UserName,
//                    Password = model.Password,
//                    EmailAddress = model.EmailAddress,
//                    MobileNumber = model.MobileNumber
//                };

//                return View(viewModel);
//            }
//            catch (Exception ex)
//            {
//                TempData["Exception"] = ex.Message;
//                return View("Error");
//            }

//        }
//            public async Task<IActionResult> Delete(int id)
//            {
//                if (id <= 0)
//                {
//                    return BadRequest("Invalid Partnerlogin id");
//                }

//                try
//                {
//                    using (HttpClient client = new HttpClient())
//                    {
//                        client.BaseAddress = new Uri("https://localhost:44384/"); // Ensure this is your API base address
//                        client.DefaultRequestHeaders.Accept.Clear();
//                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//                        HttpResponseMessage response = await client.DeleteAsync($"api/PartnerLogin/DeletePartnerLogin?id={id}");

//                        if (response.IsSuccessStatusCode)
//                        {
//                            return RedirectToAction("Index");
//                        }
//                        else
//                        {
//                            // Handle server-side errors
//                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    // Handle exceptions
//                    TempData["Exception"] = $"Exception: {ex.Message}";
//                }

//                return RedirectToAction("Index");
//            }
//        [HttpGet]
//        public IActionResult Login()
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Index", "PartnerLogincore");
//            }
//            return View();
//        }

//        [HttpPost]
//        public async Task<IActionResult> Login(PartnerLogin model)
//        {
//            if (ModelState.IsValid)
//            {
//                // Assuming you have a database context named '_context' injected into your controller
//                var user = context.partners
//                    .FirstOrDefault(u => u.UserName == model.UserName && u.Password == model.Password);

//                if (user != null)
//                {
//                    List<Claim> claims = new List<Claim>
//                {
//                    new Claim(ClaimTypes.NameIdentifier, model.UserName)
//                };

//                    ClaimsIdentity claimIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
//                    AuthenticationProperties properties = new AuthenticationProperties
//                    {
//                        AllowRefresh = true,
//                        // Add other properties like IsPersistent, ExpiresUtc etc if needed
//                    };

//                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
//                        new ClaimsPrincipal(claimIdentity), properties);
//                    return RedirectToAction("Index", "PartnerLogincore");
//                }

//                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
//            }
//            return View(model);
//        }

//    }
//}


