﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Math;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{
          //  [Authorize]

          public class BillingDetailsCoreController : Controller
          {
                    List<StateModel> liststate = new List<StateModel>();
                    private string localUrl = "http://localhost:5007/";
                    public CustomerdetailsModel objcustomerdetails = new CustomerdetailsModel();
                    List<BillingModel> lstbilling = new List<BillingModel>();
                    public List<City> lstcity = new List<City>();
                    public List<BankModel> lstbank = new List<BankModel>();
                 // public List<CustomerTypeModel> lstcustomertype = new List<CustomerTypeModel>();    

                    public IActionResult BillingView(int page = 1)
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/AllBillingData").Result;

                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstbilling = JsonConvert.DeserializeObject<List<BillingModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = lstbilling.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = lstbilling.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }




                    //[HttpGet]
                    //public async Task<IActionResult> AddBilling(int id)
                    //{

                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              // Fetching state data
                    //                              var stateResponse = await client.GetAsync("api/State/ListAllData");
                    //                              HttpResponseMessage responseMessage2 = client.GetAsync($"api/City/ALLDATACITY").Result;
                    //                              //  HttpResponseMessage responseMessage = client.GetAsync($"api/BankApi/AllBankList").Result;

                    //                              //&& responseMessage.IsSuccessStatusCode
                    //                              if (stateResponse.IsSuccessStatusCode  && responseMessage2.IsSuccessStatusCode)
                    //                              {
                    //                                        string stateData = await stateResponse.Content.ReadAsStringAsync();
                    //                                        liststate = JsonConvert.DeserializeObject<List<StateModel>>(stateData) ?? new List<StateModel>();

                    //                                        string data2 = responseMessage2.Content.ReadAsStringAsync().Result;
                    //                                        lstcity = JsonConvert.DeserializeObject<List<City>>(data2); 
                    //                                       // string data3 = responseMessage.Content.ReadAsStringAsync().Result;
                    //                                       // lstbank = JsonConvert.DeserializeObject<List<BankModel>>(data3);
                    //                              }

                    //                              // Fetching customer details
                    //                              HttpResponseMessage customerResponse = await client.GetAsync($"api/BillingAPI/OneFetchCustomerDetails?id={id}");
                    //                              //       HttpResponseMessage  bankResponse1 = await client.GetAsync("http://localhost:5007/api/BankApi/BankDetails?id={id}");

                    //                              HttpResponseMessage bankResponse1 = await client.GetAsync($"api/BankApi/BankDetails?id={id}");

                    //                              if (customerResponse.IsSuccessStatusCode && bankResponse1.IsSuccessStatusCode)
                    //                              {
                    //                                        string customerData = await customerResponse.Content.ReadAsStringAsync();
                    //                                        var customerDetails = JsonConvert.DeserializeObject<CustomerdetailsModel>(customerData);
                    //                                        //string bankData = await bankResponse1.Content.ReadAsStringAsync();
                    //                                        //lstbank = JsonConvert.DeserializeObject<BankModel>(bankData);
                    //                                        string bankData = await bankResponse1.Content.ReadAsStringAsync();
                    //                                        lstbank = JsonConvert.DeserializeObject<BankModel>(bankData);


                    //                                        if (customerDetails != null || lstbank != null)
                    //                                        {
                    //                                                  ViewBag.fullname = customerDetails.CustomerName;

                    //                                                  // Matching name logic (optional, if you want to check)
                    //                                                  if (!string.IsNullOrWhiteSpace(lstbank.BankCustomerName) &&
                    //                                                      lstbank.BankCustomerName.Trim().Equals(customerDetails.CustomerName.Trim(), StringComparison.OrdinalIgnoreCase))
                    //                                                  {
                    //                                                            ViewBag.BankupiList = new SelectList(new List<string> { lstbank.BankCustomerName });
                    //                                                  }

                    //                                                  //                                                                var filteredBankList = lstbank
                    //                                                  //.Where(b =>
                    //                                                  //    !string.IsNullOrWhiteSpace(b.BankCustomerName) &&
                    //                                                  //    !string.IsNullOrWhiteSpace(customerDetails.CustomerName) &&
                    //                                                  //    b.BankCustomerName.Trim().Equals(customerDetails.CustomerName.Trim(), StringComparison.OrdinalIgnoreCase)
                    //                                                  //)
                    //                                                  //.ToList();


                    //                                                  //                                                     var         filteredBankList = lstbank
                    //                                                  //.Where(b =>
                    //                                                  //    !string.IsNullOrWhiteSpace(b.BankCustomerName) &&
                    //                                                  //    !string.IsNullOrWhiteSpace(customerDetails.CustomerName) &&
                    //                                                  //    b.BankCustomerName.Trim().Equals(customerDetails.CustomerName.Trim(), StringComparison.OrdinalIgnoreCase)
                    //                                                  //)
                    //                                                  //.ToList();

                    //                                        }




                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"Customer API failed: {customerResponse.ReasonPhrase}";
                    //                              }
                    //                    }

                    //                    // Correct API call with string interpolation


                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //          }
                    //          ViewBag.citylist = new SelectList(lstcity, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display
                    //        //  ViewBag.BankupiList = new SelectList(lstbank, "BankCustomerName", "BankCustomerName");

                    //          ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName");
                    //          return View();
                    //}

                    [HttpGet]
                    public async Task<IActionResult> AddBilling(int id)

                    {

                                 try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Fetch state and city
                                                  HttpResponseMessage response = await client.GetAsync($"api/State/ListAllData");
                                                  HttpResponseMessage responseMessage2 = client.GetAsync($"api/City/ALLDATACITY").Result;
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BankApi/AllBankList").Result;

                                                  if (response.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string stateData = await response.Content.ReadAsStringAsync();
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(stateData) ?? new List<StateModel>();

                                                            string cityData = await responseMessage2.Content.ReadAsStringAsync();
                                                            lstcity = JsonConvert.DeserializeObject<List<City>>(cityData);
                                                            string BankData = await responseMessage.Content.ReadAsStringAsync();
                                                            lstbank = JsonConvert.DeserializeObject<List<BankModel>>(BankData);
                                                  }

                                                  // Fetch customer and bank details using the same ID
                                                  HttpResponseMessage customerResponse = await client.GetAsync($"api/BillingAPI/OneFetchCustomerDetails?id={id}");

                                                  if (customerResponse.IsSuccessStatusCode)
                                                  {
                                                            var customerData = await customerResponse.Content.ReadAsStringAsync();
                                                            var customerDetails = JsonConvert.DeserializeObject<CustomerdetailsModel>(customerData);

                                                            string selectedBankCustomerName = null;


                                                            if (customerDetails != null)
                                                            {
                                                                      ViewBag.fullname = customerDetails.CustomerName;


                                                                      var matchedBank = lstbank.FirstOrDefault(b =>
                                                                                                            string.Equals(b.BankCustomerName?.Trim(), customerDetails.CustomerName?.Trim(), StringComparison.OrdinalIgnoreCase));

                                                                      if (matchedBank != null)
                                                                      {
                                                                                selectedBankCustomerName = matchedBank.BankCustomerName;
                                                                      }
                                                            }
                                                            ViewBag.bankMatchOnly = selectedBankCustomerName;
                                                            ViewBag.banklst = new SelectList(lstbank, "BankCustomerName", "BankCustomerName");

                                                            //  ViewBag.banklst = new SelectList(lstbank, "BankCustomerName", "BankCustomerName", selectedBankCustomerName);

                                                  }

                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = "Failed to fetch customer or bank details.";
                                                  }
                                        }




                              }

                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.citylist = new SelectList(lstcity, "City_Name", "City_Name");
                              ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName");
                              //ViewBag.banklst = new SelectList(lstbank, "BankCustomerName", "BankCustomerName");
                              var model = new BillingModel
                              {
                                        CustomerId = objcustomerdetails.CustId,
                                        BillingDate = DateOnly.FromDateTime(DateTime.Now),
                                        BillingVoucherNumber = GenerateVoucherNumber()
                              };

                              //  ViewBag.fullname = "Customer Full Name"; // If needed
                              return View(model);
                              //  return View();
                    }

                    private string GenerateVoucherNumber()
                    {
                              // Auto-generated unique voucher number like INV202504141231456
                              return "INV" + DateTime.Now.ToString("yyyyMMddHHmmssfff");
                    }

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddBilling(BillingModel model)
                    {

                              //if (!ModelState.IsValid)
                              //{
                              //          await LoadStateList(); // Reload dropdown list
                              //          return View(model);
                              //}
                              //if (ModelState.IsValid)
                              //{
                              if (!ModelState.IsValid)
                              {
                                        return View(model); // Will return to the same page without saving
                              }

                              try
                                        {

                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("http://localhost:5007/api/BillingAPI/CreateBilling", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "BillingView Added Successfully ";

                                                                   //   return RedirectToAction("CreateCustomerDetail");//CreateCustomerDetail--------------AddBilling
                                                                      return RedirectToAction("AddBillingItem");//CreateCustomerDetail--------------AddBilling
                                                            }
                                                            // ✅ Model me CustomerId & BillingId set karna

                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }

                                        ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.citylist = new SelectList(lstcity, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display
                                                                                                              //   ViewBag.BankupiList = new SelectList(lstbank, "BankId", "BankCustomerName");
                                        ViewBag.banklst = new SelectList(lstbank, "BankCustomerName", "BankCustomerName");



                                      //  await LoadStateList(); // Reload dropdown list before returning to the view


                              


                            
                                        var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                                        // Log or debug errors here
                                        TempData["Error"] = string.Join("; ", errors);
                                        return View(model);
                              }


                    // ✅ Helper Method to Load State List
                    //private async Task LoadStateList()
                    //{
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage response = await client.GetAsync($"api/State/ListAllData");
                    //                              HttpResponseMessage responseMessage2 = client.GetAsync($"api/City/ALLDATACITY").Result;
                    //                              HttpResponseMessage responseMessage = client.GetAsync($"api/BankApi/AllBankList").Result;


                    //                              if (response.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string data = await response.Content.ReadAsStringAsync();
                    //                                        var liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                    //                                        string data1 = await responseMessage2.Content.ReadAsStringAsync();
                    //                                        lstcity = JsonConvert.DeserializeObject<List<City>>(data1);
                    //                                        string data2 = await responseMessage.Content.ReadAsStringAsync();
                    //                                        lstbank = JsonConvert.DeserializeObject<List<BankModel>>(data2);

                    //                                        ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName");
                    //                                        ViewBag.citylist = new SelectList(lstcity, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display

                    //                                        ViewBag.banklst = new SelectList(lstbank, "BankCustomerName", "BankCustomerName");

                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = "Error fetching state data: " + ex.Message;
                    //          }
                    //}







                    //ItemDesciptindetails


                    // BillingVIewDesign
                    public IActionResult BillingViewItem(int page = 1)
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/AllBillingData").Result;

                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstbilling = JsonConvert.DeserializeObject<List<BillingModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = lstbilling.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = lstbilling.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }


                    [HttpGet]
                    public IActionResult AddBillingItem()

                    {

                              return View();
                              //  return View();
                    }

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddBillingItem(BillingModel model)
                    {

                              //if (!ModelState.IsValid)
                              //{
                              //          await LoadStateList(); // Reload dropdown list
                              //          return View(model);
                              //}
                              //if (ModelState.IsValid)
                              //{
                              if (!ModelState.IsValid)
                              {
                                        return View(model);
                              }

                                        try
                                        {

                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync("http://localhost:5007/api/BillingAPI/CreateBilling", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "BillingItem Added Successfully ";

                                                            //  return RedirectToAction("CreateCustomerDetail");//CreateCustomerDetail--------------AddBilling
                                                            return RedirectToAction("BillingViewItem");
                                                  }
                                                  // ✅ Model me CustomerId & BillingId set karna

                                                  else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }

                                       




                              


                              var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                                        // Log or debug errors here
                                        TempData["Error"] = string.Join("; ", errors);
                                        return View(model);
                    }

                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> EditBilling(int? id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid Billingid");
                              }

                              try
                              {
                                        BillingModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  //HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/BillingAPI/DetailsBilling?id={id}");
                                                  HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/DetailsBilling?id={id}");
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                                                  HttpResponseMessage responseMessage2 = client.GetAsync($"api/City/ALLDATACITY").Result;
                                                  //    HttpResponseMessage bankResponse1 = await client.GetAsync($"api/BankApi/BankDetails?id={id}");
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BankApi/AllBankList").Result;


                                                  if (response.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode && responseMessage2.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<BillingModel>(result);
                                                            var result1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(result1);
                                                            var result2 = await responseMessage2.Content.ReadAsStringAsync();
                                                            lstcity = JsonConvert.DeserializeObject<List<City>>(result2);
                                                            var result3 = await responseMessage.Content.ReadAsStringAsync();
                                                            lstbank = JsonConvert.DeserializeObject<List<BankModel>>(result3);

                                                  }
                                                  else
                                                  {
                                                            ///{ bankResponse1.IsSuccessStatusCode}
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage1.ReasonPhrase}/{responseMessage2.ReasonPhrase}/{responseMessage.ReasonPhrase}";
                                                            return View("Error");
                                                  }



                                        }


                                        if (objpublisher == null)
                                        {
                                                  return NotFound("BillingData not found");
                                        }


                                        ViewBag.citylist = new SelectList(lstcity, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display

                                        ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        ViewBag.BankupiList = new SelectList(lstbank, "BankCustomerName", "BankCustomerName");

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> EditBilling(BillingModel models)
                    {

                              //if (!ModelState.IsValid)
                              //{
                              //          await LoadStateList(); // Reload dropdown list
                              //          return View(models);

                              //}
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            //HttpResponseMessage response = await httpClient.PostAsync("api/BillingAPI/UpdateBilling", content);
                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/BillingAPI/UpdateBilling", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "BillingView Update  Successfully ";


                                                                      return RedirectToAction("BillingView");
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }

                              ViewBag.citylist = new SelectList(lstcity, "City_Name", "City_Name"); // Assuming CustomerExtraUser is the property to display

                              ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                              ViewBag.BankupiList = new SelectList(lstbank, "BankId", "BankCustomerName");

                              return View(models);
                    }

                    //DetailsData

                    [HttpGet]
                    public async Task<IActionResult> DetailBilling(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid Billing id");

                              }

                              try
                              {
                                        BillingModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/DetailsBilling?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<BillingModel>(result);

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                            //  return View("Error");

                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("BillingModel not found");

                                        }

                                        BillingModel viewModel = new BillingModel()
                                        {

                                                  BillingId = model.BillingId,
                                                  FullName = model.FullName,
                                                  Email = model.Email,
                                                  OtherAmount = model.OtherAmount,

                                                  Address = model.Address,
                                                  City = model.City,
                                                  State = model.State,
                                                  BankName = model.BankName,
                                                  CardNumber = model.CardNumber,
                                                  ExpMonth = model.ExpMonth,
                                                  ExpYear = model.ExpYear,
                                                  //Pincode = model.Pincode,
                                                  CVV = model.CVV
                                        };
                                        return View(viewModel);

                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }


                    //Delete Function
                    public async Task<IActionResult> DeleteBilling(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid Billing id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/BillingAPI/DeleteBilling?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "BillingData Delete Successfully ";

                                                            return RedirectToAction("BillingView");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("BillingView");
                    }


                    //Current Billing View

                    public IActionResult CurrentBillingView()
                    {
                              BillingModel latestBilling = null;
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/AllBillingData").Result;

                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            var lstbilling = JsonConvert.DeserializeObject<List<BillingModel>>(datalist);

                                                            // Get the last added record, assuming a 'BillingDate' field exists
                                                            latestBilling = lstbilling.OrderByDescending(b => b.BillingId).FirstOrDefault();
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              if (latestBilling != null)
                              {
                                        return View(new List<BillingModel> { latestBilling }); // Pass only the latest record as a list
                              }
                              else
                              {
                                        TempData["ErrorMessage"] = "No billing data found.";
                                        return View(new List<BillingModel>()); // Return an empty list if no data
                              }
                    }


                    // Billing  {rint 
                    //public async Task<IActionResult> PrintInvoice(int id)
                    //{
                    //          var response = await _httpClient.GetAsync($"api/billing/commonbilling/{id}");
                    //          if (!response.IsSuccessStatusCode)
                    //                    return View("Error");

                    //          var invoice = await response.Content.ReadFromJsonAsync<CommonBillingVoucherDTO>();
                    //          return View(invoice);
                    //}


                    [HttpGet]
                    public async Task<IActionResult> PrintInvoice(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid Customer ID");
                              }

                              try
                              {
                                        BillingModel model1 = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/BillingPrint?id={id}");
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/AllBillingData").Result;

                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist1 = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstbilling = JsonConvert.DeserializeObject<List<BillingModel>>(datalist1);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }

                                                  if (!response.IsSuccessStatusCode)
                                                  {
                                                            TempData["ErrorMessage"] = response.ReasonPhrase;
                                                            return View("Error");
                                                  }

                                                  var result = await response.Content.ReadAsStringAsync();
                                                  model1 = JsonConvert.DeserializeObject<BillingModel>(result);
                                        }

                                        if (model1 == null)
                                        {
                                                  return NotFound("Billing and customer data not found");
                                        }

                                        var viewModel = new CommonBillingVoucherDTO()
                                        {
                                                  voucherid = model1.BillingId,
                                                  FullName = model1.FullName,
                                                  Address = model1.Address,
                                                  BillingCurrentDate = DateOnly.FromDateTime(DateTime.Now),
                                                  BankUpi = model1.Bankupi,
                                                  BillingVoucherNumber = model1.BillingVoucherNumber,
                                                  ItemDescription= model1.ProductDescription,
                                                  itemQuantity = model1.Quantity,         
                                                  Rate = model1.Rate, 
                                                  Amount = model1.Amount,       
                                                  CGST = model1.CGST,
                                                  SGST = model1.SGST,
                                                  IGST = model1.IGST,
                                                  TotalInWords = model1.TotalInWords
                                                 
                                        };





                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }
                    }

                    //[HttpGet]
                    //public async Task<IActionResult> PrintInvoice(int id)
                    //{
                    //          if (id == 0)
                    //          {
                    //                    return BadRequest("Invalid Customer ID");
                    //          }

                    //          try
                    //          {
                    //                    BillingModel model1 = null;
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/BillingPrint?id={id}");
                    //                              HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/AllBillingData").Result;

                    //                              client.Dispose();
                    //                              if (responseMessage.IsSuccessStatusCode )
                    //                              {
                    //                                        string datalist1 = responseMessage.Content.ReadAsStringAsync().Result;
                    //                                        lstbilling = JsonConvert.DeserializeObject<List<BillingModel>>(datalist1);
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                    //                              }
                    //                              if (!response.IsSuccessStatusCode)
                    //                              {
                    //                                        TempData["ErrorMessage"] = response.ReasonPhrase;
                    //                                        return View("Error");
                    //                              }

                    //                              var result = await response.Content.ReadAsStringAsync();
                    //                              model1 = JsonConvert.DeserializeObject<BillingModel>(result);
                    //                    }

                    //                    if (model1 == null)
                    //                    {
                    //                              return NotFound("BiilingandcustomerData not found");
                    //                    }

                    //                    var viewModel = new CommonBillingVoucherDTO()
                    //                    {
                    //                              voucherid = model1.BillingId,
                    //                              FullName = model1.FullName,
                    //                              Address = model1.Address,
                    //                              BillingCurrentDate = DateOnly.FromDateTime(DateTime.Now),
                    //                              ItemDescription = model1.ProductDescription,
                    //                              itemQuantity = model1.Quantity,
                    //                              Rate = model1.Rate,
                    //                              Amount = model1.OtherAmount,
                    //                              TotalInWords = model1.TotalInWords, // Optional: can convert number to words dynamically
                    //                              BankUpi = model1.Bankupi,
                    //                              BillingVoucherNumber = model1.BillingVoucherNumber,
                    //                              CGST = model1.CGST,
                    //                              SGST = model1.SGST,
                    //                              IGST = model1.IGST
                    //                    };


                    //                    //                                    var viewModel = new CommonBillingVoucherDTO()
                    //                    //                                    {
                    //                    //                                              voucherid = model1.BillingId,
                    //                    //                                              FullName = model1.FullName,
                    //                    //                                              Address = model1.Address,
                    //                    //                                              BillingCurrentDate = DateOnly.FromDateTime(DateTime.Now),
                    //                    //                                              BankUpi = model1.Bankupi,
                    //                    //                                              BillingVoucherNumber = model1.BillingVoucherNumber,
                    //                    //                                              CGST = model1.CGST,
                    //                    //                                              SGST = model1.SGST,
                    //                    //                                              IGST = model1.IGST,
                    //                    //                                              TotalInWords = model1.TotalInWords,
                    //                    //                                               Items= new List<BillingItemDTO>()
                    //                    //{
                    //                    //    new BillingModel()
                    //                    //    {
                    //                    //        ProductDescription = model1.ProductDescription,
                    //                    //        Quantity = model1.Quantity,
                    //                    //        Rate = model1.Rate,
                    //                    //        Amount = model1.OtherAmount
                    //                    //    }
                    //                    //    // you can add multiple items here
                    //                    //}
                    //                    //                                    };

                    //                    return View(viewModel);
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //                    return View("Error");
                    //          }
                    //}


                    //Customerview 
                    public IActionResult Customerview(int page = 1)
                    {
                              List<CustomerdetailsModel> lstcustomer = new List<CustomerdetailsModel>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/ListAllCustomer").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstcustomer = JsonConvert.DeserializeObject<List<CustomerdetailsModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = lstcustomer.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = lstcustomer.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }




                    //CreateCustomerDetail


                    [HttpGet]
                    public IActionResult CreateCustomerDetail()
                    {

                              // var model = new CustomerdetailsModel
                              var model = new CustomerdetailsModel
                              {
                                        CustId = objcustomerdetails.CustId,
                                        custCurrentDate = DateOnly.FromDateTime(DateTime.Now)
                                        //  BillingVoucherNumber = GenerateVoucherNumber()
                              };

                              //  ViewBag.fullname = "Customer Full Name"; // If needed
                              return View(model);
                    }
          




                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> CreateCustomerDetail(CustomerdetailsModel model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync($"api/BillingAPI/CustomerInsertData", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {

                                                                      TempData["AlertMessage"] = "CustomerDetailsData  Add  Successfully ";



                                                                      return RedirectToAction("Customerview"); //CreateCustomerDetail--AddBilling
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }

                              return View(model);
                    }


                   
                  




                    //update CustomerData

                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> EditCustomer(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid CustomerId");
                              }

                              try
                              {
                                        CustomerdetailsModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  //HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/BillingAPI/DetailsBilling?id={id}");
                                                  HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/OneFetchCustomerDetails?id={id}");
                                                  //HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                                                  // && responseMessage1.IsSuccessStatusCode
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<CustomerdetailsModel>(result);
                                                            //var result1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            //liststate = JsonConvert.DeserializeObject<List<StateModel>>(result1);

                                                  }
                                                  else
                                                  {
                                                            ///{ responseMessage1.ReasonPhrase}
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("CustomerData not found");
                                        }

                               //         ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> EditCustomer(CustomerdetailsModel models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            //HttpResponseMessage response = await httpClient.PostAsync("api/BillingAPI/UpdateBilling", content);
                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/BillingAPI/UpdateCustomer", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "CustomerData Update  Successfully ";


                                                                      return RedirectToAction("Customerview");
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                       //       ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }


                    //DetailsData

                    [HttpGet]
                    public async Task<IActionResult> DetailCustomer(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid Customer id");

                              }

                              try
                              {
                                        CustomerdetailsModel model1 = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/OneFetchCustomerDetails?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model1 = JsonConvert.DeserializeObject<CustomerdetailsModel>(result);

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                            //  return View("Error");

                                                  }
                                        }

                                        if (model1 == null)
                                        {
                                                  return NotFound("CustomerModel not found");

                                        }

                                        CustomerdetailsModel viewModel = new CustomerdetailsModel()
                                        {

                                                  CustId = model1.CustId,
                                                  CustomerName = model1.CustomerName,
                                                  CompanyName = model1.CompanyName,
                                                  Customerphone = model1.Customerphone,

                                                  Companyphone = model1.Companyphone,
                                                  CustomerAddress = model1.CustomerAddress,
                                                  CompanyAddress = model1.CompanyAddress,
                                                  CustomerType = model1.CustomerType,
                                                  customerGstRno = model1.customerGstRno,
                                                  CompanyGstRno = model1.CompanyGstRno,
                                                 
                                                 // BillingVoucherNumber = model.BillingVoucherNumber
                                                  //Pincode = model.Pincode,
                                                 // CVV = model.CVV
                                        };
                                        return View(viewModel);

                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> DeleteCustomer(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid Customer id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/BillingAPI/DeleteCustomer?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "CustomerData Delete Successfully ";

                                                            return RedirectToAction("Customerview");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("Customerview");
                    }

                    // Weekly Billing View 
                    //public IActionResult WeeklyBillingView(int page = 1)
                    //{

                    //  List<BillingModel> lstbilling = new List<BillingModel>();
                    //          try
                    //          {
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri(localUrl);
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              // Fetch data for the last 7 days
                    //                              HttpResponseMessage responseMessage = client.GetAsync($"api/BillingAPI/7dayBillingData").Result;

                    //                              if (responseMessage.IsSuccessStatusCode)
                    //                              {
                    //                                        string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                    //                                        lstbilling = JsonConvert.DeserializeObject<List<BillingModel>>(datalist);
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"Error: {responseMessage.StatusCode}";
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = $"An error occurred: {ex.Message}";
                    //          }

                    //          // Pagination logic
                    //          int pageSize = 5; // Display 5 records per page
                    //          int totalRecords = lstbilling.Count;
                    //          int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                    //          var paginatedList = lstbilling.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                    //          // Pass pagination details to the view
                    //          ViewBag.TotalPages = totalPages;
                    //          ViewBag.CurrentPage = page;

                    //          return View(paginatedList);
                    //}


                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/BillingAPI/export-Billing-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "billingModels.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting billingModels: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("BillingView");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }

                    }
                    // CustomerTypeView

                    public IActionResult CustomerTypeView(int page = 1)
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"http://localhost:5007/api/BillingAPI/AllListCustomertype").Result;

                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                         //   lstcustomertype = JsonConvert.DeserializeObject<List<CustomerTypeModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = lstbilling.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = lstbilling.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }



                    // CustomerType add data 

                    [HttpGet]
                    public async Task<IActionResult> CreateCustomerType()

                    {
                              return View();

                    }


                 
                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    //public async Task<IActionResult> CreateCustomerType(CustomerTypeModel model)
                    //{

                    //          if (ModelState.IsValid)
                    //          {
                    //                    try
                    //                    {

                    //                              using (HttpClient httpClient = new HttpClient())
                    //                              {
                    //                                        httpClient.BaseAddress = new Uri(localUrl);
                    //                                        httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                                        string json = JsonConvert.SerializeObject(model);
                    //                                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                                        HttpResponseMessage response = await httpClient.PostAsync($"http://localhost:5007/api/BillingAPI/CreateCustomerTypes", content);

                    //                                        if (response.IsSuccessStatusCode)
                    //                                        {
                    //                                                  TempData["AlertMessage"] = "AddCustomerType Added Successfully ";

                    //                                                  return RedirectToAction("CustomerTypeView");//CreateCustomerDetail--------------AddBilling
                    //                                        }
                    //                                        // ✅ Model me CustomerId & BillingId set karna

                    //                                        else
                    //                                        {
                    //                                                  ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                    //                                        }
                    //                              }
                    //                    }
                    //                    catch (Exception ex)
                    //                    {
                    //                              ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                    //                    }


                    //          }


                    //        //  await LoadStateList(); // Reload dropdown list before returning to the view


                    //          return View(model);
                    //}
                    

                 




          }




}








































