﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{
          [Authorize]

          public class ClientCoreController : Controller
    {

                    private string localUrl = "http://localhost:5007";


        // INDEX PAGE CODE
        public IActionResult Index(int page = 1)
        {
            List<ClientModel> listclient = new List<ClientModel>();
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage responseMessage = client.GetAsync($"api/ClientApi/AllListData").Result;
                    client.Dispose();
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                        listclient = JsonConvert.DeserializeObject<List<ClientModel>>(datalist);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["expection"] = ex.Message;
            }

            int pageSize = 5; // Display 10 records per page
            int totalRecords = listclient.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = listclient.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;

            return View(paginatedList);
        }

 

        // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Create()
        {
           

            return View();
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ClientModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(model);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync($"api/ClientApi/CreateClinetData", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      //if (photo != null)
                                                                      //{
                                                                      //    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", Photo.FileName);
                                                                      //    using (var stream = new FileStream(filePath, FileMode.Create))
                                                                      //    {
                                                                      //        await photo.CopyToAsync(stream);
                                                                      //    }
                                                                      //    model.Photo = Photo.FileName;
                                                                      //}
                                                                      TempData["AlertMessage"] = "ClientData Add  Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
          

            return View(model);
            
        }
                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid clientData id");
                              }

                              try
                              {
                                        ClientModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage response = await client.GetAsync($"api/ClientApi/DetailsClientmodel?clientid={id}");

                                                  //HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/ClientApi/DetailsClientmodel?clientid={id}");
                                                //  HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<ClientModel>(result);
                                                            //string data = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            //liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("clientData not found");
                                        }

                             //           ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(ClientModel models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/ClientApi/UpdateClientmodel", content);

                                                        //    HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/ClientApi/UpdateClientmodel", content);
                                                            //     HttpResponseMessage responseMessage = httpClient.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                            if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {
                                                              TempData["AlertMessage"] = "ClientData Update Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                                                            }




                                                                     
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                            //  ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }
                    //DetailsDataCity

                    //[HttpGet]
                    //public async Task<IActionResult> Detail(int? id)
                    //{
                    //          if (id == null || id == 0)
                    //          {
                    //                    return BadRequest("Invalid clientData id");
                    //          }

                    //          try
                    //          {
                    //                    ClientModel model = null;
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //                            //  HttpResponseMessage response = await client.GetAsync("api/ClientApi/DetailsClientmodel?Client={id}");
                    //                            //  HttpResponseMessage response = await client.GetAsync($"api/ClientApi/DetailsClientmodel?clientid={id}");

                    //                                HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/ClientApi/DetailsClientmodel?clientid={id}");

                    //                              if (response.IsSuccessStatusCode)
                    //                              {
                    //                                        var result = await response.Content.ReadAsStringAsync();
                    //                                        model = JsonConvert.DeserializeObject<ClientModel>(result);
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                    //                                        return View("Error");
                    //                              }
                    //                    }

                    //                    if (model == null)
                    //                    {
                    //                              return NotFound("ClientData not found");
                    //                    }

                    //                    ClientModel viewModel = new ClientModel()
                    //                    {
                    //                              Client_Id = model.Client_Id,
                    //                              ClientName = model.ClientName,
                    //                              Photo = model.Photo
                    //                    };
                    //                    //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                    //                    return View(viewModel);
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Exception"] = ex.Message;
                    //                    return View("Error");
                    //          }
                    //}
                    //DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> Detail(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid ClientDetail id");
                              }

                              try
                              {
                                        ClientModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/ClientApi/DetailsClientmodel?clientid={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<ClientModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("City not found");
                                        }

                                        ClientModel viewModel = new ClientModel()
                                        {
                                                  Client_Id = model.Client_Id,
                                                  ClientName = model.ClientName,
                                                  Photo = model.Photo
                                        };
                                        //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                              {
                                        if (id <= 0)
                                        {
                                                  return BadRequest("Invalid clientData id");
                                        }

                                        try
                                        {
                                                  using (HttpClient client = new HttpClient())
                                                  {
                                                            client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                            client.DefaultRequestHeaders.Accept.Clear();
                                                            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                            //      HttpResponseMessage response = await client.DeleteAsync("api/ClientApi/DeleteClientmodel?clientid={id}");

                                                HttpResponseMessage response = await client.DeleteAsync($"api/ClientApi/DeleteClientmodel?clientid={id}");

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "clientData Delete Successfully ";

                                                                      return RedirectToAction("Index");
                                                            }
                                                            else
                                                            {
                                                                      // Handle server-side errors
                                                                      TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  // Handle exceptions
                                                  TempData["Exception"] = $"Exception: {ex.Message}";
                                        }

                                        return RedirectToAction("Index");
                              }

                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/ClientApi/export-client-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "clientModels.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting clientModels: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }


          }

}

