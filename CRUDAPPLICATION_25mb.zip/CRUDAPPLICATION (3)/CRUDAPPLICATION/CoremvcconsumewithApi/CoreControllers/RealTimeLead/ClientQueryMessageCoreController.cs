﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Linq.Expressions;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{
          [Authorize]

          public class ClientQueryMessageCoreController : Controller
    {
      List<Country> countries=new List<Country>();
        List<StateModel> liststate=new List<StateModel>();
        List<City> lstcity=new List<City>();    
        private string localUrl = "http://localhost:5007";

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ClientQueryMessageView(int page = 1)
        {
            List<ClientQuery> messages = new List<ClientQuery>();
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage httpResponseMessage = client.GetAsync($"api/ClientQueryMessageApi/AllClientQueryMessageShow").Result;

                    client.Dispose();
                    if (httpResponseMessage.IsSuccessStatusCode)//&& response.IsSuccessStatusCode
                    {
                        var data = httpResponseMessage.Content.ReadAsStringAsync().Result;
                        messages = JsonConvert.DeserializeObject<List<ClientQuery>>(data);
                        
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{httpResponseMessage.StatusCode}";
                    }
                }
            }
            catch (Exception ex)
            {

                TempData["expection"] = ex.Message;


            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = messages.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = messages.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;

            return View(paginatedList);
        }

        // Client query message create function
        [HttpGet]
        public IActionResult CreateClientQueryMessge()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage response = client.GetAsync($"api/Country/GETCOUNTRYALL").Result;

                    HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;
                    HttpResponseMessage responseMessage1 = client.GetAsync($"api/City/ALLDATACITY").Result;

                    if (responseMessage.IsSuccessStatusCode && response.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode)
                    {
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                        string data1 = response.Content.ReadAsStringAsync().Result;
                        countries = JsonConvert.DeserializeObject<List<Country>>(data1);
                        string data2 = responseMessage1.Content.ReadAsStringAsync().Result;
                        lstcity = JsonConvert.DeserializeObject<List<City>>(data2);

                        // Sorting customerPrices by Id (assuming Id is the property to sort by)
                        //  liststate = customerPrices.OrderBy(cp => cp.Id).ToList();
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}/{response.ReasonPhrase}/{responseMessage1.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
            }
            ViewBag.countrylist = new SelectList(countries, "CountryName", "CountryName");

            ViewBag.stateList = new SelectList(liststate, "StateName", "StateName");
            ViewBag.CityList = new SelectList(lstcity, "City_Name", "City_Name");

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateClientQueryMessge(ClientQuery model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(model);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync($"api/ClientQueryMessageApi/CreateClientQueryMessage", content);
                        
                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "ClientMessageData  Add  Successfully ";

                                                                      return RedirectToAction("CreateClientQueryMessge"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage response1 = client.GetAsync($"api/Country/GETCOUNTRYALL").Result;

                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/City/ALLDATACITY").Result;
                                                  if (responseMessage.IsSuccessStatusCode    && responseMessage1.IsSuccessStatusCode )
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                            string data1 = response1.Content.ReadAsStringAsync().Result;
                                                            countries = JsonConvert.DeserializeObject<List<Country>>(data1);
                                                            string data2 = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            lstcity = JsonConvert.DeserializeObject<List<City>>(data2);

                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }
                    ViewBag.countrylist = new SelectList(countries, "CountryName", "CountryName");

            ViewBag.stateList = new SelectList(liststate, "StateName", "StateName");
            ViewBag.CityList = new SelectList(lstcity, "City_Name", "City_Name");

            return View(model);
        }

        // ClientQueryMessage  will be update function

        [HttpGet]
        public async Task<IActionResult> EditClientQueryMessage(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid ClientQueryMessage id");
            }

            try
            {
                ClientQuery objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/ClientQueryMessageApi/DetailClientQueryMessage?id={id}");
                    HttpResponseMessage response1 = client.GetAsync($"api/Country/GETCOUNTRYALL").Result;

                    HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;
                    HttpResponseMessage responseMessage1 = client.GetAsync($"api/City/ALLDATACITY").Result;
                    if (response.IsSuccessStatusCode && response1.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode)//responseMessage1.IsSuccessStatusCode
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<ClientQuery>(result);

                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);

                        string data1 = response1.Content.ReadAsStringAsync().Result;
                        countries = JsonConvert.DeserializeObject<List<Country>>(data1);

                        string data2 = responseMessage1.Content.ReadAsStringAsync().Result;
                        lstcity = JsonConvert.DeserializeObject<List<City>>(data2);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage.ReasonPhrase}/{response1.ReasonPhrase}/{responseMessage1.ReasonPhrase}"; /// {responseMessage1.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("ClientQueryMessage not found");
                }

                //      ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                ViewBag.countrylist = new SelectList(countries, "CountryName", "CountryName");

                ViewBag.stateList = new SelectList(liststate, "StateName", "StateName");
                ViewBag.CityList = new SelectList(lstcity, "City_Name", "City_Name");



                return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

          


        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditClientQueryMessage(ClientQuery models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        //HttpResponseMessage response = await httpClient.PostAsync("api/ClientQueryMessageApi/UpdteClientQueryMessage", content);
                        HttpResponseMessage response = await httpClient.PutAsync($"api/ClientQueryMessageApi/UpdteClientQueryMessage", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "ClientMessageData  Update  Successfully ";

                                                                      return RedirectToAction("ClientQueryMessageView"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            //  ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
            ViewBag.countrylist = new SelectList(countries, "CountryName", "CountryName");

            ViewBag.stateList = new SelectList(liststate, "StateName", "StateName");
            ViewBag.CityList = new SelectList(lstcity, "City_Name", "City_Name");



            return View(models);

        }
        // ClientQueryMessage Details

        [HttpGet]
        public async Task<IActionResult> DetailClientQueryMessage(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid DetaiClientQuery id");
            }

            try
            {
                ClientQuery model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/ClientQueryMessageApi/DetailClientQueryMessage?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<ClientQuery>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("DetaiClientQuery not found");
                }

                ClientQuery viewModel = new ClientQuery()
                {
                    c_Id = model.c_Id,
                    clientFirtName = model.clientFirtName,

                    clientLastName = model.clientLastName,
                    Country=model.Country,
                    State=model.State,
                    City=model.City,
                    ContactNumber=model.ContactNumber,  
                    clientDescription = model.clientDescription,

                };
                //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }


        }

        //Delete Function
        public async Task<IActionResult> DeleteClientQueryMessage(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid DetaiClientQuery id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/ClientQueryMessageApi/DeleteClientQueryMessage?id={id}");

                    if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "ClientMessageData  Delete   Successfully ";


                                                            return RedirectToAction("ClientQueryMessageView");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("ClientQueryMessageView");
        }



                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/ClientQueryMessageApi/export-ClientQuery-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "clientQuerys.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting clientQuerys: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }

          }
}
