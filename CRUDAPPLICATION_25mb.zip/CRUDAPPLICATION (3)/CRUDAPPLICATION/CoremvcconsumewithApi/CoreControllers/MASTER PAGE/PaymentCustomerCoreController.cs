﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.RealTimeLead
{
          [Authorize]

          public class PaymentCustomerCoreController : Controller
          {
                    private string localUrl = "http://localhost:5007";
                    //All Data and view bag data show 
                    public IActionResult PaymentCustomer()//Method 
                    {


                              List<PaymentCustomerExtraUserModel> employees = new List<PaymentCustomerExtraUserModel>();
                              List<CustomerPrice> customerPrices = new List<CustomerPrice>();

                              try
                              {

                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  //HttpResponseMessage responseMessage = client.GetAsync("/EmployeeProfile/ListAllData").Result;
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/CustomePaymentAPI/AllPaymentDataList").Result;
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"/api/CustomerPrices/GetAllData").Result;

                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode)
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            string data1 = responseMessage1.Content.ReadAsStringAsync().Result;

                                                            employees = JsonConvert.DeserializeObject<List<PaymentCustomerExtraUserModel>>(data);
                                                            customerPrices = JsonConvert.DeserializeObject<List<CustomerPrice>>(data1);



                                                  }

                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}/ {responseMessage1.ReasonPhrase}";
                                                  }
                                        }
                              }

                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              ViewBag.CustomerList = new SelectList(customerPrices, "CustomerExtraUser", "CustomerExtraUser"); // Assuming CustomerExtraUser is the property to display
                                                                                                                               // ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(validCustomerPrices);
                              ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));
                              return View(employees);
                    }
                    //Add
                    //CreatePaymentCustomer
                    // [HttpGet]
                    //         public IActionResult Add()
                    // {
                    //     return View();
                    // }
                    // //Add
                    //[HttpPost]
                    //[ValidateAntiForgeryToken]
                    // public async Task<IActionResult> Add(PaymentCustomerExtraUserModel model)
                    // {
                    //     if (ModelState.IsValid)
                    //     {
                    //         try
                    //         {
                    //             using (HttpClient httpClient = new HttpClient())
                    //             {
                    //                 httpClient.BaseAddress = new Uri(localUrl);
                    //                 httpClient.DefaultRequestHeaders.Accept.Clear();
                    //                 httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                 string json = JsonConvert.SerializeObject(model);
                    //                 StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    //                 HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/CustomePaymentAPI/CreatePaymentCustomer", content);

                    //                 if (response.IsSuccessStatusCode)
                    //                 {
                    //                     return RedirectToAction("PaymentCustomer"); // Update this with your actual action
                    //                 }
                    //                 else
                    //                 {
                    //                     ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                    //                 }
                    //             }
                    //         }
                    //         catch (Exception ex)
                    //         {
                    //             ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                    //         }
                    //     }
                    //     return View(model);
                    // }





                    //Update

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid Corporate Id OR Device Serial: paymentId");
                              }

                              try
                              {
                                        PaymentCustomerExtraUserModel model = null;

                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/CustomePaymentAPI/SearchPaymentData?id={id}");
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<PaymentCustomerExtraUserModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("Corporate Id OR Device Serial: paymentId not found");
                                        }

                                        return View(model);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }
                    }

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(PaymentCustomerExtraUserModel model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/CustomePaymentAPI/UpdatePaymentData", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      //      TempData["AlertMessage"] = "PaymentCustomerData Update Successfully ";

                                                                      return RedirectToAction("PaymentCustomer"); // Redirect to success action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }

                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }

                              // If ModelState is invalid or update fails, return to the edit view with model
                              return View(model);
                    }

                    // Search Details

                    [HttpGet]
                    public async Task<IActionResult> DetailsDataPayment(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid Corporate Id OR Device Serial:  paymentId");
                              }

                              try
                              {
                                        PaymentCustomerExtraUserModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/CustomePaymentAPI/SearchPaymentData?id={id}");
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<PaymentCustomerExtraUserModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("Country not found");
                                        }

                                        PaymentCustomerExtraUserModel viewModel = new PaymentCustomerExtraUserModel()
                                        {
                                                  id = model.id,
                                                  Device_Serials = model.Device_Serials
                                                  //State_Name = model.State_Name
                                        };

                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }
          
                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/CustomePaymentAPI/export-PaymentCustomer-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "paymentCustomeExtraUserModels.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting cities: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("PaymentCustomer");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }

          }


}
