﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection.Metadata;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers
{
          [Authorize]

          public class RelationModelController : Controller
    {
         List<AddRelationShipModel> relationShipModels=new List<AddRelationShipModel>();    
        private string localUrl = "http://localhost:5007";
        public IActionResult Index(int page = 1)
        {
            List<RelationModel> listrelationModels = new List<RelationModel>();
            try
            {
                using (HttpClient client = new HttpClient()) { 
                client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage responseMessage = client.GetAsync($"api/Relation/ALLDATARelation").Result;
                    client.Dispose();
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string relationModels = responseMessage.Content.ReadAsStringAsync().Result;
                        listrelationModels = JsonConvert.DeserializeObject<List<RelationModel>>(relationModels);
                        
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                    }

                }

            }
            catch (Exception ex)
            {
                TempData["ERRORMESSAGE"] = ex.Message;
            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = listrelationModels.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = listrelationModels.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }


        // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Add()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage responseMessage = client.GetAsync($"api/AddRelaitonShipAPI/ListAllRelation").Result;

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        relationShipModels = JsonConvert.DeserializeObject<List<AddRelationShipModel>>(data);

                      
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
            }

            ViewBag.AddRelationship = new SelectList(relationShipModels, "AddRelationShip", "AddRelationShip"); // Assuming CustomerExtraUser is the property to display
            //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

            return View();
        }
    

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(RelationModel models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync("http://localhost:5007/api/Relation/CreateRelation", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "RelationModelData  Add Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side Relation error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            ViewBag.AddRelationship = new SelectList(relationShipModels, "AddRelationShip", "AddRelationShip"); // Assuming CustomerExtraUser is the property to display

            return View(models);
        }

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid Relation id");
            }

            try
            {
                RelationModel objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/Relation/DetailsRelation?id={id}");
                    HttpResponseMessage responseMessage = client.GetAsync($"api/AddRelaitonShipAPI/ListAllRelation").Result;

                    if (response.IsSuccessStatusCode && responseMessage.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<RelationModel>(result);
                        string data = responseMessage.Content.ReadAsStringAsync().Result;
                        relationShipModels = JsonConvert.DeserializeObject<List<AddRelationShipModel>>(data);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("Relation not found");
                }
                ViewBag.AddRelationship = new SelectList(relationShipModels, "AddRelationShip", "AddRelationShip"); // Assuming CustomerExtraUser is the property to display

                return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(RelationModel models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PutAsync($"api/Relation/UpdateRelation", content);

                        if (response.IsSuccessStatusCode )
                        {
                                                                      TempData["AlertMessage"] = "RelationModelData Update Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            ViewBag.AddRelationship = new SelectList(relationShipModels, "AddRelationShip", "AddRelationShip"); // Assuming CustomerExtraUser is the property to display

            return View(models);
        }


        // DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid Relation id");
            }

            try
            {
                RelationModel model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/Relation/DetailsRelation?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<RelationModel>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("EmployeeQuery not found");
                }

                RelationModel viewModel = new RelationModel()
                {
                    Relat_Id = model.Relat_Id,
                    RefrenceRelation_Name = model.RefrenceRelation_Name,
                   // RefrenceRelation_Name1 = model.RefrenceRelation_Name1,
                   // ReferenceRelation = model.ReferenceRelation,

                   // ReferredRelation1 = model.ReferredRelation1,

                   //MobileNumber= model.MobileNumber,
                   // MobileNumber1 = model.MobileNumber1,

                    //Rel_RelationShip=model.Rel_RelationShip,


                    //State_Name = model.State_Name
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

        }
       

        // Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid Relation id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/Relation/DeleteRelation?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "RelationModelData  Delete  Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }
       
    }
}
