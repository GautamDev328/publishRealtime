﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.Controllers
{
          [Authorize]

          public class CustomerPriceController : Controller
    {
        private string localUrl = "http://localhost:5007";


        public IActionResult Index(int page = 1)
        {
            List<CustomerPrice> listcustomer = new List<CustomerPrice>();
            try
            {
                using (HttpClient client=new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage responseMessage = client.GetAsync($"api/CustomerPrices/GetAllData").Result;
                    client.Dispose();
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                        listcustomer = JsonConvert.DeserializeObject<List<CustomerPrice>>(datalist);


                    }


                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                    }
                }
            }

            catch (Exception ex)
            {
                TempData["expection"] = ex.Message;
            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = listcustomer.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = listcustomer.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }

           // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(CustomerPrice model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(model);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync($"api/CustomerPrices/CreateCustomerPrice", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "CustomerPriceData Add Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side CustomerPrice error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(model);
        }

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid CustomerPrice id");
            }

            try
            {
                CustomerPrice objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/CustomerPrices/DetailCustomerPrice?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<CustomerPrice>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("CustomerPrice not found");
                }

                return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CustomerPrice models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PutAsync($"api/CustomerPrices/UpdateCustomerPrice", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "CustomerPriceData  Update Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }

     
        // DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> DetailsDataCustomerPrice(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid CustomerPrice id");
            }

            try
            {
                CustomerPrice model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/CustomerPrices/DetailCustomerPrice?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<CustomerPrice>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("CustomerPrice not found");
                }

                CustomerPrice viewModel = new CustomerPrice()
                {
                    Id = model.Id,
                    CustomerExtraPrice = model.CustomerExtraPrice,
                    CustomerExtraUser=model.CustomerExtraUser
                    
                    //State_Name = model.State_Name
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

        }
        // Search Funciton


        //[HttpGet]
        //public async Task<IActionResult> Search(int? id)
        //{
        //    if (id == null || id == 0)
        //    {
        //        return BadRequest("Invalid city id");
        //    }

        //    try
        //    {
        //        City model = null;
        //        using (HttpClient client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //            HttpResponseMessage response = await client.GetAsync($"api/City/SearchById?id={id}");
        //            if (response.IsSuccessStatusCode)
        //            {
        //                var result = await response.Content.ReadAsStringAsync();
        //                model = JsonConvert.DeserializeObject<City>(result);
        //            }
        //            else
        //            {
        //                TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
        //                return View("Error");
        //            }
        //        }

        //        if (model == null)
        //        {
        //            return NotFound("City not found");
        //        }

        //        City viewModel = new City()
        //        {
        //            City_Id = model.City_Id,
        //            City_Name = model.City_Name,
        //            State_Name = model.State_Name
        //        };

        //        return View(viewModel);
        //    }
        //    catch (Exception ex)
        //    {
        //        TempData["Exception"] = ex.Message;
        //        return View("Error");
        //    }

        //}


        // Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid CustomerPrice id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/CustomerPrices/DeleteCustomerPrice?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "CustomerPriceData Delete  Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }



                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/CustomerPrices/export-CustomerPrice-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "customerPrices.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting customerPrices: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }

          }
}

