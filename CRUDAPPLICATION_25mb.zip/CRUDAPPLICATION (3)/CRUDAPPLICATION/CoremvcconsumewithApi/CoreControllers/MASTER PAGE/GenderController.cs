﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace CoremvcconsumewithApi.Controllers
{
          [Authorize]

          public class GenderController : Controller
	{
		private string localUrl = "https://localhost:44384";

                    //public string localUrl = "http://localhost:5007";


                    public IActionResult Index(int page = 1)
		{
			List<Gender> listgender = new List<Gender>();
			try
			{
				using (HttpClient client = new HttpClient())
				{
					client.BaseAddress = new Uri(localUrl);
					client.DefaultRequestHeaders.Clear();
					client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
					HttpResponseMessage responseMessage = client.GetAsync("https://localhost:44384/api/Gender/ALLDATAGender").Result;
					client.Dispose();
					if (responseMessage.IsSuccessStatusCode)
					{
						string datalist = responseMessage.Content.ReadAsStringAsync().Result;
						listgender = JsonConvert.DeserializeObject<List<Gender>>(datalist);
					}
					else
					{
						TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";

					}
				}
			}
			catch (Exception ex)
			{

				TempData["expection"] = ex.Message;

			}
            int pageSize = 5; // Display 10 records per page
            int totalRecords = listgender.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = listgender.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }

   // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Gender models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:44384/api/Gender/CreateGender", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "Gender Add Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side EmployeeQuery error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid Gender id");
            }

            try
            {
                Gender objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/Gender/DetailsGender?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<Gender>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("Gender not found");
                }

                return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Gender models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PutAsync("api/Gender/UpdateGender", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "Gender Update Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }


        // DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid Gender id");
            }

            try
            {
                Gender model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/Gender/DetailsGender?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<Gender>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("EmployeeQuery not found");
                }

                Gender viewModel = new Gender()
                {
                  Gen_Id  =model.Gen_Id,
                    Gen_Name = model.Gen_Name,
                  

                    //State_Name = model.State_Name
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

        }
        // Search Funciton


        //[HttpGet]
        //public async Task<IActionResult> Search(int? id)
        //{
        //    if (id == null || id == 0)
        //    {
        //        return BadRequest("Invalid city id");
        //    }

        //    try
        //    {
        //        City model = null;
        //        using (HttpClient client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri("https://localhost:44384/"); // Update with your API base address
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //            HttpResponseMessage response = await client.GetAsync($"api/City/SearchById?id={id}");
        //            if (response.IsSuccessStatusCode)
        //            {
        //                var result = await response.Content.ReadAsStringAsync();
        //                model = JsonConvert.DeserializeObject<City>(result);
        //            }
        //            else
        //            {
        //                TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
        //                return View("Error");
        //            }
        //        }

        //        if (model == null)
        //        {
        //            return NotFound("City not found");
        //        }

        //        City viewModel = new City()
        //        {
        //            City_Id = model.City_Id,
        //            City_Name = model.City_Name,
        //            State_Name = model.State_Name
        //        };

        //        return View(viewModel);
        //    }
        //    catch (Exception ex)
        //    {
        //        TempData["Exception"] = ex.Message;
        //        return View("Error");
        //    }

        //}


        // Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid Gender id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44384/"); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/Gender/DeleteGender?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "Gender  Delete  Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }
    }
}
