﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers
{
          [Authorize]

          public class RoleWiseController : Controller
    {
        private string localUrl = "http://localhost:5007";
        public IActionResult Index(int page = 1)
        {
            List<RoleWiseModel> lstrosewisemodel = new List<RoleWiseModel>();
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage responseMessage = client.GetAsync($"api/ROleWise/ALLDATARoleWiseModel").Result;
                    client.Dispose();
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string rosewisemodel = responseMessage.Content.ReadAsStringAsync().Result;
                        lstrosewisemodel = JsonConvert.DeserializeObject<List<RoleWiseModel>>(rosewisemodel);

                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";

                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = lstrosewisemodel.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = lstrosewisemodel.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }
        // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(RoleWiseModel models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync($"api/ROleWise/CreateRoleWiseModel", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "RoleWise Add Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side RoleWise error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid RoleWise id");
            }

            try
            {
                RoleWiseModel objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/ROleWise/DetailsRoleWise?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<RoleWiseModel>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("ROleWise not found");
                }

                return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(RoleWiseModel models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PutAsync($"api/ROleWise/UpdateRoleWise", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "RoleWise Update Successfully ";


                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
            return View(models);
        }


        // DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid ROleWise id");
            }

            try
            {
                RoleWiseModel model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/ROleWise/DetailsRoleWise?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<RoleWiseModel>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("RoleWise not found");
                }

                RoleWiseModel viewModel = new RoleWiseModel()
                {
                    Role_ID = model.Role_ID,
                    Role_Name = model.Role_Name,
                   
                    //Rel_RelationShip=model.Rel_RelationShip,


                    //State_Name = model.State_Name
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

        }
    


        // Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid ROleWise id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/ROleWise/DeleteRoleWise?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "RoleWise Delete Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }
    }
}
