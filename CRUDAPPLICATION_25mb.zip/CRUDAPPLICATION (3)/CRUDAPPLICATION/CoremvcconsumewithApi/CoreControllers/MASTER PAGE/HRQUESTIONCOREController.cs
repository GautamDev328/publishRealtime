﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.MASTER_PAGE
{
          [Authorize]

          public class HRQUESTIONCOREController : Controller
          {
                    private string localUrl = "http://localhost:5007";

                    //public IActionResult Index()
                    //{
                    //          return View();
                    //}

                    // INDEX PAGE CODE
                    public IActionResult HRQUESTIONVIEW(int page = 1)
                    {
                              //LOCAL VARIABLE 
                              List<HRQUESTIONMODEL> listHRQUESTION = new List<HRQUESTIONMODEL>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/HRQUESTIONAPI/GetHRQUESTION").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listHRQUESTION = JsonConvert.DeserializeObject<List<HRQUESTIONMODEL>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listHRQUESTION.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listHRQUESTION.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }
                    //ADDHRQUESTION

                    [HttpGet]
                    public IActionResult ADDHRQUESTION()
                    {
                             
                              return View();
                    }




                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> ADDHRQUESTION(HRQUESTIONMODEL model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync($"api/HRQUESTIONAPI/AddHRQUESTION", content);
                                                            //   HttpResponseMessage responseMessage =  httpClient.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                            if (response.IsSuccessStatusCode)
                                                            {

                                                                      TempData["AlertMessage"] = "HRQUESTIONMODEL Added Successfully ";
                                                                      return RedirectToAction("HRQUESTIONVIEW"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              //var state = statess.states();
                              //ViewBag.States = new SelectList(state, "Id", "StateName");
                             // ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              return View(model);
                              //  return View(model);
                    }
                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> EditHRQUESTION(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid HRQUESTION id");
                              }

                              try
                              {
                                        HRQUESTIONMODEL objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/HRQUESTIONAPI/DetailsHRQuestion?id={id}");
                                                 // HttpResponseMessage responseMessage1 = client.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                  if (response.IsSuccessStatusCode )
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<HRQUESTIONMODEL>(result);
                                                            //string data = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            //liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("HRQUESTION not found");
                                        }

                                       // ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> EditHRQUESTION(HRQUESTIONMODEL models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/HRQUESTIONAPI/UpdateHRQUESTION", content);
                                                            //     HttpResponseMessage responseMessage = httpClient.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                            if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {





                                                                      TempData["AlertMessage"] = "HRQUESTION Update Successfully ";

                                                                      return RedirectToAction("HRQUESTIONVIEW"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                             // ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }

                    //DetailsHRQUESTIONy

                    [HttpGet]
                    public async Task<IActionResult> DetailsHRQUESTION(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid DetailsHRQUESTIONy id");
                              }

                              try
                              {
                                        HRQUESTIONMODEL model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/HRQUESTIONAPI/DetailsHRQuestion?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<HRQUESTIONMODEL>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("DetailsHRQUESTIONy not found");
                                        }

                                        HRQUESTIONMODEL viewModel = new HRQUESTIONMODEL()
                                        {
                                                  HRQUESITONID = model.HRQUESITONID,
                                                  HRKEYNUMBER = model.HRKEYNUMBER,
                                                  HrQuestionKey = model.HrQuestionKey
                                        };
                                        //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> DeleteHRQUESTION(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid DeleteHRQUESTION id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/HRQUESTIONAPI/DeleteHRQUESTION?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "HRQUESTION Delete Successfully ";

                                                            return RedirectToAction("HRQUESTIONVIEW");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("HRQUESTIONVIEW");
                    }
                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/HRQUESTIONAPI/export-GeneratesHRQUESTIONExcelFile-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "HRQUESTIONMODELs.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting cities: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }
          }
}
