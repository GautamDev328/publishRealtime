﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.MASTER_PAGE
{
          [Authorize]

          public class Auot_CustomerhelpModelCoreController : Controller
          {
                    private string localUrl = "http://localhost:5007";

                    // Customer  support online query
                    public IActionResult Customerhelpview(int page = 1)
                    {
                              List<Auot_CustomerhelpModel> listcity = new List<Auot_CustomerhelpModel>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/Auot_CustomerhelpModelAPI/AllCustomerHelper").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listcity = JsonConvert.DeserializeObject<List<Auot_CustomerhelpModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listcity.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listcity.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }

                    [HttpGet]
                    public IActionResult CreateCustomerHelper()
                    {
                              


                              return View();
                    }

          


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> CreateCustomerHelper(Auot_CustomerhelpModel model)
                    { 
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync($"api/Auot_CustomerhelpModelAPI/CreateCustomerHelper", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {

                                                                      TempData["AlertMessage"] = "CreateCustomerHelper Added Successfully ";
                                                                      return RedirectToAction("CreateCustomerHelper"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                          
                              return View(model);
                              //  return View(model);
                    }


                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> UpdateCustomerHelper(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid UpdateCustomerHelper id");
                              }

                              try
                              {
                                        Auot_CustomerhelpModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                            //      HttpResponseMessage response = await client.GetAsync($"api/State/DetailState?id={id}");
                                                  HttpResponseMessage response = await client.GetAsync($"api/Auot_CustomerhelpModelAPI/DetailsCustomerHelper?id={id}");
                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<Auot_CustomerhelpModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("Auot_CustomerhelpModel not found");
                                        }

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }
                    }

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> UpdateCustomerHelper(Auot_CustomerhelpModel models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync($"hapi/Auot_CustomerhelpModelAPI/UpdateCustomerHelper", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "Customerhelpview Update Successfully ";

                                                                      return RedirectToAction("Customerhelpview"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              return View(models);
                    }
                    //DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> DetailCustomerhelper(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid Auot_CustomerhelpModel id");
                              }

                              try
                              {
                                        Auot_CustomerhelpModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/Auot_CustomerhelpModelAPI/DetailsCustomerHelper?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<Auot_CustomerhelpModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("Customerhelpview not found");
                                        }

                                        Auot_CustomerhelpModel viewModel = new Auot_CustomerhelpModel()
                                        {
                                                  CustomerId = model.CustomerId,
                                                  CustomerName = model.CustomerName,
                                                  Email = model.Email,
                                                  Phone = model.Phone,
                                                  Address = model.Address,
                                                  Message = model.Message,
                                                  CreatedDate = model.CreatedDate

                                        };
                                        //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }


                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid Auot_CustomerhelpModel id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/Auot_CustomerhelpModelAPI/DeleteCustomerHelper?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "Customerhelpview Delete Successfully ";

                                                            return RedirectToAction("Customerhelpview");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("Customerhelpview");
                    }

          }
}
