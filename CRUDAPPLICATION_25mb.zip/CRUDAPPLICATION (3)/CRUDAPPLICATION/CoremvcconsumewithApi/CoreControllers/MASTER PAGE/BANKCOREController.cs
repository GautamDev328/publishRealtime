﻿using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers
{
          [Authorize]

          public class BANKCOREController : Controller

          {



                    private string localUrl = "http://localhost:5007";
                   //List<DistrictNameModel> lstdist = new List<DistrictNameModel>();
                    public List<StateModel> liststate = new List<StateModel>();
                   // BillingModel objbillingmodel = new BillingModel();

                    // INDEX PAGE CODE
                    public IActionResult BankView(int page = 1)
                    {
                              //LOCAL VARIABLE 
                              List<BankModel> lstbank = new List<BankModel>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/BankApi/AllBankList").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstbank = JsonConvert.DeserializeObject<List<BankModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = lstbank.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = lstbank.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }

                    // CREATE FUNCTIONALITY CODE 
                    [HttpGet]
                    public async Task<IActionResult> Add()

                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;
                                                //  HttpResponseMessage responseMessage1 = client.GetAsync($"api/DistrictNameAPI/AllListDistrict").Result;



                                                  if (responseMessage.IsSuccessStatusCode)//&& responseMessage1.IsSuccessStatusCode
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                            //string data1 = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            //lstdist = JsonConvert.DeserializeObject<List<DistrictNameModel>>(data1);
                                                           

                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                                                                      //"/{responseMessage1.IsSuccessStatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomerstateList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                          //    ViewBag.DistictList = new SelectList(lstdist, "DistrictName", "DistrictName"); // Assuming CustomerExtraUser is the property to display
                              return View();

                    }




                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Add(BankModel model)
                    {

                              if (!ModelState.IsValid)
                              {
                                        await LoadStateList(); // Reload dropdown list
                                        return View(model);
                              }

                              //if (ModelState.IsValid)
                              //{
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync($"api/BankApi/AddBank", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "BankData Add Successfully ";

                                                                      return RedirectToAction("BankView"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }

                              await LoadStateList(); // Reload dropdown list before returning to the view
                              return View(model);

                             // Assuming CustomerExtraUser is the property to display

                             
                              }
                    

                              // Reload ViewBag data when returning to the view
                                private async Task LoadStateList()
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;
                                             //     HttpResponseMessage responseMessage1 = client.GetAsync($"api/
                                             //
                                             //     API/AllListDistrict").Result;

                                                  if (responseMessage.IsSuccessStatusCode)//&& responseMessage1.IsSuccessStatusCode
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                            //string data1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            //lstdist = JsonConvert.DeserializeObject<List<DistrictNameModel>>(data1);
                                                  }


                                        }


                              }




                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }
                              ViewBag.CustomerstateList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                       //       ViewBag.DistictList = new SelectList(lstdist, "DistrictName", "DistrictName");

                              //      return View(model);
                    }
                   



                    
                    //ViewBag.CustomerStareList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                    //          return View(model);
                    //  }
                    //[HttpGet]
                    //public async Task<IActionResult> GetDistrictsByState(string stateName)
                    //{
                    //          List<DistrictNameModel> districts = new List<DistrictNameModel>();

                    //          using (HttpClient client = new HttpClient())
                    //          {
                    //                    client.BaseAddress = new Uri(localUrl);
                    //                    client.DefaultRequestHeaders.Accept.Clear();
                    //                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                    HttpResponseMessage response = await client.GetAsync($"https://localhost:44384/api/DistrictAPI/GetDistrictsByState?stateName={stateName}");

                    //                    if (response.IsSuccessStatusCode)
                    //                    {
                    //                              string data = await response.Content.ReadAsStringAsync();
                    //                              districts = JsonConvert.DeserializeObject<List<DistrictNameModel>>(data);
                    //                    }
                    //          }
                    //          return Json(districts);
                    //}







                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid Bankid");
                              }

                              try
                              {
                                        BankModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/BankApi/BankDetails?id={id}");
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;
                                                  //  HttpResponseMessage responseMessage2 = client.GetAsync($"api/DistrictNameAPI/AllListDistrict").Result;
                                                  //&& responseMessage2.IsSuccessStatusCode
                                                  if (response.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode )
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<BankModel>(result);
                                                            string data = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                            //string data1 = responseMessage2.Content.ReadAsStringAsync().Result;
                                                            //lstdist = JsonConvert.DeserializeObject<List<DistrictNameModel>>(data1);
                                                  }
                                                  
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage1.ReasonPhrase}";
                                                                     // $"/{responseMessage2.IsSuccessStatusCode}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("BANK not found");
                                        }

                                        ViewBag.CustomerstateList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                 //       ViewBag.DistictList = new SelectList(lstdist, "DistrictName", "DistrictName"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(BankModel models)
                    {

                              if (!ModelState.IsValid)
                              {
                                        await LoadStateList(); // Reload dropdown list
                                        return View(models);

                              }
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/BankApi/UpdateBank", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {
                                                                      TempData["AlertMessage"] = "BankData Edit Successfully ";

                                                                      return RedirectToAction("BankView");
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                              // Reload ViewBag data when returning to the view

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;
                                                  //  HttpResponseMessage responseMessage1 = client.GetAsync($"hapi/DistrictNameAPI/AllListDistrict").Result;
                                                  // && responseMessage1.IsSuccessStatusCode
                                                  if (responseMessage.IsSuccessStatusCode )
                                                  {
                                                            string data = await responseMessage.Content.ReadAsStringAsync();
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);  
                                                            //string data1 = await responseMessage1.Content.ReadAsStringAsync();
                                                            //lstdist = JsonConvert.DeserializeObject<List<DistrictNameModel>>(data1);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomerstateList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                            //  ViewBag.DistictList = new SelectList(lstdist, "DistrictName", "DistrictName"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }

                    //ViewBag.CustomerstateList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                    //          return View(models);
          
        //DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> DetailsDataBank(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid Bank id");
            }

            try
            {
                BankModel model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.GetAsync($"api/BankApi/BankDetails?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<BankModel>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("Bank not found");
                }

                BankModel viewModel = new BankModel()
                {
                    BankId = model.BankId,
                    BankCustomerName=model.BankCustomerName,
                    AccountNumber=model.AccountNumber,
                    ConfirmAccountNumber=model.ConfirmAccountNumber,
                    BankName = model.BankName,
                    IFSCCODE = model.IFSCCODE,
                    StatusCode = model.StatusCode,
                    MICRCODE = model.MICRCODE,
                    BranchName = model.BranchName,
                    DistrictName = model.DistrictName,
                    Address = model.Address,
                    State = model.State,
                    BankDescription = model.BankDescription  

                };
                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }


        }

        //Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid Bankid");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = await client.DeleteAsync($"api/BankApi/DeleteBank?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "BankData Delete Successfully ";

                                                            return RedirectToAction("BankView");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("BankView");
        }

                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/BankApi/export-Bank-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "bankModels.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting bankModels: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("BankView");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }

          }




}
  