﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CoremvcconsumewithApi.CoreControllers
{
 [Authorize]
          public class DisplayImageController : Controller
          {
                    public IActionResult Index()
                    {
                              return View();
                    }
                    public IActionResult DisplayImage()
                    {
                              return View();
                    }
          }
}
