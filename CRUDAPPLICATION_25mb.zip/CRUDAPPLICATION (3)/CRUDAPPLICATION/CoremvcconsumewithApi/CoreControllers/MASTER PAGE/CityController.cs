﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CoremvcconsumewithApi.Controllers
{
          [Authorize]
          public class CityController : Controller
          {
                    // global variable 
                    List<StateModel> liststate = new List<StateModel>();

                    private string localUrl = "http://localhost:5007";



                    // INDEX PAGE CODE
                    public IActionResult Index(int page = 1)
                    {
                              //LOCAL VARIABLE 
                              List<City> listcity = new List<City>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/City/ALLDATACITY").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listcity = JsonConvert.DeserializeObject<List<City>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }
                              listcity = listcity.GroupBy(c => c.City_Name).Select(g => g.First()).ToList(); /*doublicate data */

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listcity.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listcity.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }

                    // CREATE FUNCTIONALITY CODE 
                    [HttpGet]
                    public IActionResult Add()
                    
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;

                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);

                                                            // Sorting customerPrices by Id (assuming Id is the property to sort by)
                                                            //liststate = customerPrices.OrderBy(cp => cp.Id).ToList();
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                                                                                          //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

                              return View();
                    }

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Add(City model)
                    {
                              if (!ModelState.IsValid)
                              {
                                        await LoadStateList(); // Reload dropdown list
                                        return View(model);
                              }

                              try
                              {
                                        using (HttpClient httpClient = new HttpClient())
                                        {
                                                  httpClient.BaseAddress = new Uri(localUrl);
                                                  httpClient.DefaultRequestHeaders.Accept.Clear();
                                                  httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // ✅ Check if city already exists BEFORE making the POST request
                                                  HttpResponseMessage checkResponse = await httpClient.GetAsync($"api/City/CheckCityExists?cityName={model.City_Name}");
                                                  if (checkResponse.IsSuccessStatusCode)
                                                  {
                                                            string result = await checkResponse.Content.ReadAsStringAsync();
                                                            if (result.Contains("true")) // API should return "true" if city exists
                                                            {
                                                                     // ModelState.AddModelError(string.Empty, "CityName  already Show.");
                                                                    TempData["CityExistsMessage"] = "City Name already Show!";

                                                                      await LoadStateList();
                                                                      return View(model);
                                                            }
                                                  }

                                                  // ✅ If city does not exist, proceed to add it
                                                  string json = JsonConvert.SerializeObject(model);
                                                  StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                  HttpResponseMessage response = await httpClient.PostAsync($"api/City/CREATECITY", content);

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "CityName  added successfully!";
                                                            return RedirectToAction("Index");
                                                  }
                                                  else
                                                  {
                                                            ModelState.AddModelError(string.Empty, "Server error: " + response.ReasonPhrase);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                              }

                              await LoadStateList(); // Reload dropdown list before returning to the view
                              return View(model);
                    }

                    // ✅ Helper Method to Load State List
                    private async Task LoadStateList()
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/State/ListAllData");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            string data = await response.Content.ReadAsStringAsync();
                                                            var liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                            ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = "Error fetching state data: " + ex.Message;
                              }
                    }



                    //  UPDATE

                    [HttpGet]
                    public async Task<IActionResult> Edit(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid city id");
                              }

                              try
                              {
                                        City objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/City/DetailsCity?id={id}");
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;

                                                  if (response.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<City>(result);
                                                            string data = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/ {responseMessage1.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("City not found");
                                        }

                                        ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                       [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> Edit(City models)
                    {
                              if (!ModelState.IsValid)
                              {
                                        await LoadStateList(); // Reload dropdown list
                                        return View(models);

                              }
                              if (ModelState.IsValid)
                                        {

                                                  try
                                                  {
                                                            using (HttpClient httpClient = new HttpClient())
                                                            {
                                                                      httpClient.BaseAddress = new Uri(localUrl);
                                                                      httpClient.DefaultRequestHeaders.Accept.Clear();
                                                                      httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                                      string json = JsonConvert.SerializeObject(models);
                                                                      StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                                                                      // only checking the data  same cityname or difference cityname check 
                                                                      // ✅ Check if city already exists BEFORE making the POST request
                                                                      HttpResponseMessage checkResponse = await httpClient.GetAsync($"api/City/CheckCityExists?cityName={models.City_Name}");
                                                                      if (checkResponse.IsSuccessStatusCode)
                                                                      {
                                                                                string result = await checkResponse.Content.ReadAsStringAsync();
                                                                                if (result.Contains("true")) // API should return "true" if city exists
                                                                                {
                                                                                          // ModelState.AddModelError(string.Empty, "CityName  already Show.");
                                                                                          TempData["CityExistUpdatesMessage"] = "City Name already Show!";

                                                                                          await LoadStateList();
                                                                                          return View(models);
                                                                                }
                                                                      }

                                                                      // ✅ If city does not exist, proceed to add it
                                                                      string jsons = JsonConvert.SerializeObject(models);
                                                                      StringContent contents = new StringContent(jsons, Encoding.UTF8, "application/json");

                                                                      // update case code 
                                                                      HttpResponseMessage response = await httpClient.PostAsync($"api/City/UpdateCity", content);
                                                                      //     HttpResponseMessage responseMessage = httpClient.GetAsync("https://localhost:44384/api/State/ListAllData").Result;

                                                                      if (response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                                      {

                                                                                TempData["AlertMessage"] = "CityData Update Successfully ";

                                                                                return RedirectToAction("Index"); // Update this with your actual action




                                                                      }
                                                                      else
                                                                      {
                                                                                ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                                      }
                                                            }
                                                  }
                                                  catch (Exception ex)
                                                  {
                                                            ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                                  }

                                        }
                             // }// testcheck 
                              ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              return View(models);
                    }



                    //DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> DetailsDataCity(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid city id");
                              }

                              try
                              {
                                        City model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/City/DetailsCity?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<City>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("City not found");
                                        }

                                        City viewModel = new City()
                                        {
                                                  City_Id = model.City_Id,
                                                  City_Name = model.City_Name,
                                                  StateName = model.StateName
                                        };
                                        //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> Delete(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid city id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/City/DeleteCity?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "CityData Delete Successfully ";

                                                            return RedirectToAction("Index");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("Index");
                    }
                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/City/export-cities-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "citys.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting cities: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }



          }






}
    






