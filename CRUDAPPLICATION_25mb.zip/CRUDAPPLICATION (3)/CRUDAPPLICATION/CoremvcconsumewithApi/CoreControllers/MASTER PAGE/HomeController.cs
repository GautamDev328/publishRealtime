using CoremvcconsumewithApi.Models;
using CRUDAPPLICATION.Controllers;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.Controllers
{
          [Authorize]
          public class HomeController : Controller
          {

                    //private readonly List<RegisterationFormModel> _users = new List<RegisterationFormModel>
                    //{
                    //new RegisterationFormModel {Username ="admin", Password = "password" } // Add more users as needed
                    //};


                    private readonly ILogger<HomeController> _logger;

                    public HomeController(ILogger<HomeController> logger)
                    {
                              _logger = logger;
                    }

                    public IActionResult Index()
                    {
                              return View();
                    }

                    public IActionResult Privacy()
                    {
                              return View();
                    }

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}

                 


          
             public IActionResult Error()
                    {
                              return View();
                    }
          }
}
