﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.MASTER_PAGE
{
          [Authorize]

          public class HigherQualificationCoreController : Controller
          {
                    private string localUrl = "http://localhost:5007";

                    //public IActionResult Index()
                    //{
                    //          return View();
                    //}
                    public IActionResult QualificationView(int page=1)
                    {
                              //LOCAL VARIABLE 
                              List<HigherQualificationModel> listhigh = new List<HigherQualificationModel>();
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/HighQualificationAPI/AllHighestQualification").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            listhigh = JsonConvert.DeserializeObject<List<HigherQualificationModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = listhigh.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = listhigh.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }

                    //AddQualification

                    // CREATE FUNCTIONALITY CODE 
                    [HttpGet]
                    public IActionResult AddQualification()
                    {
                            
                              return View();
                    }




                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddQualification(HigherQualificationModel model)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(model);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PostAsync($"api/HighQualificationAPI/AddHighestQualification", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {

                                                                      TempData["AlertMessage"] = "HigherQualification Added Successfully ";
                                                                      return RedirectToAction("QualificationView"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }
                      
                              return View(model);
                    }

                    //UPDATE

                    [HttpGet]
                    public async Task<IActionResult> UpdateQualification(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid HighQualification id");
                              }

                              try
                              {
                                        HigherQualificationModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/HighQualificationAPI/DetailsHighestQualification?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<HigherQualificationModel>(result);
                                                            
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("HighQualification not found");
                                        }


                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }

                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> UpdateQualification(HigherQualificationModel models)
                    {
                              if (ModelState.IsValid)
                              {
                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/HighQualificationAPI/UpdateHighestQualification", content);

                                                            if (response.IsSuccessStatusCode)
                                                            {





                                                                      TempData["AlertMessage"] = "HighQualification Update Successfully ";

                                                                      return RedirectToAction("QualificationView"); // Update this with your actual action
                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }
                              }

                              return View(models);
                    }

                    //DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> DetailQualification(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid HighQualification id");
                              }

                              try
                              {
                                        HigherQualificationModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/HighQualificationAPI/DetailsHighestQualification?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<HigherQualificationModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("HighQualification not found");
                                        }

                                        HigherQualificationModel viewModel = new HigherQualificationModel()
                                        {
                                                  highId = model.highId,
                                                  HigherQualificaiton = model.HigherQualificaiton,
                                        };
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }


                    }

                    //Delete Function
                    public async Task<IActionResult> DeleteQualification(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid HighQualification id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/HighQualificationAPI/DeleteHighestQualification?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "HighQualification Delete Successfully ";

                                                            return RedirectToAction("QualificationView");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("QualificationView");
                    }
                    // Excel Export Download
                    //[HttpGet]
                    //public async Task<IActionResult> ExportExcel()
                    //{
                    //          try
                    //          {
                    //                    // Create an instance of HttpClient
                    //                    using (HttpClient client = new HttpClient())
                    //                    {
                    //                              client.BaseAddress = new Uri("https://localhost:44384/"); // Base URL of the API
                    //                              client.DefaultRequestHeaders.Accept.Clear();
                    //                              client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //                              // Call the API to get the Excel file
                    //                              HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/City/export-cities-to-excel");

                    //                              if (response.IsSuccessStatusCode)
                    //                              {
                    //                                        // Read file content as a byte array
                    //                                        var fileContent = await response.Content.ReadAsByteArrayAsync();
                    //                                        return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "citys.xlsx");
                    //                              }
                    //                              else
                    //                              {
                    //                                        TempData["Error"] = $"Error exporting cities: {response.StatusCode} - {response.ReasonPhrase}";
                    //                                        return RedirectToAction("Index");
                    //                              }
                    //                    }
                    //          }
                    //          catch (Exception ex)
                    //          {
                    //                    TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                    //                    return RedirectToAction("Index");
                    //          }
                    //}




          }
}
