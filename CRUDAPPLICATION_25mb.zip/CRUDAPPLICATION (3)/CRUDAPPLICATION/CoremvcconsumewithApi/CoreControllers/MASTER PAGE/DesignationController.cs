﻿using Azure;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.Controllers
{
          [Authorize]

          public class DesignationController : Controller
    {

          List<Department> lstdeparment = new List<Department>();

           private string localUrl = "http://localhost:5007";
        public IActionResult Index(int page = 1)
        {
            List<DesignationModel> lstdesignationModels= new List<DesignationModel>();
            try
            {
                using(HttpClient client= new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage httpResponse = client.GetAsync($"api/Designation/ALLDATADesignation").Result;
                    client.Dispose();
                    if (httpResponse.IsSuccessStatusCode)
                    {
                        string designationdata=httpResponse.Content.ReadAsStringAsync().Result;
                        lstdesignationModels=JsonConvert.DeserializeObject<List<DesignationModel>>(designationdata);
                    }
                    else
                    {
                        TempData["ErrorMessage"]= $"{httpResponse.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {

                TempData["ErrorMessage"] = ex.Message;
            }
            int pageSize = 5; // Display 10 records per page
            int totalRecords = lstdesignationModels.Count();
            int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            var paginatedList = lstdesignationModels.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;
            return View(paginatedList);
        }

    
        // CREATE FUNCTIONALITY CODE 
        [HttpGet]
        public IActionResult Add()
                    
                              {
                                        try
                                        {
                                                  using (HttpClient client = new HttpClient())
                                                  {
                                                            client.BaseAddress = new Uri(localUrl);
                                                            client.DefaultRequestHeaders.Accept.Clear();
                                                            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            HttpResponseMessage responseMessage = client.GetAsync($"api/Department/ALLDATADepartment").Result;

                                                            if (responseMessage.IsSuccessStatusCode)
                                                            {
                                                                      string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstdeparment = JsonConvert.DeserializeObject<List<Department>>(data);

                                                                      // Sorting customerPrices by Id (assuming Id is the property to sort by)
                                                                      //  liststate = customerPrices.OrderBy(cp => cp.Id).ToList();
                                                            }
                                                            else
                                                            {
                                                                      TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  TempData["Exception"] = ex.Message;
                                        }

                              ViewBag.lstdepart = new SelectList(lstdeparment, "Dep_Name", "Dep_Name");
                              //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

                              return View();
                              }
                    

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(DesignationModel  models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                        HttpResponseMessage response = await httpClient.PostAsync($"api/Designation/CreateDesignation", content);

                         if (response.IsSuccessStatusCode )
                        {
                                                                      TempData["AlertMessage"] = "DesignationData Add Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side Designation error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
                              ViewBag.lstdepart = new SelectList(lstdeparment, "Dep_Name", "Dep_Name");
            return View(models);
        }

        //UPDATE

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("Invalid Designation id");
            }

            try
            {
                DesignationModel objpublisher = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage response = await client.GetAsync($"api/Designation/DetailsDesignation?id={id}");
                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/Department/ALLDATADepartment").Result;

                  if (response.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        objpublisher = JsonConvert.DeserializeObject<DesignationModel>(result);
                         var result1 = await responseMessage1.Content.ReadAsStringAsync();
                         lstdeparment = JsonConvert.DeserializeObject<List<Department>>(result1);
                                                  }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}/{responseMessage1.IsSuccessStatusCode}";
                        return View("Error");
                    }
                }

                if (objpublisher == null)
                {
                    return NotFound("Designation not found");
                }
                                        ViewBag.lstdepart = new SelectList(lstdeparment, "Dep_Name", "Dep_Name");

                                        return View(objpublisher);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(DesignationModel models)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(localUrl);
                        httpClient.DefaultRequestHeaders.Accept.Clear();
                        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        string json = JsonConvert.SerializeObject(models);
                        StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                        HttpResponseMessage response = await httpClient.PutAsync($"api/Designation/UpdateDesignation", content);

                       // HttpResponseMessage response = await httpClient.PutAsync("https://localhost:44384/api/Designation/UpdateDesignation", content);

                        if (response.IsSuccessStatusCode)
                        {
                                                                      TempData["AlertMessage"] = "DesignationData Update Successfully ";

                                                                      return RedirectToAction("Index"); // Update this with your actual action
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                }
            }
                    ViewBag.lstdepart = new SelectList(lstdeparment, "Dep_Name", "Dep_Name");

                              return View(models);
        }


        // DetailsDataCity

        [HttpGet]
        public async Task<IActionResult> DetailsDataDesignation(int? id)
        {
            if (id == null || id == 0)
            {
                return BadRequest("Invalid Designation id");
            }

            try
            {
                DesignationModel model = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Update with your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage response = await client.GetAsync($"api/Designation/DetailsDesignation?id={id}");

                    //HttpResponseMessage response = await client.GetAsync("https://localhost:44384/api/Designation/DetailsDesignation?id={id}");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        model = JsonConvert.DeserializeObject<DesignationModel>(result);
                    }
                    else
                    {
                        TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                        return View("Error");
                    }
                }

                if (model == null)
                {
                    return NotFound("Designation not found");
                }

                DesignationModel viewModel = new DesignationModel()
                {
                    DesigId = model.DesigId,
                    DesigName= model.DesigName,
                    //DesigDescription = model.DesigDescription,
                   DesigType=model.DesigType  /*[Departmentname show the  column] */

                    //State_Name = model.State_Name
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                TempData["Exception"] = ex.Message;
                return View("Error");
            }

        }
     

        // Delete Function
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid Designation id");
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage response = await client.DeleteAsync($"api/Designation/DeleteDesignation?id={id}");

                    //HttpResponseMessage response = await client.DeleteAsync("https://localhost:44384/api/Designation/DeleteDesignation?id={id}");

                    if (response.IsSuccessStatusCode)
                    {
                                                            TempData["AlertMessage"] = "DesignationData  Delete Successfully ";

                                                            return RedirectToAction("Index");
                    }
                    else
                    {
                        // Handle server-side errors
                        TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                TempData["Exception"] = $"Exception: {ex.Message}";
            }

            return RedirectToAction("Index");
        }
                    // fetch the departmentname and designation name demo test


                    // Excel Export Download
                    [HttpGet]
                    public async Task<IActionResult> ExportExcel()
                    {
                              try
                              {
                                        // Create an instance of HttpClient
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Base URL of the API
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // Call the API to get the Excel file
                                                  HttpResponseMessage response = await client.GetAsync($"api/Designation/export-Designation-to-excel");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            // Read file content as a byte array
                                                            var fileContent = await response.Content.ReadAsByteArrayAsync();
                                                            return File(fileContent, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "designations.xlsx");
                                                  }
                                                  else
                                                  {
                                                            TempData["Error"] = $"Error exporting designations: {response.StatusCode} - {response.ReasonPhrase}";
                                                            return RedirectToAction("Index");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Error"] = $"An unexpected error occurred: {ex.Message}";
                                        return RedirectToAction("Index");
                              }
                    }


          }
}
