﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace CoremvcconsumewithApi.CoreControllers.MASTER_PAGE
{
          public class DistrictNameCoreController : Controller
          {
                    List<StateModel> liststate = new List<StateModel>();

                    private string localUrl = "http://localhost:5007";

                    // INDEX PAGE CODE
                    public IActionResult DistrictView(int page = 1)
                    {
                              List<DistrictNameModel> lstdistrictname = new List<DistrictNameModel>();


                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/DistrictNameAPI/AllListDistrict").Result;
                                                  client.Dispose();
                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string datalist = responseMessage.Content.ReadAsStringAsync().Result;
                                                            lstdistrictname = JsonConvert.DeserializeObject<List<DistrictNameModel>>(datalist);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.StatusCode}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["expection"] = ex.Message;
                              }
                              //    listcity = listcity.GroupBy(c => c.City_Name).Select(g => g.First()).ToList(); /*doublicate data */

                              int pageSize = 5; // Display 10 records per page
                              int totalRecords = lstdistrictname.Count();
                              int totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                              var paginatedList = lstdistrictname.Skip((page - 1) * pageSize).Take(pageSize).ToList();

                              ViewBag.TotalPages = totalPages;
                              ViewBag.CurrentPage = page;

                              return View(paginatedList);
                    }


                    [HttpGet]
                    public IActionResult AddDistrict()
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage responseMessage = client.GetAsync($"api/State/ListAllData").Result;

                                                  if (responseMessage.IsSuccessStatusCode)
                                                  {
                                                            string data = responseMessage.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);

                                                            // Sorting customerPrices by Id (assuming Id is the property to sort by)
                                                            //liststate = customerPrices.OrderBy(cp => cp.Id).ToList();
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{responseMessage.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                              }

                              ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                                                                                          //ViewBag.CustomerPricesDict = JsonConvert.SerializeObject(customerPrices.ToDictionary(cp => cp.CustomerExtraUser, cp => cp.CustomerExtraPrice));

                              return View();
                    }


                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> AddDistrict(DistrictNameModel model)
                    {
                              if (!ModelState.IsValid)
                              {
                                        await LoadStateList(); // Reload dropdown list
                                        return View(model);
                              }

                              try
                              {
                                        using (HttpClient httpClient = new HttpClient())
                                        {
                                                  httpClient.BaseAddress = new Uri(localUrl);
                                                  httpClient.DefaultRequestHeaders.Accept.Clear();
                                                  httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  // ✅ Check if city already exists BEFORE making the POST request
                                                  //HttpResponseMessage checkResponse = await httpClient.GetAsync($"https://localhost:44384/api/City/CheckCityExists?cityName={model.City_Name}");
                                                  //if (checkResponse.IsSuccessStatusCode)
                                                  //{
                                                  //          string result = await checkResponse.Content.ReadAsStringAsync();
                                                  //          if (result.Contains("true")) // API should return "true" if city exists
                                                  //          {
                                                  //                    // ModelState.AddModelError(string.Empty, "CityName  already Show.");
                                                  //                    TempData["CityExistsMessage"] = "City Name already Show!";

                                                  //                    await LoadStateList();
                                                  //                    return View(model);
                                                  //          }
                                                  //}

                                                  // ✅ If city does not exist, proceed to add it
                                                  string json = JsonConvert.SerializeObject(model);
                                                  StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                                                  HttpResponseMessage response = await httpClient.PostAsync($"api/DistrictNameAPI/CreateDistrict", content);

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "DistrictName  added successfully!";
                                                            return RedirectToAction("DistrictView");
                                                  }
                                                  else
                                                  {
                                                            ModelState.AddModelError(string.Empty, "Server error: " + response.ReasonPhrase);
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                              }

                              await LoadStateList(); // Reload dropdown list before returning to the view
                              return View(model);
                    }

                    // ✅ Helper Method to Load State List
                    private async Task LoadStateList()
                    {
                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl);
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/State/ListAllData");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            string data = await response.Content.ReadAsStringAsync();
                                                            var liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                            ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName");
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = "Error fetching state data: " + ex.Message;
                              }
                    }
                    //  UPDATE

                    [HttpGet]
                    public async Task<IActionResult> EditDistrict(int id)
                    {
                              if (id == 0)
                              {
                                        return BadRequest("Invalid DistrictName id");
                              }

                              try
                              {
                                        DistrictNameModel objpublisher = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/DistrictNameAPI/DetailsDistrict?id={id}");
                                                  HttpResponseMessage responseMessage1 = client.GetAsync($"api/State/ListAllData").Result;

                                                  if (response.IsSuccessStatusCode && responseMessage1.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            objpublisher = JsonConvert.DeserializeObject<DistrictNameModel>(result);
                                                            string data = responseMessage1.Content.ReadAsStringAsync().Result;
                                                            liststate = JsonConvert.DeserializeObject<List<StateModel>>(data);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}/ {responseMessage1.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (objpublisher == null)
                                        {
                                                  return NotFound("DistrictName not found");
                                        }

                                        ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                                        return View(objpublisher);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }
                    }   
                    

                    [HttpPost]
                    [ValidateAntiForgeryToken]
                    public async Task<IActionResult> EditDistrict(DistrictNameModel models)
                    {
                              if (!ModelState.IsValid)
                              {
                                        await LoadStateList(); // Reload dropdown list
                                        return View(models);

                              }
                              if (ModelState.IsValid)
                              {

                                        try
                                        {
                                                  using (HttpClient httpClient = new HttpClient())
                                                  {
                                                            httpClient.BaseAddress = new Uri(localUrl);
                                                            httpClient.DefaultRequestHeaders.Accept.Clear();
                                                            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                            string json = JsonConvert.SerializeObject(models);
                                                            StringContent content = new StringContent(json, Encoding.UTF8, "application/json");
                                                            // only checking the data  same cityname or difference cityname check 
                                                            // ✅ Check if city already exists BEFORE making the POST request
                                                            //HttpResponseMessage checkResponse = await httpClient.GetAsync($"https://localhost:44384/api/City/CheckCityExists?cityName={models.City_Name}");
                                                            //if (checkResponse.IsSuccessStatusCode)
                                                            //{
                                                            //          string result = await checkResponse.Content.ReadAsStringAsync();
                                                            //          if (result.Contains("true")) // API should return "true" if city exists
                                                            //          {
                                                            //                    // ModelState.AddModelError(string.Empty, "CityName  already Show.");
                                                            //                    TempData["CityExistUpdatesMessage"] = "City Name already Show!";

                                                            //                    await LoadStateList();
                                                            //                    return View(models);
                                                            //          }
                                                            //}

                                                            // ✅ If city does not exist, proceed to add it
                                                            string jsons = JsonConvert.SerializeObject(models);
                                                            StringContent contents = new StringContent(jsons, Encoding.UTF8, "application/json");

                                                            // update case code 
                                                            HttpResponseMessage response = await httpClient.PutAsync($"api/DistrictNameAPI/UpdateDistrict", content);
                                                            HttpResponseMessage responseMessage = httpClient.GetAsync($"api/State/ListAllData").Result;

                                                            if (response.IsSuccessStatusCode && response.IsSuccessStatusCode)// && responseMessage.IsSuccessStatusCode)
                                                            {

                                                                      TempData["AlertMessage"] = "DistrictName Update Successfully ";

                                                                      return RedirectToAction("DistrictView"); // Update this with your actual action




                                                            }
                                                            else
                                                            {
                                                                      ModelState.AddModelError(string.Empty, "Server side error: " + response.ReasonPhrase);
                                                            }
                                                  }
                                        }
                                        catch (Exception ex)
                                        {
                                                  ModelState.AddModelError(string.Empty, "Exception: " + ex.Message);
                                        }


                              }
                              // }// testcheck 
                              ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display

                              return View(models);


                    }


                    //DetailsDataCity

                    [HttpGet]
                    public async Task<IActionResult> DetailsDistrict(int? id)
                    {
                              if (id == null || id == 0)
                              {
                                        return BadRequest("Invalid DetailsDistrict id");
                              }

                              try
                              {
                                        DistrictNameModel model = null;
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Update with your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.GetAsync($"api/DistrictNameAPI/DetailsDistrict?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            var result = await response.Content.ReadAsStringAsync();
                                                            model = JsonConvert.DeserializeObject<DistrictNameModel>(result);
                                                  }
                                                  else
                                                  {
                                                            TempData["ErrorMessage"] = $"{response.ReasonPhrase}";
                                                            return View("Error");
                                                  }
                                        }

                                        if (model == null)
                                        {
                                                  return NotFound("DetailsDistrict not found");
                                        }

                                        DistrictNameModel viewModel = new DistrictNameModel()
                                        {
                                                  DistrictId = model.DistrictId,
                                                  DistrictName = model.DistrictName,
                                                  StateName = model.StateName
                                        };
                                        //ViewBag.CustomerList = new SelectList(liststate, "StateName", "StateName"); // Assuming CustomerExtraUser is the property to display
                                        return View(viewModel);
                              }
                              catch (Exception ex)
                              {
                                        TempData["Exception"] = ex.Message;
                                        return View("Error");
                              }





                    }

                    //Delete Function
                    public async Task<IActionResult> DeleteDistrict(int id)
                    {
                              if (id <= 0)
                              {
                                        return BadRequest("Invalid DeleteDistrict id");
                              }

                              try
                              {
                                        using (HttpClient client = new HttpClient())
                                        {
                                                  client.BaseAddress = new Uri(localUrl); // Ensure this is your API base address
                                                  client.DefaultRequestHeaders.Accept.Clear();
                                                  client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                                                  HttpResponseMessage response = await client.DeleteAsync($"api/DistrictNameAPI/DeleteDistrict?id={id}");

                                                  if (response.IsSuccessStatusCode)
                                                  {
                                                            TempData["AlertMessage"] = "DeleteDistrict Delete Successfully ";

                                                            return RedirectToAction("DistrictView");
                                                  }
                                                  else
                                                  {
                                                            // Handle server-side errors
                                                            TempData["ErrorMessage"] = $"Server error: {response.ReasonPhrase}";
                                                  }
                                        }
                              }
                              catch (Exception ex)
                              {
                                        // Handle exceptions
                                        TempData["Exception"] = $"Exception: {ex.Message}";
                              }

                              return RedirectToAction("DistrictView");
                    }

                    //[HttpGet]
                    //public JsonResult GetDistrictsByStateName(string stateName)
                    //{
                    //          var districts = _context.Districts
                    //                                  .Where(d => d.State.StateName == stateName) // StateName ke basis par filter
                    //                                  .Select(d => new { d.DistrictId, d.DistrictName })
                    //                                  .ToList();

                    //          return Json(districts);
                    //}

          }
}