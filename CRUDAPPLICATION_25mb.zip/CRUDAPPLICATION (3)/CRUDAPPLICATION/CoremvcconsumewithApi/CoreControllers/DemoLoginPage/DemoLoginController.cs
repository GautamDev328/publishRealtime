﻿using Microsoft.AspNetCore.Mvc;

namespace CoremvcconsumewithApi.CoreControllers.DemoLoginPage
{
          public class DemoLoginController : Controller
          {
               //     private string localUrl = "http://localhost:5007";

                    public IActionResult Index()
                    {
                              return View();

                    }
                    public IActionResult Graphs()
                    {
                              return View();
                    }
                    public IActionResult GraphAbsentChart()
                    {
                              return View();
                    }

          }
}
