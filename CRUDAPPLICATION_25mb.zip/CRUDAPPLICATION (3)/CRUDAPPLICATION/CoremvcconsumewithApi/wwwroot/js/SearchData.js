﻿//$(document).ready(function (){
//    alert();
//})

$('#textsearch').keyup(function () {
  
    var valuetype = $(this).val();
    $('tbody tr').each(function () {
        if ($(this).text().search(new RegExp(valuetype, "i")) < 0) {
            $(this).fadeOut();   /* hide -- fadeOut*/
        }
        else {
            $(this).show();
        }
    })
});


