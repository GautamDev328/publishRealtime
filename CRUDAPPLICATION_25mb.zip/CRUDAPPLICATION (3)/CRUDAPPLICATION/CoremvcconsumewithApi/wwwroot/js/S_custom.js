﻿// $(document).ready(function() {

//     alert("Ok check");
//     ListAllData();
//});

// function ListAllData(){debugger
//    $.ajax({
//        url: '/State/Index',
//        type: 'Get',
//        dataType: 'json',
//        contentType: 'application/json;charset=utf-8;',
//        success: function (result, statu, xhr) {
//            var obj = '';
//            $.each(result, function (index, item) {
//                obj += '<tr>';
//                obj += '<td>' + item.StateId + '</td>';
//                obj += '<td>' + item.StateCode + '</td>';
//                obj += '<td>' + item.StateName + '</td>';
//                obj += '</tr>';
//            });
//            $('#table_data').html(obj);
//            alert("Done");
//        },
//        error: function () {
//            alert("Data not saved");
//        }
//    });
//};


$(document).ready(function() {
    alert("Ok check");
    ListAllData();
});


function ListAllData() {
    debugger;
    $.ajax({
        url: '/State/Index',
        type: 'GET',
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        success: function (result, status, xhr) {
            var obj = '';
            $.each(result, function (index, item) {
                obj += '<tr>';
                obj += '<td>' + item.StateId + '</td>';
                obj += '<td>' + item.StateCode + '</td>';
                obj += '<td>' + item.StateName + '</td>';
                obj += '</tr>';
            });
            $('#table_data').html(obj);
            alert("Done");
        },
        error: function () {
            alert("Data not saved");
        }
    });
}

            