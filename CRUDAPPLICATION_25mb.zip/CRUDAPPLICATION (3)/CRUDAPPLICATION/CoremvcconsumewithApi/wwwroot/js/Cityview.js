﻿
function confirmUpdate() {
    return confirm("Are you sure you want to Update  Data?");
}

function confirmCreate() {
  
    return confirm("Are you sure you want to Create  Data?");
    
}
function confirmDelete() {
    return confirm("Are you sure you  want to Delete   Data?");
}

function confirmDetails() {
    return confirm("Are you sure you want  to Details   Data?");
}


function confirmviews() {
    return confirm("Are you sure you want  to  Show All Data?");
}
function confirmdataempty() {
    return confirm("Are you sure you want to  DATA  NOT SHOW ?");
}