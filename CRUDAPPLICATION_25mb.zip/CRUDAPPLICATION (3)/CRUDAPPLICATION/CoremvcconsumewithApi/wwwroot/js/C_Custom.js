﻿$(document).ready(function () {
    ListAllData();
    alert("Ok check");
});

function ListAllData() {debugger
    $.ajax({
        url:'~/City/Index',
        type: 'Get',
        dataType: 'json',
        contentType: 'application/json;charset=utf-8;',
        success: function(result,statu,xhr) {
            var obj = '';
            $.each(result, function (index, item) {
                obj += '<tr>';
                obj += '<td>' + item.City_Id + '</td>';
                obj += '<td>' + item.City_Name + '</td>';
                obj += '<td>' + item.State_Name + '</td>';
                obj += '</tr>';
            });
            $('#table_data').html(obj);
            alert("Done");
        },
        error: function () {
            alert("Data not saved");
        }
    });
};
