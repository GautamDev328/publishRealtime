﻿using CRUDAPPLICATION.Model;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.ModelDTO
{
          public class CommonBillingVoucherDTO
          {
                   [key]
              public  int voucherid { get; set; }
                   [Required(ErrorMessage = "PartyName Willbe Required")]
                    public string? FullName { get; set; } = string.Empty;
                  // [Required(ErrorMessage = "Address Willbe Required")]
             
                    public string? Address { get; set; } =null;
                    //[Required(ErrorMessage = "custCurrentDate Willbe Required")]

                    //public DateOnly? custCurrentDate { get; set; } = null;
                    //[Required(ErrorMessage = "VoucherDate Willbe Required")]

                    public DateOnly? BillingCurrentDate { get; set; } = null;
                  //  [Required(ErrorMessage = "BillingVoucherNumber Willbe Required")]


                    public string? BillingVoucherNumber { get; set; } = string.Empty;// invoice  number
                    [Required(ErrorMessage = "MobilNumber Willbe Required")]
                    [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]


                    public string? MobilNumber { get; set; } =null;
                   // [Required(ErrorMessage = "ItemDescription will be required")]
                    public string? ItemDescription { get; set; } =null;// Production Description
                   // [Required(ErrorMessage = "itemQunatitity will be required")]

                    public string? itemQuantity { get; set; } = null;
                    //[Required(ErrorMessage = "itemRate will be required")]

                    public string? Rate { get; set; } = null;
                 //   [Required(ErrorMessage = "Amount will be required")]

                    public string? Amount { get; set; } = null;
                    //  [Required(ErrorMessage = "CGST will be required")]

                    public string? CGST { get; set; } = null;
                    //    [Required(ErrorMessage = "SGST will be required")]

                    public string? SGST { get; set; } = null;
                    // [Required(ErrorMessage = "IGST will be required")]

                    public string? IGST { get; set; } = null;
                    //  [Required(ErrorMessage = "TotalInWords will be required")]



                    public string? TotalInWords { get; set; } = null;
                    public string? BankUpi { get; set; } = null;
                  //  public List<BillingItemDTO> Items { get; set; }

                    //public static implicit operator CommonBillingVoucherDTO(CommonBillingVoucherDTO v)
                    //{
                    //          throw new NotImplementedException();
                    //}
          }

          //public class BillingItemDTO
          //{
          //          public string ProductDescription { get; set; }
          //          public int Quantity { get; set; }
          //          public decimal Rate { get; set; }
          //          public decimal Amount { get; set; }
          //}
}
