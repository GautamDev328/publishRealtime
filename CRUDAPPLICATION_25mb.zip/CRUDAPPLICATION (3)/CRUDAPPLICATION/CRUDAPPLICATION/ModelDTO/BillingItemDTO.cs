﻿//namespace CRUDAPPLICATION.ModelDTO
//{
//          public class BillingItemDTO
//          {
//                    public string ProductDescription { get; set; }
//                    public int Quantity { get; set; }
//                    public decimal Rate { get; set; }
//                    public decimal Amount { get; set; }
//          }

//}
