﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.ModelDTO
{
          public class EmployeeDataDTO
          {
                    [Key]
                    public int EmpId { get; set; }

                    [Display(Name = "Employee ID")]
                    public string FormattedEmpId
                    {
                              get
                              {
                                        return $"Emp01{EmpId}";
                              }
                    }

                    [Required(ErrorMessage = "Enter the First Name")]
                    [StringLength(50, ErrorMessage = "First Name cannot be longer than 50 characters.")]
                    public string? FirstName { get; set; } = null;
                    [Required(ErrorMessage = "Enter the Last Name")]
                    [StringLength(50, ErrorMessage = "Last Name cannot be longer than 50 characters.")]

                    public string? LastName { get; set; } = null;

                    [Required(ErrorMessage = "Contact No is required.")]
                     [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]
                       public string? Mobilenumber { get; set; } = null;

                    [EmailAddress(ErrorMessage = "Invalid Email Address")]
                    [Required(ErrorMessage = "Please enter the Email")]
                    [StringLength(100, ErrorMessage = "Email cannot be longer than 100 characters.")]
                    public string? EmailName { get; set; } = null;


                    [Required(ErrorMessage = "Please select the Designation")]
                    [StringLength(100, ErrorMessage = "Designation cannot be longer than 100 characters.")]

                    public string? DesignationName { get; set; } = null;

                    [Required(ErrorMessage = "Please select the Department")]
                    [StringLength(100, ErrorMessage = "Department cannot be longer than 100 characters.")]

                    public string? DepartmentName { get; set; } = null;

                    

                    
          }

}
