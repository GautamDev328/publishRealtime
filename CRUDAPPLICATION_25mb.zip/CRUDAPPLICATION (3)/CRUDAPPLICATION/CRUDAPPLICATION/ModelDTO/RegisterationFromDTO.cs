﻿using CRUDAPPLICATION.Model;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRUDAPPLICATION.ModelDTO
{
    public class RegisterationFromDTO
    {
        [Key]
        public int regtid { get; set; }
                   // [Required(ErrorMessage = "FullName will be required")]
                   // public string? FullName { get; set; } = null;

                    [Required(ErrorMessage = "UserName will be requied")]
        [StringLength(100)]

        public string? Username { get; set; } = null;
        [Required(ErrorMessage = "Password Will be Required")]
        public string? Password { get; set; } = null;

                    //  public string? Photo { get; set; } = null;
                    public bool isActive { get; set; }
                   // [DisplayFormat(Message="ISREMEMBER")]
                    public bool remainder { get; set; }


                     public string LoginType { get; set; } = null;



                    ///Role 
                    // public int EmployeeId { get; set; }
                    //public string FirstName { get; set; }
                    //public string Role { get; set; }







          }



}
