﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.ModelDTO
{
          public class ForgetPasswordUserDto
          {
                    //[Required(ErrorMessage = "Email is required.")]
                    //[EmailAddress(ErrorMessage = "Invalid Email Address.")]
                    //public string Email { get; set; }
                    [Required(ErrorMessage = "UserName is required.")]
                    //[EmailAddress(ErrorMessage = "Invalid UserName.")]
                    public string Username { get; set; }

                    [Required(ErrorMessage = "New Password is required.")]
                    [StringLength(100, MinimumLength = 6)]
                    [DataType(DataType.Password)]
                    public string NewPassword { get; set; }

                    [Required(ErrorMessage = "Please ConfirmNew your password.")]
                    [Compare("NewPassword", ErrorMessage = "The new password and ConfirmNewPassword  do not match.")]
                    public string ConfirmNewPassword { get; set; }
          }
         
}
