﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.ModelDTO
{
          public class Designaitondtomodel
          {
                    [Key]
                     public int id { get; set; }
                    [Required(ErrorMessage ="DesigantionName will be required")]
                    public string? DesignationName { get; set; } = null;
    }
}
