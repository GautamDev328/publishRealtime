﻿//namespace CRUDAPPLICATION.ModelDTO
//{
//          public class LoginResponseDTO
//          {
//                    public bool Success { get; set; }
//                    public string? Message { get; set; }
//                    public int? EmployeeId { get; set; }  // main id
//                    public string? Username { get; set; }
//                    public string? Role { get; set; }
//                    public string? FirstName { get; set; }  
//          }

//}
