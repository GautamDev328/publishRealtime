﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.ModelDTO
{
          public class ItemDTO
          {

                    //[Key]
                    //          public int Id { get; set; }
                    [Required(ErrorMessage = "SearchName will be required")]

                    public string Name { get; set; }
                             // public decimal Price { get; set; }
                    }

          }

