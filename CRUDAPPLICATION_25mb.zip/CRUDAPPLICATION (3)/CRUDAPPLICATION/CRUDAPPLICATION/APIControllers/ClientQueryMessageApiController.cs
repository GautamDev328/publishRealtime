﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientQueryMessageApiController : ControllerBase
    {
        private readonly ClientQureyMessageRepository clientQureyMessageRepository;
        public ClientQueryMessageApiController(ClientQureyMessageRepository _clientQureyMessageRepository)
        {
            this.clientQureyMessageRepository = _clientQureyMessageRepository;
        }
        [HttpGet("AllClientQueryMessageShow")]
        public List<ClientQuery> AllClientQueryMessage()
        {
            var list = clientQureyMessageRepository.AllClientQueryMessage();
            return list;
        }
        [HttpPost("CreateClientQueryMessage")]
        public void CreateCientQueryMessage(ClientQuery message)
        {
            clientQureyMessageRepository.CreateCientQueryMessage(message);
        }
        [HttpPut("UpdteClientQueryMessage")]
        public void UpdateCientQueryMessage(ClientQuery clientQueryMessage)
        {
            clientQureyMessageRepository.UpdateCientQueryMessage(clientQueryMessage);
        }

        [HttpDelete("DeleteClientQueryMessage")]
        public void DeleteCientQueryMessage(int id)
        {
            clientQureyMessageRepository.DeleteCientQueryMessage(id);

        }
        [HttpGet("DetailClientQueryMessage")]

        public ClientQuery DetailsClientQueryMessage(int id)
        {
            var client = clientQureyMessageRepository.DetailsClientQueryMessage(id);
            return client;
        }
                    [HttpGet("export-ClientQuery-to-excel")]
                    public IActionResult ExportClientQueryDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var ClientQueryDataExcelFile = clientQureyMessageRepository.AllClientQueryMessage();

                                        // Generate the Excel file from the data
                                        var excelFile = clientQureyMessageRepository.GenerateClientQueryExcelFile(ClientQueryDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "clientQuerys.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting clientQuery", error = ex.Message });
                              }
                    }

          }
}
