﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class BankApiController : ControllerBase
          {
                    private readonly BankRepository bankRepository;
                    private readonly DistrictNameRepository _districtNameRepository;
                    public BankApiController(BankRepository _bankRepository, DistrictNameRepository districtNameRepository)
                    {
                              this.bankRepository = _bankRepository;
                              this._districtNameRepository = districtNameRepository;
                    }
                    // ...

                    [HttpPost("AddBank")]
                    public async Task<IActionResult> AddBank(BankModel model)
                    {
                              //if (!ModelState.IsValid)
                              //{
                              //          return BadRequest(ModelState);
                              //}

                              //// ✅ First, check if the bank already exists with the same AccountNumber in the same Bank
                              //var existingBank = bankRepository.GetALLBank()
                              //    .FirstOrDefault(b => b.BankName == model.BankName &&
                              //                         b.AccountNumber == model.AccountNumber);

                              //if (existingBank != null && existingBank.IFSCCODE != model.IFSCCODE)
                              //{
                              //          return BadRequest("The Account Number and IFSC Code must match within the same bank.");
                              //}

                              // ✅ If no conflict, proceed with adding the new bank entry
                              bankRepository.AddBANK(model);
                              return Ok("Bank details added successfully!");
                    }

                    [HttpDelete("DeleteBank")]
                    public void DeleteRelationShip(int id)
                    {
                              bankRepository.DeleteRelationShip(id);
                    }
                    [HttpGet("BankDetails")]
                    public BankModel DetailsModel(int id)
                    {
                              var details = bankRepository.DetailsModel(id);
                              return details;
                    }
                    [HttpGet("AllBankList")]
                    public List<BankModel> GetALLBank()
                    {
                              var list = bankRepository.GetALLBank();
                              return list;
                    }
                    [HttpPut("UpdateBank")]
                    public void UpdateBANK(BankModel BNK1model)
                    {
                              bankRepository.UpdateBANK(BNK1model);

                    }
                    [HttpGet("export-Bank-to-excel")]
                    public IActionResult ExportBankDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var BankDataExcelFile = bankRepository.GetALLBank();

                                        // Generate the Excel file from the data
                                        var excelFile = bankRepository.GenerateBankExcelFile(BankDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "bankModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting bankModel", error = ex.Message });
                              }
                    }

                    //[HttpGet("GetDistrictsByState")]
                    //public IActionResult GetDistrictsByState(string stateName)
                    //{
                    //          var filteredDistricts =_districtNameRepository.lstdistrictmode.Where(d => d.StateName == stateName).ToList();
                    //          return Ok(filteredDistricts);
                    //}

          }
}
