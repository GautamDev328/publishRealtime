﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class OpenPositonAppliedAPIController : ControllerBase
          {
                    public readonly OpenPositonAppliedRepository open;
                    public OpenPositonAppliedAPIController(OpenPositonAppliedRepository _open)
                    {
                              this.open = _open;
                    }
                    [HttpPost("CreateOpenPosition")]
                    public IActionResult CreateOpenPosition(OpenPositonAppliedModelcs Openpositon)
                    {
                              open.CreateOpenPositon(Openpositon);
                              return Ok(1);


                    }

                    [HttpGet("ALLDATAOpenPosition")]
                    public List<OpenPositonAppliedModelcs> GetOpenPosition()
                    {
                              var listopen = open.GetAllOpenPositon();
                              return listopen;
                    }

                    [HttpPost("UpdateOpenPosition")]
                    public IActionResult UpdateOpenPosition(OpenPositonAppliedModelcs OpenPosition)
                    {
                              open.UpdateOpenPositon(OpenPosition);
                              return Ok(1);
                    }
                    [HttpGet("SearchById")]
                    public IActionResult SearchById(int id)
                    {
                              var a = open.SearchById(id);
                              return Ok(a);
                    }

                    [HttpGet("DetailsOpenPosition")]
                    public IActionResult DetailOpenPosition(int id)
                    {
                              var a = open.DetailOpenPositon(id);
                              return Ok(a);
                    }
                    [HttpDelete("DeleteOpenPosition")]
                    public IActionResult DeleteOpenPosition(int id)
                    {
                              open.DeleteOpenPositon(id);
                              return Ok(1);


                    }

                    [HttpGet("export-OpenPosition-to-excel")]
                    public IActionResult ExportOpenPositionModelToExcel()
                    {
                              try
                              {
                                        var interviewresps = open.GetAllOpenPositon(); // Fetch the list of cities
                                        var excelFile = open.GenerateOpenPositonExcelFile(interviewresps); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "interviewApplicationFormModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting interviewApplicationFormModels", error = ex.Message });
                              }
                    }

                  



                    
          }
}