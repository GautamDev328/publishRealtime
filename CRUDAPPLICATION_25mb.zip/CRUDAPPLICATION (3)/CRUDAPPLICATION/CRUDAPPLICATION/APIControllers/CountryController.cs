﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly CountryRepository countryRepository;
        public CountryController(CountryRepository _countryRepository)
        {
            this.countryRepository = _countryRepository;

        }
        [HttpPost("CreateCountry")]
        public void CreateCountry(Country country)
        {
            countryRepository.CreateCountry(country);

        }
        [HttpGet("GETCOUNTRYALL")]
        public List<Country> GETCOUNTRYALL()
        {
            var list = countryRepository.GETCOUNTRYALL();
            return list;
        }
        [HttpPut("UpdateCountry")]
        public IActionResult UpdateCountry(Country country)
        {
            countryRepository.UpdateCountry(country);
            return Ok(1);

        }
        [HttpDelete("DeleteCountry")]
        public IActionResult DeleteCountry(int id)
        {
            countryRepository.DeleteCountry(id);
            return Ok(1);

        }
        [HttpGet("DetailsCountry")]
        public Country DetailsCountry(int id)
        {
            var a = countryRepository.DetailsCountry(id);
            return a;

        }
                    [HttpGet("export-COuntry-to-excel")]
                    public IActionResult ExportCOuntryDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var CountryDataExcelFile = countryRepository.GETCOUNTRYALL();

                                        // Generate the Excel file from the data
                                        var excelFile = countryRepository.GenerateCountryExcelFile(CountryDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "countries.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting countries", error = ex.Message });
                              }
                    }




          }
}
