﻿//using CRUDAPPLICATION.BLL.Repository;
//using CRUDAPPLICATION.Model;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace CRUDAPPLICATION.APIControllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ForgetPasswordAPIController : ControllerBase
//    {
//        private readonly ForgetPasswordRepository forgetPasswordRepository;
//        public ForgetPasswordAPIController(ForgetPasswordRepository _forgetPasswordRepository)
//        {
//            this.forgetPasswordRepository = _forgetPasswordRepository;
//        }
//        [HttpGet("GetByEmail/{email}")]
//        public IActionResult GetByEmail(string email)
//        {
//            var user = forgetPasswordRepository.GetUserByEmail(email);
//            if (user == null)
//            {
//                return NotFound();
//            }
//            return Ok(user);
//        }

//        //[HttpGet("GetByPhone/{phone}")]
//        //public IActionResult GetByPhone(string phone)
//        //{
//        //    var user = _userService.GetUserByPhone(phone);
//        //    if (user == null)
//        //    {
//        //        return NotFound();
//        //    }
//        //    return Ok(user);
//        //}

//        [HttpPost("UpdatePassword")]
//        public IActionResult UpdatePassword(ForgetPassWord request)
//        {
//            if (request == null || string.IsNullOrEmpty(request.EmailOrPhone) || string.IsNullOrEmpty(request.NewPassword))
//            {
//                return BadRequest("Invalid request");
//            }

//            forgetPasswordRepository.Update(request.EmailOrPhone, request.NewPassword);
//            return Ok("Password updated successfully");
//        }
//    }

//}


