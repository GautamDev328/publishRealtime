﻿//using CRUDAPPLICATION.BLL;
using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [ApiController]

    [Route("api/[controller]")]
    // [ApiController]
    public class EmployeeProfileController : ControllerBase
    {

        private readonly EmployeeProfileRepository _employeeRepository;

        public EmployeeProfileController(EmployeeProfileRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }


        [HttpGet("ListAllData")]
        public List<EmployeeProfile> GetEmployees()
        {
            var a = _employeeRepository.GetAll();
            return a;
        }

        [HttpDelete("DeleteEmployee")]
        public void deleteEmployeeProfile(int id)
        {
            _employeeRepository.deleteEmployeeProfile(id);
        }

        [HttpPut("UpdateEmployee")]
        public void update(EmployeeProfile employeeProfile)
        {
            _employeeRepository.updateEmployeeProfile(employeeProfile);
           
        }

    

        [HttpPost("CreateEmployee")]
        public void  insert(EmployeeProfile employeeProfile)
        {
          
                _employeeRepository.Insert(employeeProfile);
             
        }
        [HttpGet("DetailsEmployee")]
        public EmployeeProfile DetailsEmployeeProfile(int id)
        {
            var emp=_employeeRepository.DetailsEmployeeProfile(id);
            return emp;
        }


                    // Employee Data Fetching 
                    [HttpGet("GetEmployeeDataFetch")]
                    public EmployeeDataDTO GetEmployeeData(int empid)
                    {
                              var empdatadto=_employeeRepository.getemployeedata(empid);
                              return empdatadto;
                    }

                    //Exprot Excel 

                    [HttpGet("export-EmployeeProfile-to-excel")]
                    public IActionResult ExportEmployeeProfileToExcel()
                    {
                              try
                              {
                                        var employeeProfiless = _employeeRepository.GetAll(); // Fetch the list of cities
                                        var excelFile = _employeeRepository.GenerateempllyeeprofilesExcelFile(employeeProfiless); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "employeeProfiles.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting employeeProfile", error = ex.Message });
                              }
                    }

          }
}


