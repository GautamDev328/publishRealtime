﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RelationController : ControllerBase
    {
        private readonly RELATIONREPOSITORY _relationRepository;
        public RelationController(RELATIONREPOSITORY relationRepository)
        {
            this._relationRepository = relationRepository;
          
        }
        [HttpPost("CreateRelation")]
        public void CreateRelaitonModel(RelationModel relationModel)
        {
            _relationRepository.CreateRelaitonModel(relationModel);

        }
        [HttpGet("ALLDATARelation")]
        public List<RelationModel> GetRelationModelAll()
        {
            var list = _relationRepository.GetRelationModelAll();
            return list;
        }
        [HttpDelete("DeleteRelation")]
        public void DeleteRelaitonModel(int id)
        {
            _relationRepository.DeleteRelaitonModel(id);

        }
        [HttpPut("UpdateRelation")]
        public void UpdateRelaitonModel(RelationModel relationModel)
        {
            _relationRepository.UpdateRelaitonModel(relationModel);

        }
        [HttpGet("DetailsRelation")]
        public RelationModel DetailsRelaitonModel(int id)
        {
            var a=_relationRepository.DetailsRelaitonModel(id);
            return a;
        }
       
    }
}
