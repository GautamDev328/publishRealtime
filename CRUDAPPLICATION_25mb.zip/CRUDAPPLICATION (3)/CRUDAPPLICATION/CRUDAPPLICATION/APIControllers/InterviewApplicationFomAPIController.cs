﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class InterviewApplicationFomAPIController : ControllerBase
          {
                    public readonly InterviewApplicationFomRepository interviewresp;

                    public InterviewApplicationFomAPIController(InterviewApplicationFomRepository _interviewresp)
                    {
                              this.interviewresp = _interviewresp;
                    }

                    [HttpGet("Alllistinterviewapplication")]
                    public List<InterviewApplicationFormModel> GetAllInterview()
                    {
                              var list = interviewresp.GetAllInterview();
                              return list;

                    }
                    //correct 
                    //create data 

                    [HttpPost("CreateInterviewApplication")]
                    public void Createinterviewapplicaiton(InterviewApplicationFormModel model)
                    {
                              interviewresp.Createinterviewapplicaiton(model);

                    }


           
         

                    [HttpPut("UpdateIntervieweApplication")]
                    public void Updateinterviewapplicaitony(InterviewApplicationFormModel models)
                    {
                              interviewresp.Updateinterviewapplicaitony(models);

                    }
                    [HttpDelete("DeleteInterviewApplication")]
                    public void Deleteinterviewapplicaitony(int id)
                    {
                              interviewresp.Deleteinterviewapplicaitony(id);

                    }
                    [HttpGet("DetailsInterviewApplcation")]
                    public InterviewApplicationFormModel Detailinterviewapplicaitony(int id)
                    {
                              var details = interviewresp.Detailinterviewapplicaitony(id);
                              return details;
                    }
                    [HttpGet("SearchInterviewApplcation")]

                    public InterviewApplicationFormModel SearchById(int id)
                    {
                              var search = interviewresp.SearchById(id);
                              return search;
                    }




                    //Exprot Excel 

                    [HttpGet("export-InterviewApplicationForm-to-excel")]
                    public IActionResult ExportInterviewApplicationFormModelToExcel()
                    {
                              try
                              {
                                        var interviewresps = interviewresp.GetAllInterview(); // Fetch the list of cities
                                        var excelFile = interviewresp.GenerateinterviewapplicaitonyExcelFile(interviewresps); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "interviewApplicationFormModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting interviewApplicationFormModels", error = ex.Message });
                              }

                    }
                    [HttpGet("OpenmodelHiringfetchdata")]

                    public InterviewApplicationFormModel fetchdata(int fetchid)
                    {
                              var interviewapp= interviewresp.fetchdata(fetchid);
                              return interviewapp;          
                    }


          }
}
