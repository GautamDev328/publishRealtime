﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {
        private readonly StateRepository stateRepository;
        public StateController(StateRepository _stateRepository)
        {
            this.stateRepository = _stateRepository;
        }

        [HttpGet("ListAllData")]
        public List<StateModel> states()
        {
            var a = stateRepository.states();
            return a;
        }
        [HttpPost("CreateState")]
        public void CreateState(StateModel state)
        {
            stateRepository.CreateState(state);
            //  return Ok(1);

        }
        [HttpPut("UpdateState")]
        public void UpdateState(StateModel state)
        {
            stateRepository.UpdateState(state);

        }
        [HttpDelete("DeleteState")]
        public void DeleteState(int id)
        {
            stateRepository.DeleteState(id);
        }
        [HttpGet("DetailState")]
        public StateModel DetailsState(int id)
        {
            var states=stateRepository.DetailsState(id);
            return states;  
        }
                    [HttpGet("export-state-to-excel")]
                    public IActionResult ExportCitiesToExcel()
                    {
                              try
                              {
                                        var cities = stateRepository.states(); // Fetch the list of cities
                                        var excelFile = stateRepository.GenerateCitiesExcelFile(cities); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Cities.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting cities", error = ex.Message });
                              }

                    }


          }

}