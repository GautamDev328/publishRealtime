﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace CRUDAPPLICATION.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomePaymentAPIController : ControllerBase
    {
      private readonly string connectionString = "Server=DESKTOP-HH8FI1T\\SQLEXPRESS;Database=DataSystem;Integrated Security=True;Encrypt=false;TrustServerCertificate=True;";

        private readonly CustomerPaymentRepository customePaymentRepository;
        public CustomePaymentAPIController(CustomerPaymentRepository _customePaymentRepository)
        {
            this.customePaymentRepository = _customePaymentRepository;
        }
        [HttpGet("AllPaymentDataList")]
        public List<PaymentCustomerExtraUserModel> GetAllPaymewntCustomer()
        {
            var list = customePaymentRepository.GetAllPaymewntCustomer();
            return list;
        }

        [HttpPut("UpdatePaymentData")]
        public void UpdatePaymentCustomer(PaymentCustomerExtraUserModel paymentCustomerExtraUser)
        {

            customePaymentRepository.UpdatePaymentCustomer(paymentCustomerExtraUser);

        }

        [HttpGet("SearchPaymentData")]
        public PaymentCustomerExtraUserModel SearchPaymentUser(int id)
        {
            var search = customePaymentRepository.SearchPaymentUser(id);
            return search;
        }
        [HttpPost("CreatePaymentCustomer")]
        public IActionResult InsertPaymentCustomer(PaymentCustomerExtraUserModel paymentCustomerExtraUser)
        {
            //customePaymentRepository.InsertPaymentCustomer(paymentCustomerExtraUser);
            //return Ok(1);
            //var newPaymentCustomer = new PaymentCustomerExtraUserModel
            //{
            //    Device_Serials = paymentCustomerExtraUser.Device_Serials
            //};

            // Insert the new instance into the repository
            customePaymentRepository.InsertPaymentCustomer(paymentCustomerExtraUser);

            return Ok(1);

        }


        [HttpGet]
        [Route("api/getTotalPaidAmount")]
        public IActionResult GetTotalPaidAmount()
        {
            decimal result = 0;

            using (var conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CalculateAmount", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    // Execute the command and read the result
                    var resultObj = cmd.ExecuteScalar();
                    if (resultObj != null)
                    {
                        // Safely convert the result to decimal
                        decimal tempResult;
                        if (decimal.TryParse(resultObj.ToString(), out tempResult))
                        {
                            result = tempResult;
                        }
                        else
                        {
                            // Handle the case where conversion fails
                            return BadRequest("The result could not be converted to a decimal.");
                        }
                    }
                    else
                    {
                        return NotFound(); // Handle the case where no result is returned
                    }


                }
            }

            return Ok(result);
        }

                    [HttpGet("export-PaymentCustomer-to-excel")]
                    public IActionResult ExportPaymentCustomerDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var customerpaymentDataExcelFile = customePaymentRepository.GetAllPaymewntCustomer();

                                        // Generate the Excel file from the data
                                        var excelFile = customePaymentRepository.GenerateCcustomerpaymentExcelFile(customerpaymentDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "paymentCustomeExtraUserModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting paymentCustomeExtraUserModel", error = ex.Message });
                              }
                    }

          }

}



       