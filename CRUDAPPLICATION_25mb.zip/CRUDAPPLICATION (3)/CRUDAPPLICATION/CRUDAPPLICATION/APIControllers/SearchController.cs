﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class SearchController : ControllerBase
          {
                    private readonly SearchService _searchService;

                    public SearchController(SearchService searchService)
                    {
                           this._searchService = searchService;
                    }

                    //[HttpGet("SearchData")]
                    //public IActionResult Search(string query)   /*query*/
                    //{
                    //          if (string.IsNullOrEmpty(query))
                    //          {
                    //                    return BadRequest("Query parameter is required.");
                    //          }

                    //          var results = _searchService.SearchItems(query);

                    //          if (results == null || !results.Any())
                    //          {
                    //                    return NotFound("No items found.");
                    //          }

                    //          return Ok(results); // Return search results as JSON
                    //}

                    //[HttpGet("SearchData")]
                    //public IActionResult Search(string query)
                    //{
                    //          try
                    //          {
                    //                    var results = _searchService.SearchItems(query);

                    //                    if (!results.Any())
                    //                    {
                    //                              return NotFound("No items found.");
                    //                    }

                    //                    return Ok(results); // Return search results as JSON
                    //          }
                    //          catch (ArgumentException ex)
                    //          {
                    //                    return BadRequest(ex.Message); // Handle invalid input
                    //          }
                    //}


                    //[HttpGet("SearchData")]
                    //public IActionResult Search(string query)
                    //{
                    //          try
                    //          {
                    //                    // Log the received query
                    //                    Console.WriteLine($"Received search query: {query}");

                    //                    var results = _searchService.SearchItems(query);

                    //                    // Log the number of results found
                    //                    Console.WriteLine($"Number of results found: {results.Count()}");

                    //                    if (!results.Any())
                    //                    {
                    //                              return NotFound("No items found."); // Return 404 if no items found
                    //                    }

                    //                    return Ok(results); // Return search results as JSON
                    //          }
                    //          catch (ArgumentException ex)
                    //          {
                    //                    return BadRequest(ex.Message); // Handle invalid input
                    //          }
                    //}
                    [HttpGet("getAll")]
                    public  IActionResult SearchItems(string name)

                    {
                              var results = _searchService.SearchItems(name);
                              return Ok(results);
                    }


          }
}
