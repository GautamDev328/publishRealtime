﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ActionConstraints;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class Auot_CustomerhelpModelAPIController : ControllerBase
          {
                    public readonly Auot_CustomerhelpRepository auot;
        public Auot_CustomerhelpModelAPIController(Auot_CustomerhelpRepository _auto)
        {
                    this.auot = _auto;  
        }

        [HttpGet("AllCustomerHelper")]
                    public List<Auot_CustomerhelpModel> GetAllCustomers()
                    {
                              var allcustomer = auot.GetAllCustomer().ToList();
                              return allcustomer;
                    }

                    [HttpGet("DetailsCustomerHelper")]
                    public Auot_CustomerhelpModel DetailCustomerHelper(int id)
                    {
                              //var customer = await auot.GetCustomerByIdAsync(id);
                              //if (customer == null) return NotFound();

                              //return Ok(customer);
                              var details = auot.DetailCustomerHelper(id);
                              return  details;

                    }

                    [HttpPost("CreateCustomerHelper")]
                    public void CreateCustomerHelper(Auot_CustomerhelpModel Auot)
                    {
                              auot.CreateCustomerHelper(Auot);
                    }

                    [HttpPut("UpdateCustomerHelper")]
                    public void UpdateCustomerHelper(Auot_CustomerhelpModel Auot)
                    {
                              //if (id != customer.CustomerId) return BadRequest("Customer ID mismatch");

                              //await auot.UpdateCustomerAsync(customer);
                              //return NoContent();
                              auot.UpdateCustomerHelper(Auot);
                    }

                    [HttpDelete("DeleteCustomerHelper")]
                    public void DeleteCustomerHelper(int id)
                    {
                              auot.DeleteCustomerHelper(id);
                    }
          }
}
