﻿
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Math;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;


namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class RegisterationFormAPIController : ControllerBase
          {
                    private readonly RegisterationFormRepository registerationForms;
                    private readonly EmployeeProfileRepository employeeProfileRepository;
                  //  private const string SESSION_KEY_CAPTCHA = "CaptchaCode";
                    public RegisterationFormAPIController(RegisterationFormRepository _registerationFormRepository, EmployeeProfileRepository _emp)
                    {
                              this.registerationForms = _registerationFormRepository;
                              this.employeeProfileRepository = _emp;
                    }
                    [HttpGet("AllRegisterationForm")]
                    public List<RegisterationForm> GetAllRegisteration()
                    {
                              var list = registerationForms.GetAllRegisteration().ToList();
                              return list;
                    }
                    [HttpPost("CreateRegisterationForm")]
                    public void CreateRegistertaion(RegisterationForm registerationFormModel)
                    {
                              registerationForms.CreateRegistertaion(registerationFormModel);
                    }
                    [HttpGet("DetailsRegisteration")]
                    public RegisterationForm DetailRegisteration(int id)
                    {
                              var registeration = registerationForms.GetAllRegisteration(id);
                              return registeration;
                    }
                    [HttpPut("UpdateRegisteration")]
                    public void UpdateRegistertaion(RegisterationForm registertaion)
                    {
                              registerationForms.UpdateRegistertaion(registertaion);

                    }
                    [HttpDelete("DeleteRegisteration")]
                    public void DeleteRegistertaion(int id)
                    {
                              registerationForms.DeleteRegistertaion(id);

                    }
                    // Login form 

                    //[HttpPost("LoginPage")]
                    //public IActionResult LoginPage(RegisterationFromDTO model)
                    //{
                    //          var user = registerationForms.LoginPage(model.Username, model.Password);

                    //          if (user != null)
                    //          {
                    //                    return Ok(new { message = "Login successful" });
                    //          }
                    //          return Unauthorized(new { message = "Invalid username or password" });
                    //}



                    //[HttpPost("LoginPage")]
                    //public IActionResult LoginPage(RegisterationFromDTO model)
                    //{
                    //          List<string> errors = new List<string>();

                    //          if (string.IsNullOrWhiteSpace(model.Username))
                    //                    errors.Add("Username is required");

                    //          if (string.IsNullOrWhiteSpace(model.Password))
                    //                    errors.Add("Password is required");

                    //          if (errors.Count > 0)
                    //                    return BadRequest(new { errors });

                    //          var user = registerationForms.GetUserByUsername(model.Username);

                    //          if (user == null)
                    //                    errors.Add("Invalid username");
                    //          else if (user.Password.Trim() != model.Password.Trim())
                    //                    errors.Add("Invalid password");

                    //          if (errors.Count > 0)
                    //                    return Unauthorized(new { errors });

                    //          return Ok(new { message = "Login successful" });
                    //}
                    [HttpPost("LoginPage")]
                    public IActionResult LoginPage(RegisterationFromDTO model)
                    {
                              List<string> errors = new List<string>();

                              // Basic validation
                              if (string.IsNullOrWhiteSpace(model.Username))
                                        errors.Add("Username is required");

                              if (string.IsNullOrWhiteSpace(model.Password))
                                        errors.Add("Password is required");

                              if (errors.Count > 0)
                                        return BadRequest(new { errors });

                              // Get user from Registration table
                              var user = registerationForms.GetUserByUsername(model.Username);

                              if (user == null)
                                        errors.Add("Invalid username");
                              else if (user.Password.Trim() != model.Password.Trim())
                                        errors.Add("Invalid password");

                              if (errors.Count > 0)
                                        return Unauthorized(new { errors });

                              //// ✔ Employee Check: FirstName must match Username
                              //var employee = employeeProfileRepository.GetEmployeeByFirstName(user.Username);

                              //if (employee == null)
                              //          return BadRequest(new { errors = new List<string> { "Employee data not found" } });

                              //// SUCCESS RESPONSE
                              //return Ok(new
                              //{
                              //          message = "Login successful",
                              //          User = user,
                              //          Employee = employee
                              //});

                              // ✔ Find employee by matching FirstName = Username
                              var employee = employeeProfileRepository.DetailsEmployeeProfile(model.Username);

                              if (employee == null)
                              {
                                        return BadRequest(new { errors = new List<string> { "Employee data not found" } });
                              }

                              // ✔ Successful response
                              return Ok(new
                              {
                                        message = "Login successful",
                                        Employee = new
                                        {
                                                  employee.EmpId,
                                                  employee.FirstName,
                                                  employee.LastName,
                                                  employee.Emailid
                                        }
                              });
                    }

                    // forgetpassword check 
                    [HttpPost("ForgetPassword")]
                    public async Task<IActionResult> ResetPassword([FromBody] ForgetPasswordUserDto dto)
                    {
                              if (!ModelState.IsValid)
                                        return BadRequest(ModelState);

                              var isReset = await registerationForms.ResetPasswordAsync(dto);

                              if (!isReset)
                                        return NotFound("User  with the given New Password  and ConfirmNewPassword does not exist.");

                              return Ok("NewPassword and ConfirmNewPassword has been successfully ForgetPassword.");
                    }
                    [HttpPost("UserForget")]
                    public async Task<IActionResult> UserForget(UserForget dto1)
                    {
                              if (!ModelState.IsValid)
                                        return BadRequest(ModelState);

                              var isReset = await registerationForms.UserForgetAsync(dto1);

                              if (!isReset)
                                        return NotFound("User with the given User does not exist.");

                              return Ok("UserName has been successfully ForgetUser.");
                    }

                    //[HttpPost("login")]
                    //public IActionResult Login(RegisterationForm model)
                    //{
                    //          var user = registerationForms.LoginPage(model.Username, model.Password, model.LoginType).Result;

                    //          if (user == null)
                    //          {
                    //                    return Unauthorized("Invalid Username/Password or Incorrect Login Type");
                    //          }

                    //          return Ok(user);
                    //}


          }




}



