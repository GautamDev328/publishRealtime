﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HRAPIController : ControllerBase
    {
        private readonly HrRepository hRProfile;
        public HRAPIController(HrRepository _hRProfile)
        {
            this.hRProfile = _hRProfile;
        }
        [HttpPost("HRCreateDATA")]
        public void CreateHrProfile(HRProfile hrProfile)
        {
            hRProfile.CreateHrProfile(hrProfile);

        }


        [HttpGet("HRALLDATA")]
        public List<HRProfile> AllHrProfile()
        {
            var list = hRProfile.AllHrProfile().ToList();
            return list;
        }
        [HttpPut("UpdateAllData")]
        public void UpdateHrProfile(HRProfile hrProfile)
        {
            hRProfile.UpdateHrProfile(hrProfile);
        }
        [HttpGet("DetailAllData")]
        public HRProfile DetailHrProfile(int id)
        {
            var details=hRProfile.DetailHrProfile(id);  
            return details;
        }
        [HttpDelete("DeleteData")]
        public void DeleteHrProfile(int id)
        {
            hRProfile.DeleteHrProfile(id);
        }
        //[HttpPost("HrLoginData")]
        //public HrLoginDTO HRLoginPage(HrLoginDTO hrLoginDTO)
        //{

        //        var user = hRProfile.HRLoginPage(hrLoginDTO.Hr_Username, hrLoginDTO.Hr_Password);

        //        if (user != null)
        //        {
        //            return Ok(new { message = "Login successful" });
        //        }
        //        return Unauthorized(new { message = "Invalid username or password" });
        //    }


        //[HttpPost("HrLoginData")]
        //public IActionResult HRLoginPage(RegisterationFromDTO model)
        //{
        //    var user = hRProfile.(model.Username, model.Password);

        //    if (user != null)
        //    {
        //        return Ok(new { message = "HR Login successful" });
        //    }
        //    return Unauthorized(new { message = " HRLogin Invalid username or password" });
        //}

    }

}

