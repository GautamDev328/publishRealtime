﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using CsvExcelExportImport;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class BillingAPIController : ControllerBase
          {
                    private readonly BillingRepository billingRepository;
                    public BillingAPIController(BillingRepository _billingRepository)
                    {
                              this.billingRepository = _billingRepository;
                    }
                    [HttpDelete("DeleteBilling")]
                    public void DeleteBilling(int id)
                    {
                              billingRepository.DeleteBilling(id);
                    }
                    [HttpGet("DetailsBilling")]
                    public BillingModel DetailsBillingData(int id)
                    {
                              var details = billingRepository.DetailsBillingData(id);
                              return details;
                    }
                  


                

                    [HttpGet("AllBillingData")]
                    public List<BillingModel> GetAllBilling()
                    {
                              var list = billingRepository.GetAllBilling().ToList();
                              return list;
                    }
                    [HttpPost("CreateBilling")]
                    public void InsertBillingData(BillingModel billing)
                    {
                              billingRepository.InsertBillingData(billing);

                    }
                  


                    [HttpPut("UpdateBilling")]
                    public void UpdateBilling(BillingModel billing)
                    {
                              billingRepository.UpdateBilling(billing);
                    }
                    [HttpPost("CustomerInsertData")]
                    public void CustomerInsertData(CustomerdetailsModel customerdetails)
                    {
                              billingRepository.CustomerInsertData(customerdetails);
                    }
                    



                    [HttpGet("ListAllCustomer")]

                    public List<CustomerdetailsModel> GetAllCustomer()
                    {
                              var listcust = billingRepository.GetAllCustomer().ToList();
                              return listcust;
                    }
                    [HttpGet("BillingPrint")]
                    public CommonBillingVoucherDTO commonbilling(int id)
                    {
                              var voucher = billingRepository.commonbilling(id);
                              return voucher;
                    }
                    [HttpGet("export-Billing-to-excel")]
                    public IActionResult ExportBillingDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var BillingDataExcelFile = billingRepository.GetAllBilling();

                                        // Generate the Excel file from the data
                                        var excelFile = billingRepository.GenerateBillingExcelFile(BillingDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "billingModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting BillingData", error = ex.Message });
                              }
                    }



                    // GET: api/BillingAPI/7dayBillingData
                    //[HttpGet("7dayBillingData")]
                    //public List<BillingModel> GetAllBillingData()
                    //{
                    //          var sevenDaysAgo = DateTime.Now.AddDays(-7);

                    //          var billingData = billingRepository.GetBillingDataForLast7Days()
                    //              .Where(b => b.BillingDate.HasValue && b.ToString(billingData).Value >= sevenDaysAgo)
                    //              .ToList();

                    //          return billingData;
                    //}


                    // gets:customerid one by one fetch data



                    [HttpGet("OneFetchCustomerDetails")]

                    public CustomerdetailsModel GetCustomerById(int id)
                    {
                              //if (id <= 0) return BadRequest(new { message = "Invalid Customer ID" });

                              //var customer =  billingRepository.CustomerDetails(id); // Ensure this is async if DB call
                              //if (customer == null)
                              //{
                              //          return NotFound(new { message = "Customer not found" });
                              //}

                              //return Ok(new { customerName = customer.CustomerName ?? "N/A" });

                              var searchcustomer = billingRepository.CustomerDetails(id);
                              return searchcustomer;
                    }

                    [HttpDelete("DeleteCustomer")]
                    public void CustomerDeletes(int id)
                    {
                             billingRepository.CustomerDeletes(id);
                             // return delete;
                    }

                    [HttpPut("UpdateCustomer")]
                    public void UpdateCustomer(CustomerdetailsModel updatecusstomer)
                    {
                              billingRepository.UpdateCustomer(updatecusstomer);
                    }
                    //[HttpPost("CreateCustomerTypes")]
                    //public void CreateCustomerType(CustomerTypeModel customerType)
                    //{
                    //          billingRepository.CreateCustomerType(customerType);         
                    //}
                    //[HttpGet("AllListCustomertype")]

                    //public List<CustomerTypeModel> GetCustomerType()
                    //{
                    //          var listcustomertype= billingRepository.GetCustomerType();  
                    //          return listcustomertype;      
                    //}
          }

}
