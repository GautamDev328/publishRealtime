﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientApiController : ControllerBase
    {
        private readonly ClientRepository clientRepository;
        public ClientApiController(ClientRepository _clientRepository)
        {
             this.clientRepository = _clientRepository; 
        }
        [HttpGet("AllListData")]
        public List<ClientModel> Allclientmodel()
        {
            return clientRepository.Allclientmodel();
        }
        [HttpPost("CreateClinetData")]
        public void InsertClientmodel(ClientModel clientmodel)
        {
            clientRepository.InsertClientmodel(clientmodel);
        }
                    [HttpPut("UpdateClientmodel")]
                    public void UpdateClientmodel(ClientModel clientmodel)
                    {
                              clientRepository.UpdateClientmodel(clientmodel);
                    }
                    [HttpGet("DetailsClientmodel")]
                    public ClientModel DetailsClientmodel(int clientid)
                    {
                             var a=  clientRepository.DetailsClientmodel(clientid);
                              return a;

                    }
                    [HttpDelete("DeleteClientmodel")]

                    public void DeleteClientmodel(int clientid)
                    {
                          clientRepository.DeleteClientmodel(clientid);
                            
                    }
                    [HttpGet("export-client-to-excel")]
                    public IActionResult ExportClientDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var CLientDataExcelFile = clientRepository.Allclientmodel();

                                        // Generate the Excel file from the data
                                        var excelFile = clientRepository.GenerateClinetExcelFile(CLientDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "clientModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting clientModel", error = ex.Message });
                              }
                    }


          }
}
