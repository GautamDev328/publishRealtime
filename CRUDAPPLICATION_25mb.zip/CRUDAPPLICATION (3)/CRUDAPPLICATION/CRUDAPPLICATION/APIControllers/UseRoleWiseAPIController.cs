﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UseRoleWiseAPIController : ControllerBase
    {
        UseRoleRepository repository;
        public UseRoleWiseAPIController(UseRoleRepository _repository)
        {
            this.repository = _repository;

        }
        [HttpGet("AllDataUseRoleWise")]
        public List<UseRoleWiseModel> GetUseRoleWiseModels()
        {
            var list = repository.GetUseRoleWiseModels().ToList();
            return list;
        }
        [HttpGet("DetailsUseRoleWise")]
        public UseRoleWiseModel DetailsUseRole(int id)
        {
            var details = repository.DetailsUseRole(id);
            return details;
        }
        [HttpPut("UpdateUseRoleWise")]
        public void UpdateUseRole(UseRoleWiseModel useRole)
        {
            repository.UpdateUseRole(useRole);

        }
        [HttpPost("InsertUseRoleWise")]
        public void InsertUseRole(UseRoleWiseModel useRole)
        {
            repository.InsertUseRole(useRole);

        }
        [HttpDelete("DeleteUseRoleWise")]
        public void DeleteUseRole(int id)
        {
            repository.DeleteUseRole(id);
        }
    }
}
