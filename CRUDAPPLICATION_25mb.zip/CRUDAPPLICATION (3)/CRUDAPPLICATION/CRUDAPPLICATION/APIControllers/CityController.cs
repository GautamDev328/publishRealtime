﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly CityRepository cityRepository;
        public CityController(CityRepository _cityRepository)
        {
            this.cityRepository = _cityRepository;

        }
      
        [HttpPost("CREATECITY")]
        public IActionResult CreateCity(City city)
        {
            cityRepository.CreateCity(city);
            return Ok(1);


        }
        [HttpGet("ALLDATACITY")]
        public List<City> GetCities()
        {
            var list = cityRepository.GetCities();
            return list;
        }

        [HttpPost("UpdateCity")]
        public IActionResult UpdateCity(City city)
        {
            cityRepository.UpdateCity(city);
            return Ok(1);
        }
        [HttpGet("SearchById")]
        public IActionResult SearchById(int id)
        {
            var a = cityRepository.SearchById(id);
            return Ok(a);
        }
        [HttpGet("DetailsCity")]
        public IActionResult DetailCity(int id)
        {
            var a = cityRepository.DetailCity(id);
            return Ok(a);
        }
        [HttpDelete("DeleteCity")]
        public IActionResult DeleteCity(int id)
        {
            cityRepository.DeleteCity(id);
            return Ok(1);
        }
                    //Exprot Excel 

                    [HttpGet("export-cities-to-excel")]
                    public IActionResult ExportCitiesToExcel()
                    {
                              try
                              {
                                        var cities = cityRepository.GetCities(); // Fetch the list of cities
                                        var excelFile = cityRepository.GenerateCitiesExcelFile(cities); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Cities.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting cities", error = ex.Message });
                              }

                    }
                    //int cityId
                    //           && c.City_Id != cityId

                    //[HttpGet("CheckCityExists")]
                    // public IActionResult CheckCityExists(string cityName)
                    // {
                    //           var cityExists = cityRepository.GetCities().Any(c => c.City_Name == cityName).;
                    //           //if (cityExists != null)
                    //           //{
                    //           //          return Ok(true); // City exists
                    //           //}
                    //           return Ok(cityExists);
                    // }

                    [HttpGet("CheckCityExists")]
                    public IActionResult CheckCityExists(string cityName)
                    {
                              var cityExists = cityRepository.GetCities()
                                  .Any(c => c.City_Name.Equals(cityName, StringComparison.OrdinalIgnoreCase)); // Case-insensitive comparison

                              return Ok(cityExists);
                    }


          }
}
