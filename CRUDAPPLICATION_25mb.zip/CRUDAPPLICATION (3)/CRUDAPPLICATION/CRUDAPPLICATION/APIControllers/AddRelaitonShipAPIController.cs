﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class AddRelaitonShipAPIController : ControllerBase
          {
                    private readonly AddRelationShipRepository addRelationShipRepository;
                    public AddRelaitonShipAPIController(AddRelationShipRepository _addRelationShipRepository)
                    {
                              this.addRelationShipRepository = _addRelationShipRepository;
                    }
                    [HttpGet("ListAllRelation")]
                    public List<AddRelationShipModel> GetAddRelationShips()
                    {
                              var LIST = addRelationShipRepository.AllAddRelationShips().ToList();
                              return LIST;
                    }
                    [HttpPost("CreateAddRelation")]
                    public void AddRelationShip(AddRelationShipModel model)
                    {
                              addRelationShipRepository.AddRelationShip(model);

                    }
                    [HttpGet("DetailAddRelation")]
                    public AddRelationShipModel DetailsRelationship(int id)
                    {
                              var details = addRelationShipRepository.DetailsRelationship(id);
                              return details;
                    }
                    [HttpDelete("DeleteAddRelationShp")]
                    public void DeleteRelationShip(int id)

                    {
                              addRelationShipRepository.DeleteRelationShip(id);

                    }
                    [HttpPut("UpdateAddRelation")]
                    public void UpdateRealtionShip(AddRelationShipModel model)
                    {
                              addRelationShipRepository.UpdateRealtionShip(model);
                    }

          
          //Exprot Excel 
                    [HttpGet("export-AddRelation-to-excel")]
                    public IActionResult ExportaddrelationExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var addrelationData = addRelationShipRepository.AllAddRelationShips();

                                        // Generate the Excel file from the data
                                        var excelFile = addRelationShipRepository.GenerateaddrelationExcelFile(addrelationData);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "addRelationShipModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting addRelationShipModel", error = ex.Message });
                              }
                    }



          }
}
