﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class RescheduleDateInterviewOPENINGAPIController : ControllerBase
          {
                    public readonly RescheduleDateInterviewOPENINGRepository _rescheudedate;
        public RescheduleDateInterviewOPENINGAPIController(RescheduleDateInterviewOPENINGRepository rescheudedate)
        {
                              this._rescheudedate = rescheudedate;
        }

                    [HttpGet("Alllistrescheudedate")]
                    public List<RescheduleDateInterviewOPENINGMODEL> GetAllrescheudedate()//rescheudedate
                    {
                              var listrescheudedate = _rescheudedate.GetAllRescheduleDate();
                              return listrescheudedate;

                    }

                    [HttpPost("Createrescheudedate")]
                    public void Createrescheudedate(RescheduleDateInterviewOPENINGMODEL model)
                    {
                              _rescheudedate.CreateRescheduleDate(model);

                    }

                    [HttpPut("UpdateRescheduleDate")]
                    public void Updateinterviewapplicaitony(RescheduleDateInterviewOPENINGMODEL models)
                    {
                              _rescheudedate.UpdateRescheduleDate(models);

                    }
                    [HttpDelete("DeleteRescheduleDate")]
                    public void DeleteRescheduleDate(int id)
                    {
                              _rescheudedate.DeleteRescheduleDate(id);

                    }
                    [HttpGet("Detailsrescheudedate")]
                    public RescheduleDateInterviewOPENINGMODEL Detailrescheudedate(int id)
                    {
                              var detailsrescheudedate = _rescheudedate.DetailRescheduleDate(id);
                              return detailsrescheudedate;
                    }

                    [HttpGet("Searchrescheudedate")]

                    public RescheduleDateInterviewOPENINGMODEL SearchById(int id)
                    {
                              var searchrescheudedate = _rescheudedate.SearchById(id);
                              return searchrescheudedate;
                    }

                    //Exprot Excel 

                    [HttpGet("export-rescheudledate-to-excel")]
                    public IActionResult ExportrescheudedateToExcel()
                    {
                              try
                              {
                                        var interviewrescheudedate = _rescheudedate.GetAllRescheduleDate(); // Fetch the list of cities
                                        var excelFile = _rescheudedate.GenerateRescheduleDateExcelFile(interviewrescheudedate); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "rescheduleDates.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting rescheduleDates", error = ex.Message });
                              }
                    }
          }

}
