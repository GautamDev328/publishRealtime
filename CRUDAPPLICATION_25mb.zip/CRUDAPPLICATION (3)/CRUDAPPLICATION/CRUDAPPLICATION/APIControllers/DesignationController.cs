﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class DesignationController : ControllerBase
    {
        private readonly DesignationRepository _designationRepository;
        public DesignationController(DesignationRepository designationRepository)
        {
            this._designationRepository = designationRepository;

        }
        [HttpPost("CreateDesignation")]
        public void CreateDesignation(DesignationModel designationModel)
        {
            _designationRepository.CreateDesignation(designationModel);

        }
        [HttpGet("ALLDATADesignation")]
        public List<DesignationModel> GetALLDesignationData()
        {
            var list = _designationRepository.GetALLDesignationData();
            return list;
        }
        [HttpGet("DetailsDesignation")]
        public DesignationModel DetailsDesignationModel(int id)
        {
          return   _designationRepository.DetailsDesignationModel(id);
           
        }
        [HttpDelete("DeleteDesignation")]
        public void DeleteDesignationModel(int id)
        {
            _designationRepository.DeleteDesignationModel(id);  
        }
        [HttpPut("UpdateDesignation")]
        public void UpdateDesignationModel(DesignationModel designationModel)
        {
            _designationRepository.UpdateDesignationModel(designationModel);
        }

                    [HttpGet("GetDesignationsByDepartment/{departmentId}")]
                    public IActionResult GetDesignationsByDepartment(int departmentId)
                    {
                              var designations = _designationRepository.GetDesignationsByDepartment(departmentId);
                              if (designations == null || !designations.Any())
                              {
                                        return NotFound("No designations found for this department.");
                              }
                              return Ok(designations);
                    }


                    [HttpGet("export-Designation-to-excel")]
                    public IActionResult ExportDesignationDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var DesignationDataExcelFile = _designationRepository.GetALLDesignationData();

                                        // Generate the Excel file from the data
                                        var excelFile = _designationRepository.GenerateDesignationExcelFile(DesignationDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "designations.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting designation", error = ex.Message });
                              }
                    }


          }
}
