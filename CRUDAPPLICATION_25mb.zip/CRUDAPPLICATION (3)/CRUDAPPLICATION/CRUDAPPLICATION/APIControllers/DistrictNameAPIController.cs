﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class DistrictNameAPIController : ControllerBase
          {
                    public readonly DistrictNameRepository _districtname;
                    public readonly EmployeeDbContext _dbcontext;
                    public DistrictNameAPIController(DistrictNameRepository districtNameRepository,EmployeeDbContext dbcontext)
                    {
                                      this._districtname= districtNameRepository;
                              this._dbcontext = dbcontext;
                    }
                    [HttpGet("AllListDistrict")]
                    public List<DistrictNameModel> listdistrictmode()
                    {
                              var list = _districtname.lstdistrictmode();
                              return list;        
                    }
                    [HttpPost("CreateDistrict")]
                    public void CreateDistrict(DistrictNameModel objdistrictname)
                    {
                              _districtname.CreateDistrict(objdistrictname);
                              
                    }
                    [HttpDelete("DeleteDistrict")]
                    public void DeleteDistrict(int id)
                    {
                              _districtname.DeleteDistrict(id);
                            

                    }
                    [HttpPut("UpdateDistrict")]
                    public void UpdateDistrict(DistrictNameModel objdistrictname)
                    {
                              _districtname.UpdateDistrict(objdistrictname);

                    }
                    [HttpGet("DetailsDistrict")]
                    public DistrictNameModel DetailsDistrict(int id)
                    {
                              var details=_districtname.DetailsDistrict(id);    
                              return details;     
                    }


                    [HttpGet("GetDistrictsByStateName")]
                    public IActionResult GetDistrictsByStateName(string stateName)
                    {
                              if (string.IsNullOrEmpty(stateName))
                              {
                                        return BadRequest("Invalid state name.");
                              }

                              var districts = _dbcontext.districtNameModelss
                                                      .Where(d => d.StateName == stateName)
                                                      .Select(d => new { d.DistrictId, d.DistrictName })
                                                      .ToList();

                              return Ok(districts);
                    }

          }
}
