﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeQueryController : ControllerBase
    {
        private readonly EmployeeQueryRepository employeeQueryRepository;
        public EmployeeQueryController(EmployeeQueryRepository _employeeQueryRepository)
        {

            this.employeeQueryRepository = _employeeQueryRepository;
        }
        [HttpGet("GetEmployeeQueryAll")]
        public List<EmployeeQuery> GetEmployeeQueryAll()
        {
            var list = employeeQueryRepository.GetEmployeeQueryAll();
            return list;
        }
        [HttpPost("CreateemployeeQuery")]

        public void CreateEmployeeQuery(EmployeeQuery employeeQuery)
        {

            employeeQueryRepository.CreateEmployeeQuery(employeeQuery);
        }
        [HttpGet("DetailsEmployeeQuery")]
        public EmployeeQuery DetailsEmployeeQuery(int id)
        {
            return employeeQueryRepository.DetailsEmployeeQuery(id);

        }
        [HttpDelete("DeleteEmployeeQuery")]
        public void DeleteEmployeeQuery(int id)
        {
            employeeQueryRepository.DeleteEmployeeQuery(id);

        }
        [HttpPut("UpdateEmployeeQuery")]
        public void UpdateEmployeeQuery(EmployeeQuery employeeQuery)
        {
            employeeQueryRepository.UpdateEmployeeQuery(employeeQuery);
        }

                    //Exprot Excel 

                    [HttpGet("export-EmployeeQuery-to-excel")]
                    public IActionResult ExportCitiesToExcel()
                    {
                              try
                              {
                                        var EmployeeQuerys = employeeQueryRepository.GetEmployeeQueryAll(); // Fetch the list of cities
                                        var excelFile = employeeQueryRepository.GenerateEmployeeQueryExcelFile(EmployeeQuerys); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "employeeQuery.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting employeeQuery", error = ex.Message });
                              }
                    }


          }

}
