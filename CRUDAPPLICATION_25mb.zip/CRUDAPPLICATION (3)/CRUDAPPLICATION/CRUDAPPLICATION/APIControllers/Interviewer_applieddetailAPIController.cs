﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class Interviewer_applieddetailAPIController : ControllerBase
          {
                    public readonly Interviewer_applieddetailRepository interviewdetails;
        public Interviewer_applieddetailAPIController(Interviewer_applieddetailRepository _interviewdetails)
        {
                    this.interviewdetails = _interviewdetails;
        }

                    [HttpGet("Alllistinterviewdetails")]//interviewdetails
                    public List<Interviewer_applieddetail_Models> Alllistinterviewdetails()
                    {
                              var listinterviewdetails = interviewdetails.GetAllInterviewer_applieddetail();
                              return listinterviewdetails;

                    }

                    [HttpPost("Createinterviewdetails")]
                    public void Createinterviewdetails(Interviewer_applieddetail_Models model)
                    {
                              interviewdetails.CreateInterviewer_applieddetail(model);

                    }
                    [HttpPut("Updateinterviewdetailsn")]
                    public void Updateinterviewdetails(Interviewer_applieddetail_Models models)
                    {
                              interviewdetails.UpdateInterviewer_applieddetail(models);

                    }


                    [HttpDelete("Deleteinterviewdetails")]
                    public void Deleteinterviewdetails(int id)
                    {
                              interviewdetails.DeleteInterviewer_applieddetail(id);

                    }

                    [HttpGet("Detailsinterviewdetails")]
                    public Interviewer_applieddetail_Models Detailinterviewapplicaitony(int id)
                    {
                              var detailsinterviewdetails = interviewdetails.DetailInterviewer_applieddetail(id);
                              return detailsinterviewdetails;
                    }

                    [HttpGet("Searchinterviewdetails")]

                    public Interviewer_applieddetail_Models SearchById(int id)
                    {
                              var search = interviewdetails.SearchById(id);
                              return search;
                    }

                    //Exprot Excel 

                    [HttpGet("export-interviewdetails-to-excel")]
                    public IActionResult ExportInterviewApplicationFormModelToExcel()
                    {
                              try
                              {
                                        var interviewdetailss = interviewdetails.GetAllInterviewer_applieddetail(); // Fetch the list of cities
                                        var excelFile = interviewdetails.GenerateInterviewer_applieddetailExcelFile(interviewdetailss); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "interviewer_applieddetailModels.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting interviewer_applieddetailModels", error = ex.Message });
                              }
                    }
          }
}
