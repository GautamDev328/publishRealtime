﻿using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class HighQualificationAPIController : ControllerBase
          {
                    private readonly HighestQualificaitonRepository _highestQualificaitonRepository;
        public HighQualificationAPIController(HighestQualificaitonRepository highestQualificaitonRepository)
        {
                    this._highestQualificaitonRepository = highestQualificaitonRepository;          
        }
                    [HttpPost("AddHighestQualification")]   
                    public void AddHighestQualification(HigherQualificationModel higherQualificationModel)
                    {
                              _highestQualificaitonRepository.AddHighestQualification(higherQualificationModel);
                    }
                    [HttpGet("AllHighestQualification")]    
                    public List<HigherQualificationModel> AllHighestQualification()
                    {
                                 return _highestQualificaitonRepository.AllHighestQualification().ToList();
                    }
                    [HttpDelete("DeleteHighestQualification")]
                    public HigherQualificationModel DeleteHighestQualificationById(int id)
                    {
                              return _highestQualificaitonRepository.DeleteHighestQualificationById(id);
                    }         

                    [HttpGet("DetailsHighestQualification")]
                    public HigherQualificationModel DetailsHighestQualificationById(int id)
                    {
                              return _highestQualificaitonRepository.DetailsHighestQualificationById(id);
                    }
                    [HttpPut("UpdateHighestQualification")]
                    public void UpdateHighestQualification(HigherQualificationModel higherQualificationModel)
                    {
                              _highestQualificaitonRepository.UpdateHighestQualification(higherQualificationModel);
                    }

    }
}
