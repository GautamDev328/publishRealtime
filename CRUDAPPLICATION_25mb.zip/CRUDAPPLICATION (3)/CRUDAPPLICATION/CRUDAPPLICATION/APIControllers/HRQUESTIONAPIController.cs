﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.APIControllers
{
          [Route("api/[controller]")]
          [ApiController]
          public class HRQUESTIONAPIController : ControllerBase
          {
                    private readonly HRQUESTIONREPOSITORY _hrquestion;
        public HRQUESTIONAPIController(HRQUESTIONREPOSITORY hrquestion)
        {
                              this._hrquestion = hrquestion;          
                    
        }
                    [HttpPost("AddHRQUESTION")]
                    public void AddHRQUESTIONMODEL(HRQUESTIONMODEL hRQUESTIONMODEL)
                    {
                             _hrquestion.AddHRQUESTIONMODEL(hRQUESTIONMODEL);

                    }
                    [HttpDelete("DeleteHRQUESTION")]
                    public void DeleteHRQUESTIONMODEL(int id)
                    {
                              _hrquestion.DeleteHRQUESTIONMODEL(id);  
                    }
                    [HttpGet("DetailsHRQuestion")]
                    public HRQUESTIONMODEL DetailsHRQUESTIONMODEL(int id)
                    {
                            var details=  _hrquestion.DetailsHRQUESTIONMODEL(id); 
                              return details;
                    }
                    [HttpGet("GetHRQUESTION")]
                    public List<HRQUESTIONMODEL> GetHRQUESTIONMODEL()
                    {
                              var list=_hrquestion.GetHRQUESTIONMODEL();
                              return list;
                    }
                    [HttpPut("UpdateHRQUESTION")]
                    public void UpdateHRQUESTIONMODEL(HRQUESTIONMODEL hRQUESTIONMODEL)
                    {
                              _hrquestion.UpdateHRQUESTIONMODEL(hRQUESTIONMODEL);         
                    }
                    [HttpGet("export-GeneratesHRQUESTIONExcelFile-to-excel")]

                    public IActionResult GeneratesHRQUESTIONExcelFile()
                    {
                              try
                              {
                                        var hrquestions = _hrquestion.GetHRQUESTIONMODEL(); // Fetch the list of cities
                                        var excelFile =_hrquestion.GeneratesHRQUESTIONExcelFile(hrquestions); // Generate Excel file

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "HRQUESTIONMODELs.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting HRQUESTIONMODELs", error = ex.Message });
                              }
                    }
    }
}
