﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.BLL.Repository;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        public  readonly DepartmentRepository _DepartmentRepository;
        public DepartmentController(DepartmentRepository DepartmentRepository)
        {
            this._DepartmentRepository = DepartmentRepository;
        }

                    [HttpPost("CreateDepartment")]
                    public void CreateDepartment(Department model)
                    {
                              _DepartmentRepository.CreateDepartment(model);
                    }
                              

        
        [HttpGet("ALLDATADepartment")]
        public List<Department> GetAllDepartmentData()
         {
            var list = _DepartmentRepository.GetAllDepartmentData();
            return list;
        }
        [HttpPut("UpdateDepartment")]
        public void  UpdateDepartment(Department department)
        {
            _DepartmentRepository.UpdateDepartment(department);

            


        }
        [HttpDelete("DeleteDepartments")]
        public void DeleteDepartments(int id)
        {
            _DepartmentRepository.DeleteDepartment(id);
             

        }
        [HttpGet("DetailDepartment")]
        public Department DetailsDepartments(int id)
        {
            var dep=_DepartmentRepository.DetailsDepartments(id);
            return dep;
        }

                    [HttpGet("export-Billing-to-excel")]
                    public IActionResult ExportDepartmentDataExcelFile()
                    {
                              try
                              {
                                        // Fetch the data for the Excel file
                                        var DepartmentDataExcelFile = _DepartmentRepository.GetAllDepartmentData();

                                        // Generate the Excel file from the data
                                        var excelFile = _DepartmentRepository.GenerateDepartmentExcelFile(DepartmentDataExcelFile);

                                        // Return the file as a response
                                        return File(excelFile, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "department.xlsx");
                              }
                              catch (Exception ex)
                              {
                                        return StatusCode(500, new { message = "Error exporting department", error = ex.Message });
                              }
                    }



          }

}
