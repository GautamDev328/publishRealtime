﻿//using EFCore.BulkExtensions;
//using Entity;
//using Entity.Models;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Configuration;
//using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
//using System.Data;
//using Dapper;
//using System.Reflection;
//using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
//using System.Text;
//using WEBGSTCore;

//namespace DALC
//{

//    public class GenericRepository<T> : IGenericRepository<T> where T : BaseEntity
//    {
//        protected readonly ApplicationDbContext dbcontext;
//        protected DbSet<T> entities;
//        private readonly string constring;
//        private Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction? dbContextTransaction;
//        public GenericRepository(ApplicationDbContext _dbcontext, Microsoft.Extensions.Configuration.IConfiguration _con)
//        {
//            DatabaseHelper.con = _con;
//            // constring = _dbcontext.Database.GetConnectionString();
//            //_con.GetConnectionString("WebtelConnection");
//            constring = DatabaseHelper.GetCompConnectionString();
//            dbcontext = _dbcontext;
//            dbcontext.Database.SetConnectionString(constring);
//            entities = dbcontext.Set<T>();

//        }
//        //public GenericRepository(ApplicationDbContext _dbcontext)
//        //{

//        //    dbcontext = _dbcontext;
//        //    entities = dbcontext.Set<T>();

//        //}

//        //public void Insert(T entity)
//        //{
//        //    //entities.Add(entity);
//        //    //dbcontext.SaveChanges();
//        //    if (entity.Id == 0)
//        //    {
//        //        entities.Add(entity);
//        //        dbcontext.SaveChanges();
//        //        //  var IdProperty = entity.GetType().GetProperty("Id").GetValue(entity, null);
//        //        // return entities.SingleOrDefault(s => s.Id ==entity.Id);
//        //        long id = entity.Id;
//        //    }
//        //    else
//        //    {
//        //        entities.Update(entity);
//        //        dbcontext.SaveChanges();
//        //    }
//        //}
//        public long Insert(T entity)
//        {
//            if (entity.Id == 0)
//            {
//                entities.Add(entity);
//                dbcontext.SaveChanges();
//                //  var IdProperty = entity.GetType().GetProperty("Id").GetValue(entity, null);
//                // return entities.SingleOrDefault(s => s.Id ==entity.Id);
//                long id = entity.Id;
//                return id;
//            }
//            else
//            {
//                entities.Update(entity);
//                dbcontext.SaveChanges();
//                long id = entity.Id;
//                return id;
//            }
            
//        }

//        public void Insert(IEnumerable<T> entity)
//        {
//            if (entity == null)
//            {
//                throw new ArgumentNullException("Entity Missing");
//            }
//            else if (entity.Count() == 0)
//            {
//                throw new ArgumentNullException("Entity Missing");
//            }
//            if (entity.Count() > 0)
//            {
//                this.dbcontext.Database.SetCommandTimeout(500);
//                using (this.dbContextTransaction = this.dbcontext.Database.BeginTransaction())
//                {
//                    entities.AddRange(entity);
//                    this.dbcontext.SaveChanges();
//                    this.dbContextTransaction.Commit();
//                }
//            }
//        }

//        public void BulkInsert(List<T> entity)
//        {
//            if (entity == null)
//            {
//                throw new ArgumentNullException("Entity Missing");
//            }
//            else if (entity.Count() == 0)
//            {
//                throw new ArgumentNullException("Entity Missing");
//            }
//            if (entity.Count() > 0)
//            {
//                using (this.dbContextTransaction = this.dbcontext.Database.BeginTransaction())
//                {
//                    this.dbcontext.BulkInsert(entity, i => i.IncludeGraph = true);
//                    this.dbContextTransaction.Commit();
//                }
//            }
//        }

//        public T GetData(long id)
//        {
//            return entities.SingleOrDefault(s => s.Id == id);
//        }

//        public long Update(T entity)
//        {
//            if (entities == null)
//            {
//                throw new ArgumentNullException("Entity missing");
//            }
//            else
//            {
//                entities.Update(entity);
//                dbcontext.SaveChanges();
//                long id = entity.Id;
//                return id;
//            }
//        }

//        public void Remove(T entity)
//        {
//            if (entity == null)
//            {
//                throw new ArgumentNullException("Entity Missing");
//            }
//            else
//            {
//                entities.Remove(entity);
//                dbcontext.SaveChanges();
//            }
//        }

//        public void Savechanges()
//        {
//            dbcontext.SaveChanges();
//        }

//        //public void Update(T entity)
//        //{
//        //    if (entity == null)
//        //    {
//        //        throw new ArgumentNullException("Entity Missing");
//        //    }
//        //    else
//        //    {
//        //        entities.Update(entity);
//        //        dbcontext.SaveChanges();
//        //    }
//        //}

//        public void BulkInsertDapper(IEnumerable<T> entity)
//        {
//            string InsertQuery = "INSERT INTO " + typeof(T).GetTypeInfo().Name + " ( ";
//            PropertyInfo[] propertyInfos = typeof(T).GetProperties();
//            bool isFirst = true;
//            foreach (PropertyInfo propertyInfo in propertyInfos)
//            {
//                if (propertyInfo.Name.ToLower() == "id")
//                    continue;
//                InsertQuery = InsertQuery + (isFirst == false ? " , " : "") + propertyInfo.Name;
//                isFirst = false;
//            }
//            InsertQuery = InsertQuery + ") Values ";

//            using (IDbConnection con = new MySqlConnector.MySqlConnection(constring))
//            {
//                con.Open();
//                int parcount = 1;
//                bool IsFirstLine = true;
//                int RecordCount = 1;
//                StringBuilder query = new StringBuilder();
//                query.Append("");
//                bool IsRecordExist = false;
//                var parameters = new DynamicParameters();
//                foreach (T objmodel in entity)
//                {
//                    if (!IsFirstLine)
//                        query.Append(" , ");
//                    else
//                        IsFirstLine = false;
//                    query.Append(" (");
//                    isFirst = true;
//                    foreach (var prop in propertyInfos)
//                        if (prop.GetIndexParameters().Length == 0)
//                        {
//                            if (prop.Name.ToLower() == "id")
//                                continue;
//                            query = query.Append((isFirst == false ? " , " : " ") + "?args_" + prop.Name + parcount.ToString());
//                            parameters.Add("?args_" + prop.Name + parcount.ToString(), prop.GetValue(objmodel));
//                            //Console.WriteLine("   {0} ({1}): {2}", prop.Name,
//                            //                  prop.PropertyType.FullName,
//                            //                  prop.GetValue(objmodel));
//                            isFirst = false;
//                        }
//                    //else
//                    //    Console.WriteLine("   {0} ({1}): <Indexed>", prop.Name,
//                    //                      prop.PropertyType.Name);

//                    //   parameters.Add("DisplayName", objmodel.DisplayName);
//                    // parameters.Add("TIN", objmodel.DisplayName, DbType.String);
//                    query.Append(" )");
//                    parcount += 1;
//                    IsRecordExist = true;
//                    if (RecordCount == 100)
//                    {
//                        con.Execute(InsertQuery + query.ToString(), parameters);
//                        RecordCount = 1;
//                        query = new StringBuilder();
//                        parameters = new DynamicParameters();
//                        IsFirstLine = true;
//                        parcount = 1;
//                        IsRecordExist = false;
//                    }
//                    else
//                        RecordCount += 1;
//                }
//               if(IsRecordExist) con.Execute(InsertQuery + query.ToString(), parameters);
//                con.Close();
//                query = null;
//            }
//        }

//        public void BulkInsertDapper1(IEnumerable<gst_partymaster> entity)
//        {
//            string InsertQuery = "INSERT INTO " + typeof(gst_partymaster).GetTypeInfo().Name + " ( ";
//            PropertyInfo[] propertyInfos = typeof(gst_partymaster).GetProperties();
//            bool isFirst = true;
//            foreach (PropertyInfo propertyInfo in propertyInfos)
//            {
//                if (propertyInfo.Name.ToLower() == "id")
//                    continue;
//                InsertQuery = InsertQuery + (isFirst == false ? " , " : "") + propertyInfo.Name;
//                isFirst = false;
//            }
//            InsertQuery = InsertQuery + ") Values ";

//            using (IDbConnection con = new MySqlConnector.MySqlConnection(constring))
//            {
//                con.Open();
//                int parcount = 1;
//                bool IsFirstLine = true;
//                int RecordCount = 1;
//                StringBuilder query = new StringBuilder();
//                query.Append("");
//                bool IsRecordExist = false;
//                var parameters = new DynamicParameters();
//                foreach (gst_partymaster objmodel in entity)
//                {
//                    if (!IsFirstLine)
//                        query.Append(" , ");
//                    else
//                        IsFirstLine = false;
//                    query.Append(" (");
//                    isFirst = true;
//                    foreach (var prop in propertyInfos)
//                        if (prop.GetIndexParameters().Length == 0)
//                        {
//                            if (prop.Name.ToLower() == "id")
//                                continue;
//                            query = query.Append((isFirst == false ? " , " : " ") + "?args_" + prop.Name + parcount.ToString());
//                            parameters.Add("?args_" + prop.Name + parcount.ToString(), prop.GetValue(objmodel));
//                            //Console.WriteLine("   {0} ({1}): {2}", prop.Name,
//                            //                  prop.PropertyType.FullName,
//                            //                  prop.GetValue(objmodel));
//                            isFirst = false;
//                        }
//                    //else
//                    //    Console.WriteLine("   {0} ({1}): <Indexed>", prop.Name,
//                    //                      prop.PropertyType.Name);

//                    //   parameters.Add("DisplayName", objmodel.DisplayName);
//                    // parameters.Add("TIN", objmodel.DisplayName, DbType.String);
//                    query.Append(" )");
//                    parcount += 1;
//                    IsRecordExist = true;
//                    if (RecordCount == 100)
//                    {
//                        con.Execute(InsertQuery + query.ToString(), parameters);
//                        RecordCount = 1;
//                        query = new StringBuilder();
//                        parameters = new DynamicParameters();
//                        IsFirstLine = true;
//                        parcount = 1;
//                        IsRecordExist = false;
//                    }
//                    else
//                        RecordCount += 1;
//                }
//                if (IsRecordExist) con.Execute(InsertQuery + query.ToString(), parameters);
//                con.Close();
//                query = null;
//            }
//        }
//        public List<T> GetAllData()
//        {
//            return entities.ToList();
//        }
//        public IEnumerable<T> GetAll()
//        {
//            return entities.AsEnumerable();
//        }
//        public void Remove(long id)
//        {
//            entities.Remove(entities.Where(s=>s.Id==id).FirstOrDefault());
//            dbcontext.SaveChanges();
//        }
//        public long InsertDapper(T entity, IDbConnection con, int DeleteType = 0)
//        {
//            long RecordId = entity.Id;
//            try
//            {
//                if (entity.Id == 0)
//                {
//                    string InsertQuery = "";
//                    InsertQuery = "INSERT INTO " + typeof(T).GetTypeInfo().Name + " ( ";
//                    StringBuilder query = new StringBuilder();
//                    query.Append("");
//                    PropertyInfo[] propertyInfos = typeof(T).GetProperties();
//                    bool isFirst = true;
//                    var parameters = new DynamicParameters();
//                    int parcount = 1;
//                    foreach (PropertyInfo propertyInfo in propertyInfos)
//                    {
//                        if ((propertyInfo.Name.ToLower() == "id") || (propertyInfo.PropertyType.Name == "List`1") || (propertyInfo.PropertyType.BaseType == typeof(Entity.BaseEntity)))
//                            continue;
//                        InsertQuery = InsertQuery + (isFirst == false ? " , " : "") + propertyInfo.Name;
//                        if (isFirst)
//                            query.Append(" (");
//                        query = query.Append((isFirst == false ? " , " : " ") + "@" + propertyInfo.Name + parcount.ToString());
//                        parameters.Add("@" + propertyInfo.Name + parcount.ToString(), propertyInfo.GetValue(entity));

//                        isFirst = false;
//                    }
//                    InsertQuery = InsertQuery + ") Values ";
//                    query.Append(" );");
//                    if (DatabaseHelper.DatabaseType == 2)
//                        query.Append("SELECT SCOPE_IDENTITY();");
//                    else
//                        query.Append("Select LAST_INSERT_ID();");
//                    RecordId = con.QueryFirst<long>(InsertQuery + query.ToString(), parameters);
//                }
//                else
//                {
//                    if (DeleteType == 0)
//                    {
//                        string UPDATEQuery = "";
//                        UPDATEQuery = "UPDATE " + typeof(T).GetTypeInfo().Name + " SET  ";
//                        PropertyInfo[] propertyInfos = typeof(T).GetProperties();
//                        bool isFirst = true;
//                        var parameters = new DynamicParameters();
//                        int parcount = 1;
//                        foreach (PropertyInfo propertyInfo in propertyInfos)
//                        {
//                            if ((propertyInfo.Name.ToLower() == "id") || (propertyInfo.PropertyType.Name == "List`1") || (propertyInfo.PropertyType.BaseType == typeof(Entity.BaseEntity)))
//                                continue;
//                            UPDATEQuery += (isFirst ? "" : " , ") + propertyInfo.Name + " = @" + propertyInfo.Name + parcount.ToString();
//                            parameters.Add("@" + propertyInfo.Name + parcount.ToString(), propertyInfo.GetValue(entity));
//                            isFirst = false;
//                        }
//                        UPDATEQuery += " Where Id = @Id;";
//                        parameters.Add("@Id", entity.Id);
//                        var count = con.Execute(UPDATEQuery, parameters);
//                        RecordId = entity.Id;
//                    }
//                    else
//                    {
//                        var parameters = new DynamicParameters();
//                        string UPDATEQuery = "";
//                        UPDATEQuery = "Delete from " + typeof(T).GetTypeInfo().Name + " Where Id = @Id;";
//                        parameters.Add("@Id", entity.Id);
//                        var count = con.Execute(UPDATEQuery, parameters);
//                        RecordId = entity.Id;
//                    }
//                }

//            }
//            catch (Exception ex)
//            {
//            }
//            return RecordId;
//        }


//    }
//}
