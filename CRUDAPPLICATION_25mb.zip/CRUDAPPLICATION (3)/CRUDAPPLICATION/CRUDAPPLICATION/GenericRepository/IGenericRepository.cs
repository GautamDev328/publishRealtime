﻿//using Entity;
//using Entity.Models;
//using System.Data;

//namespace DALC
//{
//    public interface IGenericRepository<T> where T : BaseEntity
//    {
//        long Insert(T entity);
//        void Insert(IEnumerable<T> entity);
//        void BulkInsert(List<T> entity);
//        T GetData(long id);        
//        long Update(T entity);
//        IEnumerable<T> GetAll();
//        //void Delete(T entity);
//        void Remove(T entity);
//     //   void Remove(long id);
//        void Remove(long id);
//        void Savechanges();
//        List<T> GetAllData();
//        void BulkInsertDapper(IEnumerable<T> entity);
//        void BulkInsertDapper1(IEnumerable<gst_partymaster> entity);
//        public long InsertDapper(T entity, IDbConnection con, int DeleteType = 0);

//    }
//}
