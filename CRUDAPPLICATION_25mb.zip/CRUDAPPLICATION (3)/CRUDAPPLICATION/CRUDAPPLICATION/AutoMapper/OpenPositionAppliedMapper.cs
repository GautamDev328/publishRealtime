﻿using AutoMapper;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.AutoMapper
{
          public class OpenPositionAppliedMapper : Profile
          {
                    public OpenPositionAppliedMapper()
                    {
                              {
                                        //CreateMap<OpenPositonAppliedModelcs, combinedtwomodeldto>().ReverseMap().
                                        //                                AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
                                        //                         .ForMember(dest => dest.OpenpositionId, opt => opt.MapFrom(src => src.openpositionmodel.OpenpositionId))
                                        //                         .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.openpositionmodel.FirstName))
                                        //                          .ForMember(dest => dest.MiddleName, opt => opt.MapFrom(src => src.openpositionmodel.MiddleName))

                                        //                            .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.openpositionmodel.LastName))
                                        //                             .ForMember(dest => dest.EmailAddress, opt => opt.MapFrom(src => src.openpositionmodel.EmailAddress))
                                        //                              .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.openpositionmodel.Address))
                                        //                            .ForMember(dest => dest.DateOfBirth, opt => opt.MapFrom(src => src.openpositionmodel.DateOfBirth))
                                        //                              .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => src.openpositionmodel.Gender))
                                        //                            .ForMember(dest => dest.MobileNumber, opt => opt.MapFrom(src => src.openpositionmodel.MobileNumber))
                                        //                            .ForMember(dest => dest.TotalExperience, opt => opt.MapFrom(src => src.openpositionmodel.TotalExperience))
                                        //                            .ForMember(dest => dest.RelevantExperience, opt => opt.MapFrom(src => src.openpositionmodel.RelevantExperience))
                                        //                            .ForMember(dest => dest.HIGHEREDUCATION, opt => opt.MapFrom(src => src.openpositionmodel.HIGHEREDUCATION))
                                        //                            .ForMember(dest => dest.HIgherPercentage, opt => opt.MapFrom(src => src.openpositionmodel.HIgherPercentage))
                                        //                            .ForMember(dest => dest.CurrentCTC, opt => opt.MapFrom(src => src.openpositionmodel.CurrentCTC))

                                        //                               .ForMember(dest => dest.ExpectedCTC, opt => opt.MapFrom(src => src.openpositionmodel.ExpectedCTC))
                                        //                                  .ForMember(dest => dest.Skill, opt => opt.MapFrom(src => src.openpositionmodel.Skill))
                                        //                                     .ForMember(dest => dest.Reasonchangethecompany, opt => opt.MapFrom(src => src.openpositionmodel.Reasonchangethecompany))
                                        //                                       .ForMember(dest => dest.PANCARDNUMBER, opt => opt.MapFrom(src => src.openpositionmodel.PANCARDNUMBER))
                                        //                                       .ForMember(dest => dest.image, opt => opt.MapFrom(src => src.openpositionmodel.image))
                                        //                                       .ForMember(dest => dest.Resume_CV, opt => opt.MapFrom(src => src.openpositionmodel.Resume_CV))
                                        //                                       .ForMember(dest => dest.PositionFeedback, opt => opt.MapFrom(src => src.openpositionmodel.PositionFeedback));


                                        //          CreateMap<InterviewApplicationFormModel, combinedtwomodeldto>().ReverseMap().
                                        //                                         AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
                                        //                                  .ForMember(dest => dest.interviewApplicationId, opt => opt.MapFrom(src => src.openpositionmodel.OpenpositionId))
                                        //                                  .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.openpositionmodel.FirstName))
                                        //                                   .ForMember(dest => dest.MiddleName, opt => opt.MapFrom(src => src.openpositionmodel.MiddleName))

                                        //                                     .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.openpositionmodel.LastName))
                                        //                                      .ForMember(dest => dest.EmailAddress, opt => opt.MapFrom(src => src.openpositionmodel.EmailAddress))
                                        //                                       .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.openpositionmodel.Address))
                                        //                                     .ForMember(dest => dest.DateOfBirth, opt => opt.MapFrom(src => src.openpositionmodel.DateOfBirth))
                                        //                                       .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => src.openpositionmodel.Gender))
                                        //                                     .ForMember(dest => dest.MobileNumber, opt => opt.MapFrom(src => src.openpositionmodel.MobileNumber))
                                        //                                     .ForMember(dest => dest.TotalExperience, opt => opt.MapFrom(src => src.openpositionmodel.TotalExperience))
                                        //                                     .ForMember(dest => dest.RelevantExperience, opt => opt.MapFrom(src => src.openpositionmodel.RelevantExperience))
                                        //                                     .ForMember(dest => dest.HIGHEREDUCATION, opt => opt.MapFrom(src => src.openpositionmodel.HIGHEREDUCATION))
                                        //                                     .ForMember(dest => dest.HighPercentage, opt => opt.MapFrom(src => src.openpositionmodel.HIgherPercentage))
                                        //                                     .ForMember(dest => dest.CurrentCTC, opt => opt.MapFrom(src => src.openpositionmodel.CurrentCTC))

                                        //                                        .ForMember(dest => dest.ExpectedCTC, opt => opt.MapFrom(src => src.openpositionmodel.ExpectedCTC))
                                        //                                           .ForMember(dest => dest.Skill, opt => opt.MapFrom(src => src.openpositionmodel.Skill))
                                        //                                              .ForMember(dest => dest.Reasonchangethecompany, opt => opt.MapFrom(src => src.openpositionmodel.Reasonchangethecompany))
                                        //                                                .ForMember(dest => dest.PancardNumber, opt => opt.MapFrom(src => src.openpositionmodel.PANCARDNUMBER))
                                        //                                                .ForMember(dest => dest.photo, opt => opt.MapFrom(src => src.openpositionmodel.image))
                                        //                                                .ForMember(dest => dest.Resume, opt => opt.MapFrom(src => src.openpositionmodel.Resume_CV))
                                        //                                                .ForMember(dest => dest.PositionFeedback, opt => opt.MapFrom(src => src.openpositionmodel.PositionFeedback));





                                        CreateMap<OpenPositonAppliedModelcs, InterviewApplicationFormModel>().ReverseMap().
                                                             AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
                                                      .ForMember(dest => dest.OpenpositionId, opt => opt.MapFrom(src => src.interviewApplicationId))
                                                      .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
                                                       .ForMember(dest => dest.MiddleName, opt => opt.MapFrom(src => src.MiddleName))

                                                         .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
                                                          .ForMember(dest => dest.EmailAddress, opt => opt.MapFrom(src => src.EmailAddress))
                                                           .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.Address))
                                                         .ForMember(dest => dest.DateOfBirth, opt => opt.MapFrom(src => src.DateOfBirth))
                                                           .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => src.Gender))
                                                         .ForMember(dest => dest.MobileNumber, opt => opt.MapFrom(src => src.MobileNumber))
                                                         .ForMember(dest => dest.TotalExperience, opt => opt.MapFrom(src => src.TotalExperience))
                                                         .ForMember(dest => dest.RelevantExperience, opt => opt.MapFrom(src => src.RelevantExperience))
                                                         .ForMember(dest => dest.HIGHEREDUCATION, opt => opt.MapFrom(src => src.HIGHEREDUCATION))
                                                         .ForMember(dest => dest.HIgherPercentage, opt => opt.MapFrom(src => src.HighPercentage))
                                                         .ForMember(dest => dest.CurrentCTC, opt => opt.MapFrom(src => src.CurrentCTC))

                                                            .ForMember(dest => dest.ExpectedCTC, opt => opt.MapFrom(src => src.ExpectedCTC))
                                                               .ForMember(dest => dest.Skill, opt => opt.MapFrom(src => src.Skill))
                                                                  .ForMember(dest => dest.Reasonchangethecompany, opt => opt.MapFrom(src => src.Reasonchangethecompany))
                                                                    .ForMember(dest => dest.PANCARDNUMBER, opt => opt.MapFrom(src => src.PancardNumber))
                                                                    .ForMember(dest => dest.image, opt => opt.MapFrom(src => src.photo))
                                                                    .ForMember(dest => dest.Resume_CV, opt => opt.MapFrom(src => src.Resume))
                                                                    .ForMember(dest => dest.PositionFeedback, opt => opt.MapFrom(src => src.PositionFeedback));

                              }

                    }
          }
}
