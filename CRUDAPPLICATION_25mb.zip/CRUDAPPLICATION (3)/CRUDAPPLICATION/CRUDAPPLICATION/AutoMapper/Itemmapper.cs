﻿using AutoMapper;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.AutoMapper
{
          public class Itemmapper : Profile
          {
                    public Itemmapper()
                    {

                              CreateMap<Item, ItemDTO>().ReverseMap().
                                           AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
                                      //.ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                                      .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name));
                              //.ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.Password))
                              //.ForMember(dest => dest.Photo, opt => opt.MapFrom(src => src.Photo));

                    }
          }
}
