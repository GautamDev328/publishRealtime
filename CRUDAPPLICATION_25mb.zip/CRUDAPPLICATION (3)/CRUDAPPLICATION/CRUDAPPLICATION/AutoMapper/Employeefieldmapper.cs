﻿
using AutoMapper;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.AutoMapper
{
          public class Employeefieldmapper : Profile
          {
                    public Employeefieldmapper()
                    {
                              CreateMap<EmployeeProfile, EmployeeDataDTO>().ReverseMap().
                                                      AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
                                               .ForMember(dest => dest.EmpId, opt => opt.MapFrom(src => src.EmpId))
                                               .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
                                                  .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
                                                     .ForMember(dest => dest.Mobile, opt => opt.MapFrom(src => src.Mobilenumber))
                                                        .ForMember(dest => dest.EmpId, opt => opt.MapFrom(src => src.EmailName))
                                                           .ForMember(dest => dest.DesignationName, opt => opt.MapFrom(src => src.DesignationName))
                                                              .ForMember(dest => dest.DepartmentName, opt => opt.MapFrom(src => src.DepartmentName));



                    }
          }
}
