﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using AutoMapper;

namespace CRUDAPPLICATION.AutoMapper
{
          public class RegisterationFrommapper : Profile
          {
                    public RegisterationFrommapper()
                    {
                              CreateMap<RegisterationForm, RegisterationFromDTO>().ReverseMap().

                                  AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)

                                 .ForMember(dest => dest.id, opt => opt.MapFrom(src => src.regtid))

                             .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.Username))
                             .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.Password))
                             .ForMember(dest => dest.isActive, opt => opt.MapFrom(src => src.isActive))
                             .ForMember(dest => dest.remainder, opt => opt.MapFrom(src => src.remainder));
                              //.ForMember(dest => dest.FirstLoginTime, opt => opt.MapFrom(src => src.FirstLoginTime))
                              //.ForMember(dest => dest.LastLoginTime, opt => opt.MapFrom(src => src.LastLoginTime))
                              //.ForMember(dest => dest.FirstLogOutTime, opt => opt.MapFrom(src => src.FirstLogOutTime))
                              //.ForMember(dest => dest.LastLogOutTime, opt => opt.MapFrom(src => src.LastLogOutTime));
                              //      .ForMember(dest => dest.Contact, opt => opt.MapFrom(src => src.MobileNumber));


                    }


}
}


