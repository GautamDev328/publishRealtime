﻿


using AutoMapper;
using CRUDAPPLICATION.AutoMapper;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.AutoMapper
{
          public class CommonBillingVoucherMapper : Profile
          {
                    public CommonBillingVoucherMapper()
                    {
                              // Global transformation for all string mappings
                              //    AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s);

                              //CreateMap<CustomerdetailsModel, CommonBillingVoucherDTO>()
                              //   //.ForMember(dest => dest.customerName, opt => opt.MapFrom(src => src.CustomerName))
                              //   // .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.CustomerAddress))
                              //    //.ForMember(dest => dest.custCurrentDate, opt => opt.MapFrom(src => src.custCurrentDate))
                              //    .ForMember(dest => dest.MobilNumber, opt => opt.MapFrom(src => src.Customerphone))
                              //    //.ForMember(dest => dest.BillingCurrentDate, opt => opt.MapFrom(src => src.BillingCurrentDate))
                              //    //.ForMember(dest => dest.BillingVoucherNumber, opt => opt.MapFrom(src => src.BillingVoucherNumber))
                              //    .ReverseMap();

                              CreateMap<BillingModel, CommonBillingVoucherDTO>()
                             .ForMember(dest => dest.voucherid, opt => opt.MapFrom(src => src.BillingId))
                            .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => src.FullName))
                             //.ForMember(dest => dest.ItemDescription, opt => opt.MapFrom(src => src.ProductDescription))
                             //     .ForMember(dest => dest.itemQuantity, opt => opt.MapFrom(src => src.Quantity))
                             //     .ForMember(dest => dest.Rate, opt => opt.MapFrom(src => src.Rate))
                             //     .ForMember(dest => dest.Amount, opt => opt.MapFrom(src => src.Amount))
                             //      .ForMember(dest => dest.CGST, opt => opt.MapFrom(src => src.CGST))
                             //     .ForMember(dest => dest.SGST, opt => opt.MapFrom(src => src.SGST))
                             //     .ForMember(dest => dest.IGST, opt => opt.MapFrom(src => src.IGST))
                             //       .ForMember(dest => dest.TotalInWords, opt => opt.MapFrom(src => src.TotalInWords))
                                  .ForMember(dest => dest.BillingCurrentDate, opt => opt.MapFrom(src => src.BillingDate))
                                  .ForMember(dest => dest.BillingVoucherNumber, opt => opt.MapFrom(src => src.BillingVoucherNumber))
                                 
                                  .ForMember(dest=>dest.BankUpi,opt=>opt.MapFrom(src=>src.Bankupi))
                                 
                                 .ReverseMap();

                              //CreateMap<BillingModel, Billingitemdetails>()
                              //          .ForMember(dest => dest.BillingItemid, opt => opt.MapFrom(src => src.BillingId))
                              //          .ReverseMap();


                    }

          }
}
