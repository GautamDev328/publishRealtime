﻿//using CRUDAPPLICATION.Model;
//using CRUDAPPLICATION.ModelDTO;

//namespace CRUDAPPLICATION.AutoMapper
//{
//          public class ForgetPassWordMapper : Profile
//          {
//                    public ForgetPassWordMapper()
//                    {
//                              CreateMap<RegisterationForm, ForgetPasswordUserDto>().ReverseMap()
//                                  .AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
//                                  .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.Username))
//                                  .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.NewPassword))
//                                  .ForMember(dest => dest.ConformPassword, opt => opt.MapFrom(src => src.ConfirmNewPassword));

//                              CreateMap<RegisterationForm, UserForget>().ReverseMap()
//                                  .AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
//                                  .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.Username))
//                                  .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.NewPassword));
//                    }
//          }
//}
