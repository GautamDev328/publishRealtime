﻿using AutoMapper;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.AutoMapper
{
          public class DesignationMapper : Profile
          {
                    public DesignationMapper()
                    {
                              CreateMap<DesignationModel, Designaitondtomodel>().ReverseMap().
                                                                                AddTransform<string>(s => string.IsNullOrEmpty(s) ? "" : s)
                                                  .ForMember(dest => dest.DesigId, opt => opt.MapFrom(src => src.id))
                                                  .ForMember(dest => dest.DesigName, opt => opt.MapFrom(src => src.DesignationName));

                    }
          }
}
