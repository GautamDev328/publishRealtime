﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IdistrictNameRepository
          {
                    public List<DistrictNameModel> lstdistrictmode();
                    public void CreateDistrict(DistrictNameModel objdistrictname);
                    public void UpdateDistrict(DistrictNameModel objdistrictname);
                    public void DeleteDistrict(int id);
                    public DistrictNameModel DetailsDistrict(int id);

          }
}
