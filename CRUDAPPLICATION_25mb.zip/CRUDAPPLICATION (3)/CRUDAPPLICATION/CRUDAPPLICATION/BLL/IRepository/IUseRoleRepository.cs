﻿using CRUDAPPLICATION.Model;
using System.Reflection.Metadata.Ecma335;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IUseRoleRepository
    {
        public List<UseRoleWiseModel> GetUseRoleWiseModels();
        public void InsertUseRole(UseRoleWiseModel useRole);
        public void UpdateUseRole(UseRoleWiseModel useRole);
        public void DeleteUseRole(int id);
        public UseRoleWiseModel DetailsUseRole(int id);

                    // Excel Export
                  //  public byte[] GenerateCitiesExcelFile(List<UseRoleWiseModel> useRoleWiseModelss);
          }
}
