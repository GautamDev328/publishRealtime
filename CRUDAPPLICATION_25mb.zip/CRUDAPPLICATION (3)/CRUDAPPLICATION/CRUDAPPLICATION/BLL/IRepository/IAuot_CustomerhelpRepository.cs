﻿using CRUDAPPLICATION.Model;
using Microsoft.Identity.Client;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IAuot_CustomerhelpRepository
          {
                    //Task<IEnumerable<Auot_CustomerhelpModel>> GetAllCustomersAsync();
                    //Task<Auot_CustomerhelpModel> GetCustomerByIdAsync(int customerId);
                    //Task AddCustomerAsync(Auot_CustomerhelpModel customer);
                    //Task UpdateCustomerAsync(Auot_CustomerhelpModel customer);
                    //Task DeleteCustomerAsync(int customerId);
                    public List<Auot_CustomerhelpModel> GetAllCustomer();
                    public void CreateCustomerHelper(Auot_CustomerhelpModel Auot);
                    public void UpdateCustomerHelper(Auot_CustomerhelpModel Auot);
                    public Auot_CustomerhelpModel DetailCustomerHelper(int id);
                    public void DeleteCustomerHelper(int id);
                    public byte[] GenerateBankExcelFile(List<Auot_CustomerhelpModel> autoModelss);


          }
}
