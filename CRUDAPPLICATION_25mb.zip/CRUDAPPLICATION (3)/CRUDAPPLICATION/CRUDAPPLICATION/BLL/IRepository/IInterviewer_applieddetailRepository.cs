﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IInterviewer_applieddetailRepository
          {
                    public List<Interviewer_applieddetail_Models> GetAllInterviewer_applieddetail();
                    public void CreateInterviewer_applieddetail(Interviewer_applieddetail_Models model);
                    public void UpdateInterviewer_applieddetail(Interviewer_applieddetail_Models models);
                    public void DeleteInterviewer_applieddetail(int id);
                    //public EmployeeProfile Search(int id);
                    public Interviewer_applieddetail_Models DetailInterviewer_applieddetail(int id);
                    public Interviewer_applieddetail_Models SearchById(int id);

                    // Excel Export
                    public byte[] GenerateInterviewer_applieddetailExcelFile(List<Interviewer_applieddetail_Models> interviewapplieddetail);
          }
}
