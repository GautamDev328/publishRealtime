﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IClientQueryMessageRepository
    {
        public List<ClientQuery> AllClientQueryMessage();
        public void CreateCientQueryMessage(ClientQuery message);
        public void UpdateCientQueryMessage(ClientQuery clientQueryMessage);
        public void DeleteCientQueryMessage(int id);
        public ClientQuery DetailsClientQueryMessage(int id);

                    // Excel Export
                    public byte[] GenerateClientQueryExcelFile(List<ClientQuery> clientQueriess);

          }
}
