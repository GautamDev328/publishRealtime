﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IDepartmentRepository
    {
        public List<Department> GetAllDepartmentData();
        public void CreateDepartment(Department model);
        public void UpdateDepartment(Department department);
        public void DeleteDepartment(int id);
        public Department DetailsDepartments(int  id);
      public  List<Designaitondtomodel> GetDesignationsByDepartment(int departmentId);

                    // Excel Export
    public byte[] GenerateDepartmentExcelFile(List<Department> departments);

          }
}