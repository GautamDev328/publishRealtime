﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IRegisterationFormRepository
    {
        public List<RegisterationForm> GetAllRegisteration();
 
        public void CreateRegistertaion(RegisterationForm registerationFormModel);
        public void UpdateRegistertaion(RegisterationForm registertaion);
        public void DeleteRegistertaion(int id);
        public RegisterationForm GetAllRegisteration(int id);
        public RegisterationFromDTO LoginPage(string username, string password);//,string LoginType
                   // public List<RegisterationFromDTO> allLoginPag();//,string LoginType

                    // Excel Export
                    // public byte[] GenerateCitiesExcelFile(List<RegisterationForm> registerationFormss);

                    Task<bool> ResetPasswordAsync(ForgetPasswordUserDto dto);
                    // Userforgetcheck

                    Task<bool> UserForgetAsync(UserForget dto1);


                    public RegisterationFromDTO GetUserByUsername(string username);


                   //  RegisterationForm Login(string username, string password, string loginType);



          }
}
