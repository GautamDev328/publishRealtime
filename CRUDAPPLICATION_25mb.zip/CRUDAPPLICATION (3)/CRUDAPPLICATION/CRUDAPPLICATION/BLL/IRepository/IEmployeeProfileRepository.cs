﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IEmployeeProfileRepository
    {
        public List<EmployeeProfile> GetAll();
        public void updateEmployeeProfile(EmployeeProfile employeeProfile);
        public EmployeeProfile DetailsEmployeeProfile(int id);
        public void deleteEmployeeProfile(int id);
                   
                    public void Insert(EmployeeProfile employeeProfile);

                    // Excel Export
                   public byte[] GenerateempllyeeprofilesExcelFile(List<EmployeeProfile> employeeProfiless);
                    //  EmployeeProfile Login(string username, string password, string loginType);
                    public EmployeeProfile GetEmployeeByFirstName(string firstname);
                    //{
                    //          return _context.EmployeeProfiles
                    //              .FirstOrDefault(e => e.FirstName.Trim().ToLower() == firstname.Trim().ToLower());
                    //}




          }
}
