﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IHigherQualificationRepository
          {
                    public List<HigherQualificationModel> AllHighestQualification();
                    public HigherQualificationModel DeleteHighestQualificationById(int id);
                    public void AddHighestQualification(HigherQualificationModel higherQualificationModel);
                    public void UpdateHighestQualification(HigherQualificationModel higherQualificationModel);
                    public HigherQualificationModel  DetailsHighestQualificationById(int id);

    }
}
