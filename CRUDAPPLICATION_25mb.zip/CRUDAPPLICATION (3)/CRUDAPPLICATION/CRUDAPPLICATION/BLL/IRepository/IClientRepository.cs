﻿using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IClientRepository
    {
        public List<ClientModel> Allclientmodel();
        public void InsertClientmodel(ClientModel clientmodel);
     public void UpdateClientmodel(ClientModel clientmodel);
                    public void DeleteClientmodel(int  clientid);
                    public ClientModel DetailsClientmodel(int clientid);

                    // Excel Export
                    public byte[] GenerateClinetExcelFile(List<ClientModel> clientss);


          }
}
