﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IRescheduleDateInterviewOPENINGRepository
          {

                    public List<RescheduleDateInterviewOPENINGMODEL> GetAllRescheduleDate();
                    public void CreateRescheduleDate(RescheduleDateInterviewOPENINGMODEL model);
                    public void UpdateRescheduleDate(RescheduleDateInterviewOPENINGMODEL models);
                    public void DeleteRescheduleDate(int id);
                    //public EmployeeProfile Search(int id);
                    public RescheduleDateInterviewOPENINGMODEL DetailRescheduleDate(int id);
                    public RescheduleDateInterviewOPENINGMODEL SearchById(int id);

                    // Excel Export
                    public byte[] GenerateRescheduleDateExcelFile(List<RescheduleDateInterviewOPENINGMODEL> RescheduleDate);
          }
}
