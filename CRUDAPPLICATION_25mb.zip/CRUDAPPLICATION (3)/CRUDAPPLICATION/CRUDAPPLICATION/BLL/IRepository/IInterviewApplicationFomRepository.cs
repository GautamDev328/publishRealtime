﻿//using CRUDAPPLICATION.AutoMapper;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IInterviewApplicationFomRepository
          {
                    public List<InterviewApplicationFormModel> GetAllInterview();
                   public void Createinterviewapplicaiton(InterviewApplicationFormModel model);
                    public void Updateinterviewapplicaitony(InterviewApplicationFormModel models);
                    public void Deleteinterviewapplicaitony(int id);
                    public InterviewApplicationFormModel Detailinterviewapplicaitony(int id);
                    public InterviewApplicationFormModel SearchById(int id);

                    // trail model
                //    public combinedtwomodeldto Interviewaddfetch(int id);
                    // Excel Export
                    public byte[] GenerateinterviewapplicaitonyExcelFile(List<InterviewApplicationFormModel> interview);
                    public InterviewApplicationFormModel fetchdata(int fetchid);
          }
}
