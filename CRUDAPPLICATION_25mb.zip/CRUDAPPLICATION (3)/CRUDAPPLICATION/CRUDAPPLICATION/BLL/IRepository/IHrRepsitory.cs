﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IHrRepsitory
    {
        public List<HRProfile> AllHrProfile();
        public void CreateHrProfile(HRProfile hrProfile);
        public void UpdateHrProfile(HRProfile hrProfile);
        public void DeleteHrProfile(int id);
        public HRProfile DetailHrProfile(int id);


                    // Excel Export
                //    public byte[] GenerateCitiesExcelFile(List<HRProfile> hRProfiless);
                    //public void  HrLogin(HrLoginDTO hrLoginDTO);
                    //public RegisterationFromDTO HRLoginPage(string username, string password);

          }
}
        