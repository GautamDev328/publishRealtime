﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IBillingRepository
          {
                    public List<BillingModel> GetAllBilling();
                    public void InsertBillingData(BillingModel billing);
                    public void CustomerInsertData(CustomerdetailsModel customerdetails); //CustomerdetailsModel
                    public CustomerdetailsModel CustomerDetails(int  id); //CustomerdetailsfetchdataonebyoneModel
                    public void CustomerDeletes(int id);
                    public void UpdateCustomer(CustomerdetailsModel updatecusstomer);

                    public void UpdateBilling(BillingModel billing);
                    public void DeleteBilling(int id);
                    public BillingModel DetailsBillingData(int id);
                    public List<CustomerdetailsModel> GetAllCustomer();
                  public CommonBillingVoucherDTO commonbilling(int id);

                    // Excel Export
                    public byte[] GenerateBillingExcelFile(List<BillingModel> billingModelss);


                    //public void CreateCustomerType(CustomerTypeModel customerTypes);  // customertype
                    //public List<CustomerTypeModel> GetCustomerType();

             }
}
