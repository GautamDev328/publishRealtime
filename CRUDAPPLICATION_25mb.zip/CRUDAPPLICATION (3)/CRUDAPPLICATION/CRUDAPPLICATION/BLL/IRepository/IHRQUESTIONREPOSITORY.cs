﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IHRQUESTIONREPOSITORY
          {
                    public List<HRQUESTIONMODEL> GetHRQUESTIONMODEL();
                    public void AddHRQUESTIONMODEL(HRQUESTIONMODEL hRQUESTIONMODEL);
                    public void UpdateHRQUESTIONMODEL(HRQUESTIONMODEL hRQUESTIONMODEL);
                    public void DeleteHRQUESTIONMODEL(int id);
                    public HRQUESTIONMODEL DetailsHRQUESTIONMODEL(int id);


                    public byte[] GeneratesHRQUESTIONExcelFile(List<HRQUESTIONMODEL> hRQUESTIONMODELs);

          }

}
