﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IBankRepository
    {
        public List<BankModel> GetALLBank();
        public void AddBANK(BankModel BNKmodel);
        public void UpdateBANK(BankModel BNK1model);
        public void DeleteRelationShip(int id);
        public BankModel DetailsModel(int id);

                    // Excel Export
                    public byte[] GenerateBankExcelFile(List<BankModel> bankModelss);
          }
}
