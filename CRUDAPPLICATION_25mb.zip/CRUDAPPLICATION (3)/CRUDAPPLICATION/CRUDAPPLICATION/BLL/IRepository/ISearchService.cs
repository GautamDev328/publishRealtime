﻿using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface ISearchService
          {
               //  public    List<ItemDTO> SearchItems(string name);

          }
}
