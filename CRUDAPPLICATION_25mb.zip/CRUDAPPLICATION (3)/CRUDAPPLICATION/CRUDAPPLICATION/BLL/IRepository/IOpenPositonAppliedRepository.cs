﻿using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.IRepository
{
          public interface IOpenPositonAppliedRepository
          {
                    public List<OpenPositonAppliedModelcs> GetAllOpenPositon();
                    public void CreateOpenPositon(OpenPositonAppliedModelcs model);
                    public void UpdateOpenPositon(OpenPositonAppliedModelcs models);
                    public void DeleteOpenPositon(int id);
                    //public EmployeeProfile Search(int id);
                    public OpenPositonAppliedModelcs DetailOpenPositon(int id);
                    public OpenPositonAppliedModelcs SearchById(int id);

                    // Excel Export
                    public byte[] GenerateOpenPositonExcelFile(List<OpenPositonAppliedModelcs> OpenPositons);


                    // datafectch interview application
                   // public combinedtwomodeldto fetchall(int id);
                  //  public void  fetchall(int id);


                  
                    }

          }
