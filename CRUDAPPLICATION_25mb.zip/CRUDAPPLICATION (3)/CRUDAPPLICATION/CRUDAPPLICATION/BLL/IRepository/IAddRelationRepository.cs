﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IAddRelationRepository
    {
        public List<AddRelationShipModel> AllAddRelationShips();
        public void AddRelationShip(AddRelationShipModel model);
        public void UpdateRealtionShip(AddRelationShipModel model);
        public void DeleteRelationShip(int id);
        public AddRelationShipModel DetailsRelationship(int id);

                    // Excel Export
                    public byte[] GenerateaddrelationExcelFile(List<AddRelationShipModel> addRelationShipModelss);
          }
}
