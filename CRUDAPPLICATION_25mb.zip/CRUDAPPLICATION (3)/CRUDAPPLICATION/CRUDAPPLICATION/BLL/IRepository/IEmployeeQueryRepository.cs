﻿using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.IRepository
{
    public interface IEmployeeQueryRepository
    {
        public List<EmployeeQuery> GetEmployeeQueryAll();
        public void CreateEmployeeQuery(EmployeeQuery employeeQuery);
        public void UpdateEmployeeQuery(EmployeeQuery employeeQuery);
        public void DeleteEmployeeQuery(int  id);
      
        public EmployeeQuery DetailsEmployeeQuery(int  id);

                    // Excel Export
                   public byte[] GenerateEmployeeQueryExcelFile(List<EmployeeQuery> employeeQueriess);
          }
}
