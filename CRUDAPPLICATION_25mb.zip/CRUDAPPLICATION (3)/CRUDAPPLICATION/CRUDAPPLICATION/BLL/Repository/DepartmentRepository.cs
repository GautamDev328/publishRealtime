﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class DepartmentRepository : IDepartmentRepository
          {
                    EmployeeDbContext employeeDbContext;
                    public DepartmentRepository(EmployeeDbContext _employeeDbContext)
                    {
                              this.employeeDbContext = _employeeDbContext;

                    }


                    public List<Department> GetAllDepartmentData()
                    {
                              var list = employeeDbContext.departments.ToList();
                              return list;
                    }

                    //public Department CreateDepartment(Department model)
                    //{
                    //          employeeDbContext.departments.Add(model);
                    //          employeeDbContext.SaveChanges();
                             
                    //}

                    public void UpdateDepartment(Department department)
                    {
                              employeeDbContext.departments.Update(department);
                              employeeDbContext.SaveChanges();
                    }

                    public void DeleteDepartment(int id)
                    {
                              var a = employeeDbContext.departments.Where(s => s.id == id).FirstOrDefault();
                              employeeDbContext.departments.Remove(a);
                              employeeDbContext.SaveChanges();
                    }



                    public Department DetailsDepartments(int id)
                    {
                              var dep = employeeDbContext.departments.Where(s => s.id == id).FirstOrDefault();
                              return dep;
                    }

                    public List<Designaitondtomodel> GetDesignationsByDepartment(int departmentId)
                    {
                              var designations = employeeDbContext.departments.Where(s => s.id == departmentId)
            .Select(d => new Designaitondtomodel
            {
                      id = d.id,
                      DesignationName = d.Dep_Name
            })
            .ToList();

                              return designations;
                    }
                    // Export file 
                    public byte[] GenerateDepartmentExcelFile(List<Department> departments)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("departmentss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Dep_Id";
                                        worksheet.Cells[1, 2].Value = "Dep_Name";
                                      

                                        // Add data
                                        for (int i = 0; i < departments.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = departments[i].id;
                                                  worksheet.Cells[i + 2, 2].Value = departments[i].Dep_Name;
                                               

                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public void CreateDepartment(Department model)
                    {
                              employeeDbContext.departments.Add(model);
                              employeeDbContext.SaveChanges();
                             
                    }

          }
}