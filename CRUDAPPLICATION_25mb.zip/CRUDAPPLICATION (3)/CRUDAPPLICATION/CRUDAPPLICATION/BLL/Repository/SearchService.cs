﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class SearchService : ISearchService
          {
                    EmployeeDbContext employeeDbContext;
                    public SearchService(EmployeeDbContext _employeeDbContext)
                    {
                              this.employeeDbContext = _employeeDbContext;
                    }
                    public List<ItemDTO> SearchItems(string name)
                    {
                              if (string.IsNullOrWhiteSpace(name))
                              {
                                        return new List<ItemDTO>(); // Return empty list if input is invalid
                              }

                              // Log the search term
                              Console.WriteLine($"Searching for: '{name}'");

                              var result = employeeDbContext.itemss
                                  .Where(item => item.Name.ToLower().Contains(name.ToLower())) // Case-insensitive search
                                  .Select(i => new ItemDTO
                                  {
                                            Name = i.Name
                                  }).ToList();

                              // Return the result
                              return result;
                    }



          }

}