﻿//using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
//using Microsoft.AspNetCore.Http.HttpResults;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class EmployeeProfileRepository : IEmployeeProfileRepository
          {
                    EmployeeDbContext employeeDbContext;
                    public EmployeeProfileRepository(EmployeeDbContext _employeeDbContext)
                    {
                              employeeDbContext = _employeeDbContext;
                    }


                    public List<EmployeeProfile> GetAll()
                    {
                              var a = employeeDbContext.employeeProfiless.ToList();
                              employeeDbContext.SaveChanges();
                              return a;
                    }

                   public void deleteEmployeeProfile(int id)
                 {
                              var delete = employeeDbContext.employeeProfiless.Where(s => s.EmpId == id).FirstOrDefault();
                              employeeDbContext.employeeProfiless.Remove(delete);
                              employeeDbContext.SaveChanges();
                    }




                    public EmployeeProfile DetailsEmployeeProfile(int id)
                    {
                              var b = employeeDbContext.employeeProfiless.Where(s => s.EmpId == id).FirstOrDefault();
                              return b;
                    }

                    public void updateEmployeeProfile(EmployeeProfile employeeProfile)
                    {
                              employeeDbContext.employeeProfiless.Update(employeeProfile);
                              employeeDbContext.SaveChanges();
                    }
                    // EMployee data listing 
              //Profile deskboard employeewise data show  after login  page difference employee own the our all data show the deskbaord
                    public EmployeeDataDTO getemployeedata(int empid)
                    {
                              var employeeProfile = employeeDbContext.employeeProfiless
                                                        .Where(s => s.EmpId == empid)
                                                        .FirstOrDefault();

                              //if (employeeProfile == null)
                              //{
                              //          // Handle the case where no employee is found, e.g., return null or throw an exception
                              //          return null;  // Or throw a custom exception depending on your use case
                              //}

                              // Assuming EmployeeDataDTO has similar properties to employeeProfiles,
                              // You might need to map them here if necessary.
                              var employeeDataDTO = new EmployeeDataDTO
                              {
                                        // EmpId = employeeProfile.EmpId,
                                        EmpId = employeeProfile.EmpId,
                                        FirstName = employeeProfile.FirstName,  // Example field
                                        LastName = employeeProfile.LastName,  // Example field
                                        Mobilenumber = employeeProfile.Mobile,
                                        EmailName = employeeProfile.Emailid,              /* Email Name */

                                        DesignationName = employeeProfile.DesignationName,
                                        DepartmentName = employeeProfile.DepartmentName,


                                        // Map other necessary fields
                              };

                              return employeeDataDTO;
                    }

                    public void Insert(EmployeeProfile employeeProfile)
                    {
                              employeeDbContext.employeeProfiless.Add(employeeProfile);
                              employeeDbContext.SaveChanges();
                    }

                    public byte[] GenerateempllyeeprofilesExcelFile(List<EmployeeProfile> employeeProfiless)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("employeeProfiless");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "EmpId";//FormattedEmpId
                                        worksheet.Cells[1, 2].Value = "FirstName";
                                        worksheet.Cells[1, 3].Value = "LastName";
                                        worksheet.Cells[1, 4].Value = "Designation";
                                        worksheet.Cells[1, 5].Value = "Address";
                                        worksheet.Cells[1, 5].Value = "Pincode";
                                        worksheet.Cells[1, 7].Value = "City";
                                        worksheet.Cells[1, 8].Value = "Mobile";
                                        worksheet.Cells[1, 9].Value = "StateName";
                                        worksheet.Cells[1, 10].Value = "DepartmentName";
                                        worksheet.Cells[1, 11].Value = "DesignationName";
                                        worksheet.Cells[1, 12].Value = "Emailid";
                                        worksheet.Cells[1, 13].Value = "Gender";
                                        worksheet.Cells[1, 14].Value = "Age";

                                        // Add data
                                        for (int i = 0; i < employeeProfiless.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = employeeProfiless[i].EmpId;//FormattedEmpId
                                                  worksheet.Cells[i + 2, 2].Value = employeeProfiless[i].FirstName;
                                                  worksheet.Cells[i + 2, 3].Value = employeeProfiless[i].LastName;
                                                  worksheet.Cells[i + 2, 4].Value = employeeProfiless[i].Designation;
                                                  worksheet.Cells[i + 2, 5].Value = employeeProfiless[i].Address;
                                                  worksheet.Cells[i + 2, 6].Value = employeeProfiless[i].PinCode;
                                                  worksheet.Cells[i + 2, 7].Value = employeeProfiless[i].City;
                                                  worksheet.Cells[i + 2, 8].Value = employeeProfiless[i].Mobile;
                                                  worksheet.Cells[i + 2, 9].Value = employeeProfiless[i].StateName;
                                                  worksheet.Cells[i + 2, 10].Value = employeeProfiless[i].DepartmentName;
                                                  worksheet.Cells[i + 2, 11].Value = employeeProfiless[i].DesignationName;
                                                  worksheet.Cells[i + 2, 12].Value = employeeProfiless[i].Emailid;
                                                  worksheet.Cells[i + 2, 13].Value = employeeProfiless[i].Gender;
                                                  worksheet.Cells[i + 2, 14].Value = employeeProfiless[i].Age;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public EmployeeProfile GetEmployeeByFirstName(string firstname)
                    {
                              return employeeDbContext.employeeProfiless
                                  .FirstOrDefault(e => e.FirstName.Trim().ToLower() == firstname.Trim().ToLower());
                    }

                    //public EmployeeProfile Login(string username, string password, string loginType)
                    //{
                    //          // 1. First check username + password
                    //          var user = employeeDbContext.employeeProfiless
                    //                             .FirstOrDefault(x => x.FirstName == username
                    //                                               && x.pass == password);

                    //          if (user == null)
                    //          {
                    //                    return null; // User not found
                    //          }

                    //          // 2. Check role match
                    //          if (user.LoginType != loginType)
                    //          {
                    //                    return null; // Wrong login role
                    //          }

                    //          return user;
                    //}
          }
}

