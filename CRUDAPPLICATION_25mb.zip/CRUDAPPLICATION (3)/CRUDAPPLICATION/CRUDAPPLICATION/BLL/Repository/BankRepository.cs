﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class BankRepository:IBankRepository
    {
         EmployeeDbContext EmployeeDbContext;
        public BankRepository(EmployeeDbContext _employeeDbContext)
        {
                this.EmployeeDbContext = _employeeDbContext;
        }

        public void AddBANK(BankModel BNKmodel)
        {
           EmployeeDbContext.bankModelss.Add(BNKmodel);
            EmployeeDbContext.SaveChanges();
        }

        public void DeleteRelationShip(int id)
        {
            var delete = EmployeeDbContext.bankModelss.Where(s => s.BankId == id).FirstOrDefault();
                       EmployeeDbContext.bankModelss.Remove(delete);
             EmployeeDbContext.SaveChanges();
        }

        public BankModel DetailsModel(int id)
        {
           var details= EmployeeDbContext.bankModelss.Where(s=>s.BankId == id).FirstOrDefault();
            return details;
        }

                    public byte[] GenerateBankExcelFile(List<BankModel> bankModelss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("bankModelss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "BankId";
                                        worksheet.Cells[1, 2].Value = "BankName";
                                        worksheet.Cells[1, 3].Value = "IFSCCODE";
                                        worksheet.Cells[1, 4].Value = "StatusCode";
                                        worksheet.Cells[1, 5].Value = "MICRCODE";
                                        worksheet.Cells[1, 6].Value = "BranchName";
                                        worksheet.Cells[1, 7].Value = "DistrictName";
                                        worksheet.Cells[1, 8].Value = "Address";
                                        worksheet.Cells[1, 9].Value = "State";
                                        worksheet.Cells[1, 10].Value = "BankDescription";

                                        // Add data
                                        for (int i = 0; i < bankModelss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = bankModelss[i].BankId;
                                                  worksheet.Cells[i + 2, 2].Value = bankModelss[i].BankName;
                                                  worksheet.Cells[i + 2, 3].Value = bankModelss[i].IFSCCODE;
                                                  worksheet.Cells[i + 2, 4].Value = bankModelss[i].StatusCode;
                                                  worksheet.Cells[i + 2, 5].Value = bankModelss[i].MICRCODE;
                                                  worksheet.Cells[i + 2, 6].Value = bankModelss[i].BranchName;
                                                  worksheet.Cells[i + 2, 7].Value = bankModelss[i].DistrictName;
                                                  worksheet.Cells[i + 2, 8].Value = bankModelss[i].Address;
                                                  worksheet.Cells[i + 2, 9].Value = bankModelss[i].State;
                                                  worksheet.Cells[i + 2, 10].Value = bankModelss[i].BankDescription;
                                                 
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }
                    public List<BankModel> GetALLBank()
        {
            var list = EmployeeDbContext.bankModelss.ToList();
            return list;
        }

        public void UpdateBANK(BankModel BNK1model)
        {
            EmployeeDbContext.bankModelss.Update(BNK1model); 
            EmployeeDbContext.SaveChanges();
        }

    }
}
