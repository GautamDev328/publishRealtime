﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class ROLEWISEREPSITORY : IRoleWiseRepository
    {
        EmployeeDbContext _emp;
        public ROLEWISEREPSITORY(EmployeeDbContext emp)
        {
            this._emp = emp;
        }
        public void CreateRoleWiseModel(RoleWiseModel roleWiseModel)
        {
            _emp.roleWises.Add(roleWiseModel);
            _emp.SaveChanges();
        }

        public void DeleteRoleWiseModel(int id)
        {
            var delete = _emp.roleWises.Where(s => s.Role_ID == id).FirstOrDefault();
                       _emp.roleWises.Remove(delete);    
                      _emp.SaveChanges();
        }

        public RoleWiseModel DetailsRoleWiseModel(int id)
        {
           var details=_emp.roleWises.Where(s=>s.Role_ID==id).FirstOrDefault();
            return details;
        }

        public List<RoleWiseModel> GetRoleWiseRoleAll()
        {
            var list = _emp.roleWises.ToList();
            return list;
        }

        public void UpdateRoleWiseModel(RoleWiseModel roleWiseModel)
        {
            _emp.roleWises.Update(roleWiseModel);
            _emp.SaveChanges();
        }
    }
}
