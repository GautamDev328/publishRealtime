﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class CustomerPricesRespository : ICustomePricesRepository
    {
        EmployeeDbContext _employeeDbContext;
        public CustomerPricesRespository(EmployeeDbContext employeeDbContext)
        {
            this._employeeDbContext = employeeDbContext;

        }

        public void CreateCustomerPrice(CustomerPrice customerPrice)
        {
            _employeeDbContext.customerPricess.Add(customerPrice);
            _employeeDbContext.SaveChanges();
        }

        public List<CustomerPrice> customerPrices()
        {
            var list = _employeeDbContext.customerPricess.ToList();
            return list;
        }

        public void DeleteCustomerPrice(int Id)
        {
            var delete = _employeeDbContext.customerPricess.Where(s => s.Id == Id).FirstOrDefault();
            _employeeDbContext.customerPricess.Remove(delete);
            _employeeDbContext.SaveChanges();
        }

        public CustomerPrice DetailsCustomerPrice(int ID)
        {
            var a = _employeeDbContext.customerPricess.Where(s => s.Id == ID).FirstOrDefault();
            return a;
        }

                    public byte[] GenerateCustomerPricexcelFile(List<CustomerPrice> customerPricess)
                    {

                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("customerPricess");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Id";
                                        worksheet.Cells[1, 2].Value = "CustomerExtraPrice";
                                        worksheet.Cells[1, 3].Value = "CustomerExtraUser";
                                       
                                        // Add data
                                        for (int i = 0; i < customerPricess.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = customerPricess[i].Id;
                                                  worksheet.Cells[i + 2, 2].Value = customerPricess[i].CustomerExtraPrice;
                                                  worksheet.Cells[i + 2, 3].Value = customerPricess[i].CustomerExtraUser;
                                                

                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public CustomerPrice SeachById(int id)
        {
            var a = _employeeDbContext.customerPricess.Where(s => s.Id == id).FirstOrDefault();
            return a;
        }

        public void UpdateCustomerPrice(CustomerPrice customerPrice)
        {
            _employeeDbContext.customerPricess.Update(customerPrice);
            _employeeDbContext.SaveChanges();
        }
    }
}
