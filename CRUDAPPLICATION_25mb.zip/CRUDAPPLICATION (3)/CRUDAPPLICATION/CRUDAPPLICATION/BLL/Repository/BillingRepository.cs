﻿//using AutoMapper;
using CRUDAPPLICATION.AutoMapper;
using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using System.Linq;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class BillingRepository : IBillingRepository
          {
                    EmployeeDbContext employeeDbContext;
                    public BillingRepository(EmployeeDbContext _employeeDbContext)
                    {
                              this.employeeDbContext = _employeeDbContext;
                    }

                    //CustomerInsertData 
                    public void CustomerInsertData(CustomerdetailsModel customerdetails)
                    {
                              employeeDbContext.customerdetailsModelsss.Add(customerdetails);
                              employeeDbContext.SaveChanges();
                    }

                    public void DeleteBilling(int id)
                    {
                              var delete = employeeDbContext.billingModelsss.Where(s => s.BillingId == id).FirstOrDefault();
                              employeeDbContext.billingModelsss.Remove(delete);
                              employeeDbContext.SaveChanges();
                    }

                    public BillingModel DetailsBillingData(int id)
                    {
                              var details = employeeDbContext.billingModelsss.Where(s => s.BillingId == id).FirstOrDefault();

                              return details;


                              // Fetch the BillingModel using BillingId
                              //var billingDetails = employeeDbContext.billingModelsss
                              //    .Where(b => b.BillingId == id)
                              //    .FirstOrDefault();

                              //if (billingDetails != null)
                              //{
                              //          // Fetch CustomerDetails by CustomerId from the BillingModel
                              //          var customerDetails = employeeDbContext.customerdetailsModelsss
                              //              .Where(c => c.CustId == billingDetails.CustomerId)
                              //              .FirstOrDefault();

                              //          // Automatically set FullName in BillingModel to CustomerName from CustomerdetailsModel
                              //          if (customerDetails != null)
                              //          {
                              //                    billingDetails.FullName = customerDetails.CustomerName ?? "N/A"; // Default to "N/A" if CustomerName is null
                              //          }
                              //          else
                              //          {
                              //                    // If no customer details are found, set default value
                              //              //      billingDetails.FullName = "N/A";
                              //                    billingDetails.FullName = customerDetails.CustomerName;
                              //          }
                              //}

                              //return billingDetails;
                    }




                    public byte[] GenerateBillingExcelFile(List<BillingModel> billingModelss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("billingModelsss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "BillingId";
                                        worksheet.Cells[1, 2].Value = "FullName";
                                        worksheet.Cells[1, 3].Value = "Email";
                                        worksheet.Cells[1, 4].Value = "Address";
                                        worksheet.Cells[1, 5].Value = "City";
                                        worksheet.Cells[1, 6].Value = "State";
                                        worksheet.Cells[1, 7].Value = "bankname";
                                        worksheet.Cells[1, 8].Value = "cardnumber";
                                        worksheet.Cells[1, 9].Value = "ExpMonth";
                                        worksheet.Cells[1, 10].Value = "ExpYear";
                                        worksheet.Cells[1, 11].Value = "CVV";
                                        worksheet.Cells[1, 12].Value = "Otheramount";

                                        // Add data
                                        for (int i = 0; i < billingModelss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = billingModelss[i].BillingId;
                                                  worksheet.Cells[i + 2, 2].Value = billingModelss[i].FullName;
                                                  worksheet.Cells[i + 2, 3].Value = billingModelss[i].Email;
                                                  worksheet.Cells[i + 2, 4].Value = billingModelss[i].Address;
                                                  worksheet.Cells[i + 2, 5].Value = billingModelss[i].City;
                                                  worksheet.Cells[i + 2, 6].Value = billingModelss[i].State;
                                                  worksheet.Cells[i + 2, 7].Value = billingModelss[i].BankName;
                                                  worksheet.Cells[i + 2, 8].Value = billingModelss[i].CardNumber;
                                                  worksheet.Cells[i + 2, 9].Value = billingModelss[i].ExpMonth;

                                                  worksheet.Cells[i + 2, 10].Value = billingModelss[i].ExpYear;

                                                  worksheet.Cells[i + 2, 11].Value = billingModelss[i].CVV;

                                                  worksheet.Cells[i + 2, 12].Value = billingModelss[i].OtherAmount;


                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<BillingModel> GetAllBilling()
                    {
                              var list = employeeDbContext.billingModelsss.ToList();
                              return list;
                    }

                    public List<CustomerdetailsModel> GetAllCustomer()
                    {
                              var custlist = employeeDbContext.customerdetailsModelsss.ToList();
                              return custlist;
                    }





                    public void InsertBillingData(BillingModel billing)
                    {
                              //employeeDbContext.billingModelsss.Add(billing);
                              //employeeDbContext.SaveChanges();
                              if (string.IsNullOrEmpty(billing.Email))
                              {
                                        throw new ArgumentException("Email is required");
                              }

                              employeeDbContext.billingModelsss.Add(billing);
                              employeeDbContext.SaveChanges();
                    }



                    public void UpdateBilling(BillingModel billing)
                    {
                              employeeDbContext.billingModelsss.Update(billing);
                              employeeDbContext.SaveChanges();
                    }

                    public CustomerdetailsModel CustomerDetails(int id)
                    {
                              var customerdetails = employeeDbContext.customerdetailsModelsss.Where(s => s.CustId == id).FirstOrDefault();
                              return customerdetails;
                    }

                    public void CustomerDeletes(int id)
                    {
                              var deletecustomer = employeeDbContext.customerdetailsModelsss.Where(s => s.CustId == id).FirstOrDefault();
                              employeeDbContext.customerdetailsModelsss.Remove(deletecustomer);
                              employeeDbContext.SaveChanges();
                    }

                    public void UpdateCustomer(CustomerdetailsModel updatecusstomer)
                    {
                              employeeDbContext.customerdetailsModelsss.Update(updatecusstomer);
                              employeeDbContext.SaveChanges();

                    }

                    public CommonBillingVoucherDTO commonbilling(int id)
                    {
                              var invoice = employeeDbContext.billingModelsss.FirstOrDefault(s => s.BillingId == id); // Fetch single invoice
                              if (invoice == null) return null;

                              return new CommonBillingVoucherDTO
                              {
                                        voucherid = invoice.BillingId,
                                        FullName = invoice.FullName,
                                        Address = invoice.Address,
                                        //BillingCurrentDate = DateTime.Now.ToString("dd/MM/yyyy"), // Corrected date formatting

                                        BillingCurrentDate = DateOnly.FromDateTime(DateTime.Now),

                                        ItemDescription = invoice.ProductDescription, // Make sure this property exists
                                        itemQuantity = invoice.Quantity,
                                        Rate = invoice.Rate,
                                        Amount = invoice.OtherAmount,
                                        TotalInWords = invoice.TotalInWords, // Optional: Use number-to-word converter here
                                        BankUpi = invoice.Bankupi,
                                        BillingVoucherNumber = invoice.BillingVoucherNumber,

                                        CGST = invoice.CGST,
                                        SGST = invoice.SGST,
                                        IGST = invoice.IGST
                              };
                    }

                    //public void CreateCustomerType(CustomerTypeModel customerType)
                    //{
                    //          employeeDbContext.customerTypemodless.Add(customerType);
                    //          employeeDbContext.SaveChanges();
                    //}

                    //public List<CustomerTypeModel> GetCustomerType()
                    //{
                    //          var listcustomertype = employeeDbContext.customerTypemodless.ToList();
                    //          return listcustomertype;
                    //}

                    public List<CommonBillingVoucherDTO> GetCommonBillingVoucher()
                    {
                              throw new NotImplementedException();
                    }
                    //Billingitemlist
                    //public List<CommonBillingVoucherDTO> GetCommonBillingVoucher()
                    //{
                    //          var billingitemlist = employeeDbContext.billingModelsss.ToList();
                    //          return billingitemlist;
                    //}
          }

}



          
