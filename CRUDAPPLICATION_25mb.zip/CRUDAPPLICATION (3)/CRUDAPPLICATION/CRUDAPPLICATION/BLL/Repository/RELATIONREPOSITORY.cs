﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class RELATIONREPOSITORY : IRelationRepository
    {
        EmployeeDbContext _EMP;
        public RELATIONREPOSITORY(EmployeeDbContext employee)
        {
            this._EMP = employee;
        }
        public void CreateRelaitonModel(RelationModel relationModel)
        {
            _EMP.relationModelss.Add(relationModel);
            _EMP.SaveChanges();
        }

        public void DeleteRelaitonModel(int id)
        {
            var delte = _EMP.relationModelss.Where(s => s.Relat_Id == id).FirstOrDefault();
                        _EMP.relationModelss.Remove(delte);  
                       _EMP.SaveChanges();
        }

        public RelationModel DetailsRelaitonModel(int id)
        {
           var relation=_EMP.relationModelss.Where(s=>s.Relat_Id==id).FirstOrDefault();
            return relation;
        }

        public List<RelationModel> GetRelationModelAll()
        {
            var list = _EMP.relationModelss.ToList();
            return list;
        }

        public void UpdateRelaitonModel(RelationModel relationModel)
        {
            _EMP.relationModelss.Update(relationModel);
            _EMP.SaveChanges();
        }
    }
}
