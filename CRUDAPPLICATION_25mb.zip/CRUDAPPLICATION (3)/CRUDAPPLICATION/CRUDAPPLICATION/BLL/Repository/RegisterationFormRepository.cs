﻿
using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;


namespace CRUDAPPLICATION.BLL.Repository
{
          public class RegisterationFormRepository : IRegisterationFormRepository
          {

                    EmployeeDbContext employeeDbContext;
                    private readonly PasswordHasher<RegisterationForm> _pwHasher;
                    //  private readonly EmailSender emailSender;

                    //  IConfiguration configuration;


                    public RegisterationFormRepository(EmployeeDbContext _employeeDbContext)// IOptions<SmtpSettings> smtpSettings--, IConfiguration _configuration
                    {
                              this.employeeDbContext = _employeeDbContext;
                              //    this.emailSender = _emailSender;
                              //  this.configuration = _configuration;
                              //this._smtpSettings = smtpSettings.Value ?? throw new ArgumentNullException(nameof(smtpSettings));

                              //this._mapper = mapper;
                    }

                    public void CreateRegistertaion(RegisterationForm registerationFormModel)
                    {
                              employeeDbContext.registerationFormsss
                                        .Add(registerationFormModel);
                              employeeDbContext.SaveChanges();
                    }

                    public void DeleteRegistertaion(int id)
                    {
                              var delete = employeeDbContext.registerationFormsss.Where(s => s.id == id).FirstOrDefault();

                              employeeDbContext.registerationFormsss.Remove(delete);
                              employeeDbContext.SaveChanges();
                    }


                    public RegisterationForm GetAllRegisteration(int id)
                    {
                              return employeeDbContext.registerationFormsss.FirstOrDefault(s => s.id == id);
                    }

                    public List<RegisterationForm> GetAllRegisteration()
                    {
                              return employeeDbContext.registerationFormsss.ToList();
                    }

                    public RegisterationFromDTO LoginPage(string username, string password)
                    {
                              var user = employeeDbContext.registerationFormsss
                                  .FirstOrDefault(u => u.Username == username && u.Password == password);

                              if (user != null)
                              {
                                        return new RegisterationFromDTO
                                        {
                                                  Username = user.Username,
                                                  Password = user.Password
                                                  // Add other properties as needed
                                        };
                              }

                              return null;
                    }

                    //public RegisterationForm? Login(string username, string password)
                    //{
                    //          var user = employeeDbContext.registerationFormsss.FirstOrDefault(u => u.Username == username && u.Password == password);
                    //          if (user == null) return null;


                    //          // If you stored hash in DB, use VerifyHashedPassword. Otherwise compare plain text (NOT recommended).
                    //          // Example assumes passwords are hashed in DB. If not hashed, fallback to plain compare.
                    //          try
                    //          {
                    //                    var verify = _pwHasher.VerifyHashedPassword(user, user.Password ?? string.Empty, password ?? string.Empty);
                    //                    if (verify == PasswordVerificationResult.Success || verify == PasswordVerificationResult.SuccessRehashNeeded)
                    //                    {
                    //                              if (!user.isActive) return null;
                    //                              return user;
                    //                    }
                    //                    // fallback plain text
                    //                    if ((user.Password ?? string.Empty).Trim() == (password ?? string.Empty).Trim())
                    //                    {
                    //                              if (!user.isActive) return null;
                    //                              return user;
                    //                    }


                    //                    return null;
                    //          }
                    //          catch
                    //          {
                    //                    // if PasswordHasher fails (e.g., stored plain text), do plain compare
                    //                    if ((user.Password ?? string.Empty).Trim() == (password ?? string.Empty).Trim())
                    //                    {
                    //                              if (!user.isActive) return null;
                    //                              return user;
                    //                    }
                    //                    return null;
                    //          }
                    //}

                    public void UpdateRegistertaion(RegisterationForm registertaion)
                    {
                              employeeDbContext.registerationFormsss.Update(registertaion);
                              employeeDbContext.SaveChanges();
                    }

                    // forgetpassword  
                    public async Task<bool> ResetPasswordAsync(ForgetPasswordUserDto dto)
                    {
                              var user = await employeeDbContext.registerationFormsss
                             .FirstOrDefaultAsync(u => u.Username == dto.Username);

                              if (user == null) return false;

                              // Reset Password Logic
                              user.Password = dto.NewPassword;
                              user.ConformPassword = dto.ConfirmNewPassword;// Ideally hashed, e.g., using BCrypt or Identity
                              await employeeDbContext.SaveChangesAsync();
                              return true;
                    }
                    // UserForgetAsync-- UserForget  


                    public async Task<bool> UserForgetAsync(UserForget dto1)
                    {
                           var user1 =  employeeDbContext.registerationFormsss
                             .FirstOrDefault(s=>s.Password == dto1.NewPassword);

                              if (user1 == null) return false;

                              //// Reset Password Logic
                              user1.Username = dto1.Username;
                              //user1.Password = dto.NewPassword;
                              //user.ConformPassword = dto.ConfirmNewPassword;// Ideally hashed, e.g., using BCrypt or Identity
                              await employeeDbContext.SaveChangesAsync();
                              return true;
                    }

                    public RegisterationFromDTO GetUserByUsername(string username)
                    {
                              return employeeDbContext.registerationFormsss.Where(u => u.Username == username)
                                   .Select(user => new RegisterationFromDTO
                                   {
                                             Username = user.Username,
                                             Password = user.Password
                                             // Map other properties as needed
                                   })
                                   .FirstOrDefault();


                    }

                   
          }

}


    