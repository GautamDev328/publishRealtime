﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class AddRelationShipRepository : IAddRelationRepository
          {
                    EmployeeDbContext employeeDbContext;
                    public AddRelationShipRepository(EmployeeDbContext _employeeDbContext)
                    {
                              this.employeeDbContext = _employeeDbContext;
                    }

                    public void AddRelationShip(AddRelationShipModel model)
                    {
                              employeeDbContext.addRelationShipModelss.Add(model);
                              employeeDbContext.SaveChanges();
                    }

                    public void DeleteRelationShip(int id)
                    {
                              var delete = employeeDbContext.addRelationShipModelss.Where(s => s.Relation_id == id).FirstOrDefault();
                              employeeDbContext.addRelationShipModelss.Remove(delete);
                              employeeDbContext.SaveChanges();
                    }

                    public AddRelationShipModel DetailsRelationship(int id)
                    {
                              var details = employeeDbContext.addRelationShipModelss.Where(s => s.Relation_id == id).FirstOrDefault();
                              return details;
                    }

                    public List<AddRelationShipModel> AllAddRelationShips()
                    {
                              var list = employeeDbContext.addRelationShipModelss.ToList();
                              return list;
                    }

                    public void UpdateRealtionShip(AddRelationShipModel model)
                    {
                              employeeDbContext.addRelationShipModelss.Update(model);
                              employeeDbContext.SaveChanges();
                    }

                    public byte[] GenerateaddrelationExcelFile(List<AddRelationShipModel> addRelationShipModelss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("addRelationShipModelss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Relation_id";
                                        worksheet.Cells[1, 2].Value = "AddRelationShip";

                                        // Add data
                                        for (int i = 0; i < addRelationShipModelss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = addRelationShipModelss[i].Relation_id;
                                                  worksheet.Cells[i + 2, 2].Value = addRelationShipModelss[i].AddRelationShip;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }
          }
}
