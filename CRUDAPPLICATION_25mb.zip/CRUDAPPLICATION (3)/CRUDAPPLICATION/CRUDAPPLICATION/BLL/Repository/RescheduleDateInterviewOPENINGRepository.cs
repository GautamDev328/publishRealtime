﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class RescheduleDateInterviewOPENINGRepository:IRescheduleDateInterviewOPENINGRepository
          {
                    public EmployeeDbContext empdbcontext;
        public RescheduleDateInterviewOPENINGRepository(EmployeeDbContext _empdbcontext)
        {
                              this.empdbcontext = _empdbcontext;      
        }

                    public void CreateRescheduleDate(RescheduleDateInterviewOPENINGMODEL model)
                    {
                              empdbcontext.rescheduleDatess.Add(model);
                              empdbcontext.SaveChanges();
                    }

                    public void DeleteRescheduleDate(int id)
                    {
                              var deleterescheduledate = empdbcontext.rescheduleDatess.Where(s => s.RescheduleId == id).FirstOrDefault();
                              empdbcontext.rescheduleDatess.Remove(deleterescheduledate);
                              empdbcontext.SaveChanges();
                    }

                    public RescheduleDateInterviewOPENINGMODEL DetailRescheduleDate(int id)
                    {
                              var detailsrescheduledate = empdbcontext.rescheduleDatess.Where(s => s.RescheduleId == id).FirstOrDefault();
                              return detailsrescheduledate;
                    }

                    public byte[] GenerateRescheduleDateExcelFile(List<RescheduleDateInterviewOPENINGMODEL> RescheduleDate)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("rescheduleDatess");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "RescheduleId";
                                        worksheet.Cells[1, 2].Value = "FirstName";
                                        worksheet.Cells[1, 3].Value = "MiddleName";
                                        worksheet.Cells[1, 4].Value = "LastName";
                                        worksheet.Cells[1, 5].Value = "Address";
                                        worksheet.Cells[1, 6].Value = "MobileNumber";
                                        worksheet.Cells[1, 7].Value = "InterviewerName";
                                        worksheet.Cells[1, 8].Value = "InterviewSchedue";
                                        worksheet.Cells[1, 9].Value = "PositionApplied_DesignationName";
                                        worksheet.Cells[1, 10].Value = "TotalExperience";
                                        worksheet.Cells[1, 11].Value = "HIGHEREDUCATION";
                                        worksheet.Cells[1, 12].Value = "ReasonRescheduechangedatetime";
                                        worksheet.Cells[1, 13].Value = "interviewReasoncancelled";
                                        worksheet.Cells[1, 14].Value = "FEEBACK";
                                       

                                        // Add data
                                        for (int i = 0; i < RescheduleDate.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = RescheduleDate[i].RescheduleId;
                                                  worksheet.Cells[i + 2, 2].Value = RescheduleDate[i].FirstName;
                                                  worksheet.Cells[i + 2, 3].Value = RescheduleDate[i].MiddleName;
                                                  worksheet.Cells[i + 2, 4].Value = RescheduleDate[i].LastName;
                                                  worksheet.Cells[i + 2, 5].Value = RescheduleDate[i].Address;
                                                  worksheet.Cells[i + 2, 6].Value = RescheduleDate[i].MobileNumber;
                                                  worksheet.Cells[i + 2, 7].Value = RescheduleDate[i].InterviewerName;
                                                  worksheet.Cells[i + 2, 8].Value = RescheduleDate[i].InterviewSchedue;
                                                  worksheet.Cells[i + 2, 9].Value = RescheduleDate[i].PositionApplied_DesignationName;
                                                  worksheet.Cells[i + 2, 10].Value = RescheduleDate[i].TotalExperience;
                                                  worksheet.Cells[i + 2, 11].Value = RescheduleDate[i].HIGHEREDUCATION;
                                                  worksheet.Cells[i + 2, 12].Value = RescheduleDate[i].ReasonRescheduechangedatetime;
                                                  worksheet.Cells[i + 2, 13].Value = RescheduleDate[i].interviewReasoncancelled;
                                                  worksheet.Cells[i + 2, 14].Value = RescheduleDate[i].FEEBACK;
                                                 
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<RescheduleDateInterviewOPENINGMODEL> GetAllRescheduleDate()
                    {
                              var lstReschduledate = empdbcontext.rescheduleDatess.ToList();
                              return lstReschduledate;
                    }

                    public RescheduleDateInterviewOPENINGMODEL SearchById(int id)
                    {
                              var searchRescheduleDate = empdbcontext.rescheduleDatess.Where(s => s.RescheduleId == id).FirstOrDefault();
                              return searchRescheduleDate;
                    }

                    public void UpdateRescheduleDate(RescheduleDateInterviewOPENINGMODEL models)
                    {
                              empdbcontext.rescheduleDatess.Update(models);
                              empdbcontext.SaveChanges();
                    }
          }
}
