﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class HighestQualificaitonRepository:IHigherQualificationRepository
          {
                    public EmployeeDbContext dbcontext;
        public HighestQualificaitonRepository(EmployeeDbContext _dbcontext)
        {
                    dbcontext = _dbcontext;       
        }

                    public void AddHighestQualification(HigherQualificationModel higherQualificationModel)
                    {
                             dbcontext.higherQualificationModelss.Add(higherQualificationModel);     
                              dbcontext.SaveChanges();
                              
                    }

                    public List<HigherQualificationModel> AllHighestQualification()
                    {
                              var list= dbcontext.higherQualificationModelss.ToList();     
                              return list;
                    }

                    public HigherQualificationModel DeleteHighestQualificationById(int id)
                    {
                              var data = dbcontext.higherQualificationModelss.Where(s => s.highId == id).FirstOrDefault(); ;
                              dbcontext.higherQualificationModelss.Remove(data);
                              dbcontext.SaveChanges();
                              return data;        
                    }

                    public HigherQualificationModel DetailsHighestQualificationById(int id)
                    {
                              var data = dbcontext.higherQualificationModelss.Where(s => s.highId == id).FirstOrDefault(); ;
                              return data;
                    }

                    public void UpdateHighestQualification(HigherQualificationModel higherQualificationModel)
                    {
                              dbcontext.higherQualificationModelss.Update(higherQualificationModel);
                              dbcontext.SaveChanges();
                    }
          }
}
