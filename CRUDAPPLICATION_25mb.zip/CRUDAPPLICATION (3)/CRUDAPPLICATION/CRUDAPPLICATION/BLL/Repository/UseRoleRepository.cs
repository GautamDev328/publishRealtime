﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class UseRoleRepository : IUseRoleRepository
    {
       private readonly  EmployeeDbContext _emp;
        public UseRoleRepository(EmployeeDbContext emp)
        {
            this._emp = emp;  
        }
        public void DeleteUseRole(int id)
        {
          var del=_emp.useRoleWiseModelss.Where(s=>s.Id==id).FirstOrDefault();   
                   _emp.useRoleWiseModelss.Remove(del);
            _emp.SaveChanges();
        }

        public UseRoleWiseModel DetailsUseRole(int id)
        {
           var details= _emp.useRoleWiseModelss.Where(s=>s.Id== id).FirstOrDefault();
            return  details;
        }

        public List<UseRoleWiseModel> GetUseRoleWiseModels()
        {
            var list = _emp.useRoleWiseModelss.ToList();
            return list;
        }

        public void InsertUseRole(UseRoleWiseModel useRole)
        {
            _emp.useRoleWiseModelss.Add(useRole);
            _emp.SaveChanges();
        }

        public void UpdateUseRole(UseRoleWiseModel useRole)
        {
           _emp.useRoleWiseModelss.Update(useRole);
            _emp.SaveChanges();
        }
    }
}
