﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class CityRepository : ICityRepository
          {
                    EmployeeDbContext _EmployeeDbContext;
                    public CityRepository(EmployeeDbContext EmployeeDbContext)

                    {
                              this._EmployeeDbContext = EmployeeDbContext;

                    }

                    public void CreateCity(City city)
                    {
                              _EmployeeDbContext.cityss.Add(city);
                              _EmployeeDbContext.SaveChanges();
                    }

                    public void DeleteCity(int id)
                    {
                              var a = _EmployeeDbContext.cityss.Where(s => s.City_Id == id).FirstOrDefault();
                              _EmployeeDbContext.cityss.Remove(a);
                              _EmployeeDbContext.SaveChanges();


                    }

                    //public void DetailsCity(int id )
                    //{
                    //    _EmployeeDbContext.citys.Where(s => s.City_Id == id).FirstOrDefault();
                    //    _EmployeeDbContext.SaveChanges();
                    //}

                    public List<City> GetCities()
                    {
                              var list = _EmployeeDbContext.cityss.ToList();
                              return list;
                    }



                    public void UpdateCity(City city)
                    {
                              _EmployeeDbContext.cityss.Update(city);
                              _EmployeeDbContext.SaveChanges();


                    }



                    public City DetailCity(int id)
                    {
                              var a = _EmployeeDbContext.cityss.Where(s => s.City_Id == id).FirstOrDefault();
                              return a;
                    }

                    public City SearchById(int id)
                    {
                              var b = _EmployeeDbContext.cityss.Where(s => s.City_Id == id).FirstOrDefault();
                              return b;
                    }

                    //Excel Export 
                    public byte[] GenerateCitiesExcelFile(List<City> cities)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("cityss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "City ID";
                                        worksheet.Cells[1, 2].Value = "City Name";
                                        worksheet.Cells[1, 3].Value = "State Name";

                                        // Add data
                                        for (int i = 0; i < cities.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = cities[i].City_Id;
                                                  worksheet.Cells[i + 2, 2].Value = cities[i].City_Name;
                                                  worksheet.Cells[i + 2, 3].Value = cities[i].StateName;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

          }
}