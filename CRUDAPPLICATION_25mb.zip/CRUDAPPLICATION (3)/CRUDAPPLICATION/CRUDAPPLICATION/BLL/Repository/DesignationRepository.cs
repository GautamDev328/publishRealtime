﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class DesignationRepository : IDesignationRepository
    {
        EmployeeDbContext EmployeeDb;
        public DesignationRepository(EmployeeDbContext _employeeDb)
        {
            this.EmployeeDb = _employeeDb;

        }


        public void CreateDesignation(DesignationModel designationModel)
        {
            EmployeeDb.designationss.Add(designationModel);
            EmployeeDb.SaveChanges();
        }

        public void DeleteDesignationModel(int  id)
        {
            var delete = EmployeeDb.designationss.Where(s => s.DesigId == id).FirstOrDefault();
                   EmployeeDb.designationss.Remove(delete);
            EmployeeDb.SaveChanges();
        }

       

      
        public DesignationModel DetailsDesignationModel(int id)
        {
           var details=EmployeeDb.designationss.Where(s=>s.DesigId==id).FirstOrDefault();
            return details;
        }

        public List<DesignationModel> GetALLDesignationData()
        {
            var list = EmployeeDb.designationss.ToList();
            return list;
        }

     

        public void UpdateDesignationModel(DesignationModel designationModel)
        {
            EmployeeDb.designationss.Update(designationModel);
                              EmployeeDb.SaveChanges();
        }
                    public IQueryable<DesignationModel> GetDesignationsByDepartment(int departmentId)
                    {
                              return EmployeeDb.designationss.Where(d => d.DesigId == departmentId);
                    }
                    // ExcelExport filr 
                    public byte[] GenerateDesignationExcelFile(List<DesignationModel> designationModelss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("designationss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "DesigId";
                                        worksheet.Cells[1, 2].Value = "CustomerExtraPrice";
                                        worksheet.Cells[1, 3].Value = "DesigName";

                                        // Add data
                                        for (int i = 0; i < designationModelss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = designationModelss[i].DesigId;
                                                  worksheet.Cells[i + 2, 2].Value = designationModelss[i].DesigType;
                                                  worksheet.Cells[i + 2, 3].Value = designationModelss[i].DesigName;


                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }
          }
}
