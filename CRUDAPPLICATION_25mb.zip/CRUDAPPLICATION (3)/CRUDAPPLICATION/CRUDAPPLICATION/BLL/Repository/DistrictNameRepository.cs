﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class DistrictNameRepository : IdistrictNameRepository
          {
                    public EmployeeDbContext _dbcontext;
                    public DistrictNameRepository(EmployeeDbContext employeeDb)
                    {
                                     this._dbcontext=employeeDb;      
                    }
                    public void CreateDistrict(DistrictNameModel objdistrictname)
                    {
                             _dbcontext.districtNameModelss.Add(objdistrictname);
                              _dbcontext.SaveChanges();
                    }

                    public void DeleteDistrict(int id)
                    {
                              var delete = _dbcontext.districtNameModelss.Where(s => s.DistrictId == id).FirstOrDefault();
                                          _dbcontext.districtNameModelss.Remove(delete);
                              _dbcontext.SaveChanges();
                              
                    }

                    public DistrictNameModel DetailsDistrict(int id)
                    {
                         var districtname=_dbcontext.districtNameModelss.Where(s=>s.DistrictId==id).FirstOrDefault();
                              return districtname;
                    }

                    public List<DistrictNameModel> lstdistrictmode()
                    {
                              var list = _dbcontext.districtNameModelss.ToList();
                               return list;       
                    }

                    public void UpdateDistrict(DistrictNameModel objdistrictname)
                    {
                           _dbcontext.districtNameModelss.Update(objdistrictname);
                              _dbcontext.SaveChanges();     
                    }
          }
}
