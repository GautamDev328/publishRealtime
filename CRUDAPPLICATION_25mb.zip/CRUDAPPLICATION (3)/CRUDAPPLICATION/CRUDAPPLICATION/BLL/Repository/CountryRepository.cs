﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class CountryRepository : ICountryRepository
    {
        EmployeeDbContext employeeDbContext;
        public CountryRepository(EmployeeDbContext employeeDbContext)
        {
            this.employeeDbContext = employeeDbContext;

        }
        //public void Create(Country country)
        //{
        //    employeeDbContext.countries.Add(country);
        //    employeeDbContext.SaveChanges();
        //}

        public void CreateCountry(Country country)
        {
            employeeDbContext.countriess.Add(country);
            employeeDbContext.SaveChanges();
        }

        public void DeleteCountry(int id)
        {
            var a = employeeDbContext.countriess.Where(s => s.Id == id).FirstOrDefault();
            employeeDbContext.countriess.Remove(a);
            employeeDbContext.SaveChanges();

        }

        public Country DetailsCountry(int id)
        {
            var a = employeeDbContext.countriess.Where(s => s.Id == id).FirstOrDefault();
            return a;
        }

                    public byte[] GenerateCountryExcelFile(List<Country> countriess)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("countriess");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Id";
                                        worksheet.Cells[1, 2].Value = "CountryName";

                                        // Add data
                                        for (int i = 0; i < countriess.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = countriess[i].Id;
                                                  worksheet.Cells[i + 2, 2].Value = countriess[i].CountryName;                                     worksheet.Cells[1, 2].Value = "Id";
;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<Country> GETCOUNTRYALL()
        {
            var list = employeeDbContext.countriess.ToList();
            return list;
        }

        public Country SearChById(int id)
        {
            var a = employeeDbContext.countriess.Where(s => s.Id == id).FirstOrDefault();
            return a;
        }

        public void UpdateCountry(Country country)
        {
            employeeDbContext.countriess.Update(country);
            employeeDbContext.SaveChanges();
        }
    }
}
