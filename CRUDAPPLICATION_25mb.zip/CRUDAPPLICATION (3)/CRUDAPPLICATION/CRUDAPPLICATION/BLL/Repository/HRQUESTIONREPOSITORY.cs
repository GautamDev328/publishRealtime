﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class HRQUESTIONREPOSITORY:IHRQUESTIONREPOSITORY
          {
                    public EmployeeDbContext _empdbcontext;
        public HRQUESTIONREPOSITORY(EmployeeDbContext _dbcontextg)
        {
                              this._empdbcontext = _dbcontextg;       
        }

                    public void AddHRQUESTIONMODEL(HRQUESTIONMODEL hRQUESTIONMODEL)
                    {
                          _empdbcontext.HRQUESTIONMODELss.Add(hRQUESTIONMODEL);  
                              _empdbcontext.SaveChanges();
                    }

                    public void DeleteHRQUESTIONMODEL(int id)
                    {
                           var delete= _empdbcontext.HRQUESTIONMODELss.Find(id);
                              _empdbcontext.HRQUESTIONMODELss.Remove(delete);
                              _empdbcontext.SaveChanges();
                    }

                    public HRQUESTIONMODEL DetailsHRQUESTIONMODEL(int id)
                    {
                            _empdbcontext.HRQUESTIONMODELss.Find(id);
                              return _empdbcontext.HRQUESTIONMODELss.Find(id);   
                    }

                    public byte[] GeneratesHRQUESTIONExcelFile(List<HRQUESTIONMODEL> hRQUESTIONMODELs)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("hRQUESTIONMODELss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "HRQUESITON ID";
                                        worksheet.Cells[1, 2].Value = "HRKEYNUMBER";
                                        worksheet.Cells[1, 3].Value = "HrQuestionKey";

                                        // Add data
                                        for (int i = 0; i < hRQUESTIONMODELs.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = hRQUESTIONMODELs[i].HRQUESITONID;
                                                  worksheet.Cells[i + 2, 2].Value = hRQUESTIONMODELs[i].HRKEYNUMBER;
                                                  worksheet.Cells[i + 2, 3].Value = hRQUESTIONMODELs[i].HrQuestionKey;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<HRQUESTIONMODEL> GetHRQUESTIONMODEL()
                    {
                         _empdbcontext.HRQUESTIONMODELss.ToList();
                              return _empdbcontext.HRQUESTIONMODELss.ToList();
                    }

                    public void UpdateHRQUESTIONMODEL(HRQUESTIONMODEL hRQUESTIONMODEL)
                    {
                         _empdbcontext.HRQUESTIONMODELss.Update(hRQUESTIONMODEL);
                              _empdbcontext.SaveChanges();
                    }
          }
}
