﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class Auot_CustomerhelpRepository : IAuot_CustomerhelpRepository
          {
                      public EmployeeDbContext _employeeDbContext;
                    public Auot_CustomerhelpRepository(EmployeeDbContext employeeDbContext)
                    {
                              _employeeDbContext = employeeDbContext;  
                    }

                    public void CreateCustomerHelper(Auot_CustomerhelpModel Auot)
                    {
                              _employeeDbContext.auot_CustomerhelpModelsss.Add(Auot);
                              _employeeDbContext.SaveChanges();
                    }

                    public void DeleteCustomerHelper(int id)
                    {
                              var delete = _employeeDbContext.auot_CustomerhelpModelsss.Where(s => s.CustomerId == id).FirstOrDefault();
                              _employeeDbContext.auot_CustomerhelpModelsss.Remove(delete);
                              _employeeDbContext.SaveChanges();
                    }

                    public Auot_CustomerhelpModel DetailCustomerHelper(int id)
                    {
                              var detais = _employeeDbContext.auot_CustomerhelpModelsss.Where(s => s.CustomerId == id).FirstOrDefault();
                              return detais;
                    }

                    public byte[] GenerateBankExcelFile(List<Auot_CustomerhelpModel> autoModelss)
                    {
                              throw new NotImplementedException();
                    }

                    public List<Auot_CustomerhelpModel> GetAllCustomer()
                    {
                              var list = _employeeDbContext.auot_CustomerhelpModelsss.ToList();
                              return list;
                    }

                    public void UpdateCustomerHelper(Auot_CustomerhelpModel Auot)
                    {
                              _employeeDbContext.auot_CustomerhelpModelsss.Update(Auot);
                              _employeeDbContext.SaveChanges();
                    }

          }
}
