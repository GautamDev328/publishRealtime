﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class CustomerPaymentRepository : ICustomerPaymentRepository
    {
        private EmployeeDbContext employeeDbContext;
        public CustomerPaymentRepository(EmployeeDbContext _employeeDbContext)
        {
            this.employeeDbContext = _employeeDbContext;
        }
        public List<PaymentCustomerExtraUserModel> GetAllPaymewntCustomer()
        {
            var list = employeeDbContext.paymentCustomeExtraUserModelss.ToList();
            return list;
        }
        public void UpdatePaymentCustomer(PaymentCustomerExtraUserModel paymentCustomerExtraUser)
        {
            employeeDbContext.paymentCustomeExtraUserModelss.Update(paymentCustomerExtraUser);
            employeeDbContext.SaveChanges();
        }
        public PaymentCustomerExtraUserModel SearchPaymentUser(int id)
        {
            //var search = employeeDbContext.paymentCustomeExtraUserModels.Where(s => s.paymentId ==id).FirstOrDefault();
            var search= employeeDbContext.paymentCustomeExtraUserModelss.Where(s=>s.id==id).FirstOrDefault();
            return search;
          //  return search;
        }
        public void InsertPaymentCustomer(PaymentCustomerExtraUserModel paymentCustomerExtraUser)
        {
            employeeDbContext.paymentCustomeExtraUserModelss.Add(paymentCustomerExtraUser);
            employeeDbContext.SaveChanges();
        }

                    public byte[] GenerateCcustomerpaymentExcelFile(List<PaymentCustomerExtraUserModel> paymentCustomerExtraUserModelss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("paymentCustomeExtraUserModels");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "id";
                                        worksheet.Cells[1, 2].Value = "Device_Serials";
                                        worksheet.Cells[1, 3].Value = "OtherCharges";

                                        // Add data
                                        for (int i = 0; i < paymentCustomerExtraUserModelss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = paymentCustomerExtraUserModelss[i].id;
                                                  worksheet.Cells[i + 2, 2].Value = paymentCustomerExtraUserModelss[i].Device_Serials;
                                                  worksheet.Cells[i + 2, 3].Value = paymentCustomerExtraUserModelss[i].OtherCharges;

                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }
          }
}
