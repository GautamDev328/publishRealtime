﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class RolewiseonlyemployeeRepository : IRolewiseonlyemployeeRepository
    {
        EmployeeDbContext dbcontext;
        public RolewiseonlyemployeeRepository(EmployeeDbContext _dbcontext)
        {
            this.dbcontext = _dbcontext;

        }

        public void AddRoleWiseonlyemployee(RoleWiseOnlyEmployee rolewiseonlyemployee)
        {
            dbcontext.RoleWiseOnlyEmployeess.Add(rolewiseonlyemployee);
            dbcontext.SaveChanges();
        }

        public void DeleteRoleWiseonlyemployee(int id)
        {
            var delete = dbcontext.RoleWiseOnlyEmployeess.Where(s => s.RoleWiseonlyId == id).FirstOrDefault();
                        dbcontext.RoleWiseOnlyEmployeess.Remove(delete); 
                        dbcontext.SaveChanges();
        }

        public RoleWiseOnlyEmployee DetailsRoleWiseonlyemployee(int id)
        {
            var details = dbcontext.RoleWiseOnlyEmployeess.Where(s => s.RoleWiseonlyId == id).FirstOrDefault();
            return details;
        }

        public List<RoleWiseOnlyEmployee> GetAllRoleWiseonlyemployee()
        {
            var list = dbcontext.RoleWiseOnlyEmployeess.ToList();
            return list;
        }

        public void UpdateRoleWiseonlyemployee(RoleWiseOnlyEmployee relationModel)
        {
           dbcontext.RoleWiseOnlyEmployeess.Update(relationModel);
            dbcontext.SaveChanges();
        }
    }
}
