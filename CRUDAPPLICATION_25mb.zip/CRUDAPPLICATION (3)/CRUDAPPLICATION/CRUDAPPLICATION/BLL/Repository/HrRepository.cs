﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class HrRepository : IHrRepsitory
    {
        EmployeeDbContext employeeDb;
        public HrRepository(EmployeeDbContext _employeeDbContext)
        {
            this.employeeDb = _employeeDbContext;
        }
        public List<HRProfile> AllHrProfile()
        {
            var list = employeeDb.hRProfiless.ToList();
            return list;
        }

        public void CreateHrProfile(HRProfile hrProfile)
        {
            employeeDb.hRProfiless.Add(hrProfile);
            employeeDb.SaveChanges();
        }

        public void DeleteHrProfile(int id)
        {
            var delete = employeeDb.hRProfiless.Where(s => s.HR_Id == id).FirstOrDefault();
                          employeeDb.hRProfiless.Remove(delete);
                       employeeDb.SaveChanges();
        }

        public HRProfile DetailHrProfile(int id)
        {
            var details= employeeDb.hRProfiless.Where(s=>s.HR_Id==id).FirstOrDefault();//Linque query
            return details;
        }



        public void UpdateHrProfile(HRProfile hrProfile)
        {
            employeeDb.hRProfiless.Update(hrProfile);
            employeeDb.SaveChanges(true);
        }
    }
}
