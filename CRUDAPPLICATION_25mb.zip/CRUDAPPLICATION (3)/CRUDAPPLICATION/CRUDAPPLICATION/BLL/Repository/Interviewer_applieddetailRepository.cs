﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class Interviewer_applieddetailRepository : IInterviewer_applieddetailRepository
          {
                    public EmployeeDbContext _dbcontext;
        public Interviewer_applieddetailRepository(EmployeeDbContext dbcontext)
        {
                    this._dbcontext = dbcontext;
        }
        public void CreateInterviewer_applieddetail(Interviewer_applieddetail_Models model)
                    {
                              _dbcontext.interviewer_applieddetailModelss.Add(model);
                              _dbcontext.SaveChanges();
                    }

                    public void DeleteInterviewer_applieddetail(int id)
                    {
                              var deleteinterviewdetails = _dbcontext.interviewer_applieddetailModelss.Where(s => s.interviewID == id).FirstOrDefault();
                              _dbcontext.interviewer_applieddetailModelss.Remove(deleteinterviewdetails);
                              _dbcontext.SaveChanges();
                    }

                    public Interviewer_applieddetail_Models DetailInterviewer_applieddetail(int id)
                    {
                              var detailsinterviewerdetails = _dbcontext.interviewer_applieddetailModelss.Where(s => s.interviewID == id).FirstOrDefault();
                              return detailsinterviewerdetails;
                    }

                              public byte[] GenerateInterviewer_applieddetailExcelFile(List<Interviewer_applieddetail_Models> interviewapplieddetail)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("interviewer_applieddetailModelss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "interviewID";
                                        worksheet.Cells[1, 2].Value = "FirstName";
                                        worksheet.Cells[1, 3].Value = "MiddleName";
                                        worksheet.Cells[1, 4].Value = "LastName";
                                        worksheet.Cells[1, 5].Value = "EmailAddress";
                                        worksheet.Cells[1, 6].Value = "Address";
                                        worksheet.Cells[1, 7].Value = "HIGHEREDUCATION";
                                        worksheet.Cells[1, 8].Value = "MobileNumber";
                                        worksheet.Cells[1, 9].Value = "InterviewerName";
                                        worksheet.Cells[1, 10].Value = "Skill";
                                        worksheet.Cells[1, 11].Value = "InterviewerAccept";
                                      //  worksheet.Cells[1, 12].Value = "InterviewerReJECT";
                                        worksheet.Cells[1, 12].Value = "InterviewerStatus";
                                        worksheet.Cells[1, 13].Value = "lastestReschdueDate_time";
                                        worksheet.Cells[1, 14].Value = "Resume_CV";
                                        worksheet.Cells[1, 15].Value = "fEEDBACK";
                                       

                                        // Add data
                                        for (int i = 0; i < interviewapplieddetail.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = interviewapplieddetail[i].interviewID;
                                                  worksheet.Cells[i + 2, 2].Value = interviewapplieddetail[i].FirstName;
                                                  worksheet.Cells[i + 2, 3].Value = interviewapplieddetail[i].MiddleName;
                                                  worksheet.Cells[i + 2, 4].Value = interviewapplieddetail[i].LastName;
                                                  worksheet.Cells[i + 2, 5].Value = interviewapplieddetail[i].EmailAddress;
                                                  worksheet.Cells[i + 2, 6].Value = interviewapplieddetail[i].Address;
                                                  worksheet.Cells[i + 2, 7].Value = interviewapplieddetail[i].HIGHEREDUCATION;
                                                  worksheet.Cells[i + 2, 8].Value = interviewapplieddetail[i].MobileNumber;
                                                  worksheet.Cells[i + 2, 9].Value = interviewapplieddetail[i].InterviewerName;
                                                  worksheet.Cells[i + 2, 10].Value = interviewapplieddetail[i].Skill;
                                                  worksheet.Cells[i + 2, 11].Value = interviewapplieddetail[i].InterviewerAccept_Reject;
                                                //  worksheet.Cells[i + 2, 12].Value = interviewapplieddetail[i].InterviewerReJECT;
                                                  worksheet.Cells[i + 2, 12].Value = interviewapplieddetail[i].InterviewerStatus;
                                                  worksheet.Cells[i + 2, 13].Value = interviewapplieddetail[i].lastestReschdueDate_time;
                                                  worksheet.Cells[i + 2, 14].Value = interviewapplieddetail[i].Resume_CV;
                                                  worksheet.Cells[i + 2, 15].Value = interviewapplieddetail[i].fEEDBACK;
                                               

                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<Interviewer_applieddetail_Models> GetAllInterviewer_applieddetail()
                    {
                              var lsitinterviewerapplieddetail = _dbcontext.interviewer_applieddetailModelss.ToList();
                              return lsitinterviewerapplieddetail;
                    }

                    public Interviewer_applieddetail_Models SearchById(int id)
                    {
                              var searchinterviewerapplieddetail = _dbcontext.interviewer_applieddetailModelss.Where(s => s.interviewID == id).FirstOrDefault();
                              return searchinterviewerapplieddetail;
                    }

                    public void UpdateInterviewer_applieddetail(Interviewer_applieddetail_Models models)
                    {
                              _dbcontext.interviewer_applieddetailModelss.Update(models);
                              _dbcontext.SaveChanges();
                    }
          }
}
