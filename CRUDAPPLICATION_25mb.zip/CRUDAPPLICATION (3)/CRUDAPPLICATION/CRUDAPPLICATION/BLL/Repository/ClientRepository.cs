﻿          using CRUDAPPLICATION.BLL.IRepository;
          using CRUDAPPLICATION.DATABASE;
          using CRUDAPPLICATION.Model;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
          {
              public class ClientRepository : IClientRepository
              {
                  EmployeeDbContext employeeDbContext;
                  public ClientRepository(EmployeeDbContext _employeeDbContext)
                  {
                      this.employeeDbContext = _employeeDbContext;
                
                  }
                  public List<ClientModel> Allclientmodel()
                  {
                      var list = employeeDbContext.clientModelss.ToList();
                      return list;
                  }

                              public void  DeleteClientmodel(int clientid)
                              {
                                        //list=> object 
                                        var list=employeeDbContext.clientModelss.Where(s=>s.Client_Id==clientid).FirstOrDefault();
                                        employeeDbContext.clientModelss.Remove(list);
                              employeeDbContext.SaveChanges();
                              }

                              public ClientModel DetailsClientmodel(int clientid)
                              {
                                 var a= employeeDbContext.clientModelss.Where(s => s.Client_Id == clientid).FirstOrDefault();
                              return a;
                              }

                    public byte[] GenerateClinetExcelFile(List<ClientModel> clientss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("clientModels");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Client_Id";
                                        worksheet.Cells[1, 2].Value = "ClientName";
                                        worksheet.Cells[1, 3].Value = "Photo";
                                       

                                        // Add data
                                        for (int i = 0; i < clientss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = clientss[i].Client_Id;
                                                  worksheet.Cells[i + 2, 2].Value = clientss[i].ClientName;
                                                  worksheet.Cells[i + 2, 3].Value = clientss[i].Photo;
                                                 


                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public void InsertClientmodel(ClientModel clientmodel)
                                      {
                                          employeeDbContext.clientModelss.Add(clientmodel);
                                          employeeDbContext.SaveChanges();
                                      }

                              public void UpdateClientmodel(ClientModel clientmodel)
                              {
                                 employeeDbContext.clientModelss.Update(clientmodel);      
                                      employeeDbContext.SaveChanges();
                              }
                    }
          }
