﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class GenderRepository : IGenderRepository
    {
        EmployeeDbContext employeeDbContext;
        public GenderRepository(EmployeeDbContext _employeeDbContext)
        {
            this.employeeDbContext = _employeeDbContext;

        }
        public void CreateGender(Gender gender)
        {
            employeeDbContext.genders.Add(gender);
            employeeDbContext.SaveChanges();
        }

        public void DeleteDepartment(Gender gender)
        {
                              throw new NotImplementedException();


                    }

                    public void DetailsDepartment(Gender gender)
        {
            throw new NotImplementedException();
        }

                    //public byte[] GenerateGenderExcelFile(List<Gender> genderss)
                    //{
                    //          using (var package = new ExcelPackage())
                    //          {
                    //                    var worksheet = package.Workbook.Worksheets.Add("gender");

                    //                    // Add headers
                    //                    worksheet.Cells[1, 1].Value = "Gen_Id";
                    //                    worksheet.Cells[1, 2].Value = "Gen_Name";
                                       
                    //                    // Add data
                    //                    for (int i = 0; i < genderss.Count; i++)
                    //                    {
                    //                              worksheet.Cells[i + 2, 1].Value = genderss[i].Gen_Id;
                    //                              worksheet.Cells[i + 2, 2].Value = genderss[i].Gen_Name;
                                                
                    //                    }

                    //                    // Auto-fit columns
                    //                    worksheet.Cells.AutoFitColumns();

                    //                    return package.GetAsByteArray();
                    //          }

                              public List<Gender> GetGenderAll()
        {
            var list = employeeDbContext.genders.ToList();
            return list;
        }

        public void SearchById(int id)
        {
            throw new NotImplementedException();
        }

        public void UpdateGender(Gender gender)
        {
            throw new NotImplementedException();
        }
    }
}
