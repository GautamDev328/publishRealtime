﻿
using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using OfficeOpenXml;
using OfficeOpenXml.FormulaParsing.Excel.Functions.RefAndLookup;
using System.Net.Mail;

namespace CRUDAPPLICATION.BLL.Repository
{
          public class InterviewApplicationFomRepository : IInterviewApplicationFomRepository
          {
                    public EmployeeDbContext dbcontext;
                    public InterviewApplicationFomRepository(EmployeeDbContext _dbcontext)
                    {
                              // this.mapper = _mapper;        

                              this.dbcontext = _dbcontext;
                    }





                    public void Createinterviewapplicaiton(InterviewApplicationFormModel model)
                    {
                              
                              dbcontext.interviewApplicationFormModelss.Add(model);
                              dbcontext.SaveChanges();

                    }


               
                    

          

                    public void Deleteinterviewapplicaitony(int id)
                    {
                              var deleteinterview = dbcontext.interviewApplicationFormModelss.Where(s => s.interviewApplicationId == id).FirstOrDefault();
                              dbcontext.interviewApplicationFormModelss.Remove(deleteinterview);
                              dbcontext.SaveChanges();
                    }

                    public InterviewApplicationFormModel Detailinterviewapplicaitony(int id)
                    {
                              var detailsinterview = dbcontext.interviewApplicationFormModelss.Where(s => s.interviewApplicationId == id).FirstOrDefault();
                              return detailsinterview;
                    }

                    public InterviewApplicationFormModel fetchdata(int fetchid)
                    {
                              var a=dbcontext.interviewApplicationFormModelss.Where(s=>s.interviewApplicationId== fetchid).FirstOrDefault();
                              return a;
                    }

                    public byte[] GenerateinterviewapplicaitonyExcelFile(List<InterviewApplicationFormModel> interview)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("interviewApplicationFormModelss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "interviewApplicationId";
                                        worksheet.Cells[1, 2].Value = "FirstName";
                                        worksheet.Cells[1, 3].Value = "MiddleName";
                                        worksheet.Cells[1, 4].Value = "LastName";
                                        worksheet.Cells[1, 5].Value = "EmailAddress";
                                        worksheet.Cells[1, 6].Value = "Address";
                                        worksheet.Cells[1, 7].Value = "DateOfBirth";
                                        worksheet.Cells[1, 8].Value = "Gender";
                                        worksheet.Cells[1, 9].Value = "MobileNumber";
                                        worksheet.Cells[1, 10].Value = "InterviewerName";
                                        worksheet.Cells[1, 11].Value = "InterviewSchedue";
                                        worksheet.Cells[1, 12].Value = "PositionApplied_DesignationName";
                                        worksheet.Cells[1, 13].Value = "Department";
                                        worksheet.Cells[1, 14].Value = "TotalExperience";
                                        worksheet.Cells[1, 15].Value = "RelevantExperience";
                                        worksheet.Cells[1, 16].Value = "Skill";
                                        worksheet.Cells[1, 17].Value = "Matricthpercentage";
                                        worksheet.Cells[1, 18].Value = "Interpercentag";
                                        worksheet.Cells[1, 19].Value = "GraduationPercentage";
                                        worksheet.Cells[1, 20].Value = "POSTGRADUATEPercentage";
                                        worksheet.Cells[1, 21].Value = "HIGHEREDUCATION";
                                        worksheet.Cells[1, 22].Value = "CurrentCTC";
                                        worksheet.Cells[1, 23].Value = "ExpectedCTC";
                                        worksheet.Cells[1, 24].Value = "Monthly_CTC";
                                        worksheet.Cells[1, 25].Value = "Monthly_Ectc";
                                        worksheet.Cells[1, 26].Value = "HrQUestion";
                                        worksheet.Cells[1, 27].Value = "HrquestonFeedback";
                                        worksheet.Cells[1, 28].Value = "HrQuestionAccept_Reject";
                                        //worksheet.Cells[1, 29].Value = "HrQuestionReject";
                                        worksheet.Cells[1, 30].Value = "Reject_AcceptReasonDate";
                                        worksheet.Cells[1, 31].Value = "Reasonchangethecompany";
                                        worksheet.Cells[1, 32].Value = "EPFO_UANNUMBER";
                                        worksheet.Cells[1, 33].Value = "ESIC_IPNumber";
                                        worksheet.Cells[1, 34].Value = "AadharNumber";
                                        worksheet.Cells[1, 35].Value = "PancardNumber";

                                        // Add data
                                        for (int i = 0; i < interview.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = interview[i].interviewApplicationId;
                                                  worksheet.Cells[i + 2, 2].Value = interview[i].FirstName;
                                                  worksheet.Cells[i + 2, 3].Value = interview[i].MiddleName;
                                                  worksheet.Cells[i + 2, 4].Value = interview[i].LastName;
                                                  worksheet.Cells[i + 2, 5].Value = interview[i].EmailAddress;
                                                  worksheet.Cells[i + 2, 6].Value = interview[i].Address;
                                                  worksheet.Cells[i + 2, 7].Value = interview[i].DateOfBirth;
                                                  worksheet.Cells[i + 2, 8].Value = interview[i].Gender;
                                                  worksheet.Cells[i + 2, 9].Value = interview[i].MobileNumber;
                                                  worksheet.Cells[i + 2, 10].Value = interview[i].InterviewerName;
                                                  worksheet.Cells[i + 2, 11].Value = interview[i].InterviewSchedue;
                                                  worksheet.Cells[i + 2, 12].Value = interview[i].PositionApplied_DesignationName;
                                                  worksheet.Cells[i + 2, 13].Value = interview[i].Department;
                                                  worksheet.Cells[i + 2, 14].Value = interview[i].TotalExperience;
                                                  worksheet.Cells[i + 2, 15].Value = interview[i].RelevantExperience;
                                                  worksheet.Cells[i + 2, 16].Value = interview[i].Skill;
                                                  worksheet.Cells[i + 2, 17].Value = interview[i].Matricthpercentage;
                                                  worksheet.Cells[i + 2, 18].Value = interview[i].Interpercentag;
                                                  worksheet.Cells[i + 2, 19].Value = interview[i].GraduationPercentage;
                                                  worksheet.Cells[i + 2, 20].Value = interview[i].POSTGRADUATEPercentage;
                                                  worksheet.Cells[i + 2, 21].Value = interview[i].HIGHEREDUCATION;
                                                  worksheet.Cells[i + 2, 22].Value = interview[i].CurrentCTC;
                                                  worksheet.Cells[i + 2, 23].Value = interview[i].ExpectedCTC;
                                                  worksheet.Cells[i + 2, 24].Value = interview[i].Monthly_CTC;
                                                  worksheet.Cells[i + 2,25].Value = interview[i].Monthly_Ectc;
                                                  worksheet.Cells[i + 2,26].Value = interview[i].HrQUestion;
                                                  worksheet.Cells[i + 2, 28].Value = interview[i].HrQuestionAccept_Reject;

                                                  worksheet.Cells[i + 2, 27].Value = interview[i].HrquestonFeedback;
                                                  //worksheet.Cells[i + 2, 29].Value = interview[i].HrQuestionReject;
                                                  worksheet.Cells[i + 2, 30].Value = interview[i].Reject_AcceptReasonDate;
                                                  worksheet.Cells[i + 2, 31].Value = interview[i].Reasonchangethecompany;
                                                  worksheet.Cells[i + 2, 32].Value = interview[i].EPFO_UANNUMBER;
                                                  worksheet.Cells[i + 2, 33].Value = interview[i].ESIC_IPNumber;
                                                  worksheet.Cells[i + 2, 34].Value = interview[i].AadharNumber;
                                                 worksheet.Cells[i + 2, 35].Value = interview[i].PancardNumber;
                                                 
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<InterviewApplicationFormModel> GetAllInterview()
                    {
                              var lsitinterview = dbcontext.interviewApplicationFormModelss.ToList();
                              return lsitinterview;
                    }

                    //public combinedtwomodeldto Interviewaddfetch(int id)
                    //{
                    //          var interviewApplication = dbcontext.interviewApplicationFormModels
                    //              .FirstOrDefault(a => a.interviewApplicationId == id);

                    //          // Fetch data for OpenPositonAppliedModelcs
                    //          var openPosition = dbcontext.OpenPositonAppliedModelcs
                    //              .FirstOrDefault(o => o.OpenpositionId == id); // or use a different criteria

                    //          // Combine both models into DTO
                    //          var combinedData = new combinedtwomodeldto
                    //          {
                    //                    InterviewApplication = interviewApplication,
                    //                    OpenPosition = openPosition
                    //          };

                    //          return combinedData;
                    //}
          

                   
          public InterviewApplicationFormModel SearchById(int id)
                    {
                            var searchinterviw= dbcontext.interviewApplicationFormModelss.Where(s=>s.interviewApplicationId==id).FirstOrDefault();
                              return  searchinterviw;
                    }

                    public void Updateinterviewapplicaitony(InterviewApplicationFormModel models)
                    {
                            dbcontext.interviewApplicationFormModelss.Update(models);
                              dbcontext.SaveChanges();
                    }

                  
          }
}
