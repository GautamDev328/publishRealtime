﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class EmployeeQueryRepository : IEmployeeQueryRepository
    {
        EmployeeDbContext _employeeDbContext;
        public EmployeeQueryRepository(EmployeeDbContext employeeDbContext)
        {

            this._employeeDbContext = employeeDbContext;
        }
        public void CreateEmployeeQuery(EmployeeQuery employeeQuery)
        {
            _employeeDbContext.employeeQuerys.Add(employeeQuery);
            _employeeDbContext.SaveChanges();
        }

        public void DeleteEmployeeQuery(int id)
        {
            var delete = _employeeDbContext.employeeQuerys.Where(s => s.Emp_Id == id).FirstOrDefault();
                         _employeeDbContext.employeeQuerys.Remove(delete);
                        _employeeDbContext.SaveChanges();
        }

        public EmployeeQuery DetailsEmployeeQuery(int id)
        {
            var emp=_employeeDbContext.employeeQuerys.Where(s=>s.Emp_Id==id).FirstOrDefault();
            return emp;

        }

                    public byte[] GenerateEmployeeQueryExcelFile(List<EmployeeQuery> employeeQueriess)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("employeeQuerys");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Emp_Id";
                                        worksheet.Cells[1, 2].Value = "EmployeeName";
                                        worksheet.Cells[1, 3].Value = "EmployeeQueryMessage";
                                        worksheet.Cells[1, 4].Value = "GetDateOnly";

                                        // Add data
                                        for (int i = 0; i < employeeQueriess.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = employeeQueriess[i].Emp_Id;
                                                  worksheet.Cells[i + 2, 2].Value = employeeQueriess[i].EmployeeName;
                                                  worksheet.Cells[i + 2, 3].Value = employeeQueriess[i].EmployeeQueryMessage;
                                                  worksheet.Cells[i + 2, 4].Value = employeeQueriess[i].GetDateOnly;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<EmployeeQuery> GetEmployeeQueryAll()
        {
            var list = _employeeDbContext.employeeQuerys.ToList();
            return list;
        }

        public void UpdateEmployeeQuery(EmployeeQuery employeeQuery)
        {
           _employeeDbContext.employeeQuerys.Update(employeeQuery);
            _employeeDbContext.SaveChanges();
        }
    }
}
