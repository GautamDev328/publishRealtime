﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class StateRepository : IStateRepository
    {
        EmployeeDbContext _employeedb;
        public StateRepository(EmployeeDbContext employeeDb)
        {
            this._employeedb = employeeDb;

        }
        public void CreateState(StateModel state)
        {
            _employeedb.statess.Add(state);
            _employeedb.SaveChanges();

        }

        public void DeleteState(int id)
        {
           var a= _employeedb.statess.Where(s => s.Id == id).FirstOrDefault();
            _employeedb.statess.Remove(a);

            _employeedb.SaveChanges();
        }

        public StateModel DetailsState(int id)
        {
            var state = _employeedb.statess.Where(s => s.Id == id).FirstOrDefault();
            return state;
        }

                    public byte[] GenerateCitiesExcelFile(List<StateModel> stateModelss)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("statess");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "Id";
                                        worksheet.Cells[1, 2].Value = "StateName";
                                       // worksheet.Cells[1, 3].Value = "State Name";

                                        // Add data
                                        for (int i = 0; i < stateModelss.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = stateModelss[i].Id;
                                                  worksheet.Cells[i + 2, 2].Value = stateModelss[i].StateName;
                                                 // worksheet.Cells[i + 2, 3].Value = stateModelss[i].;
                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<StateModel> states()
        {
            var list = _employeedb.statess.ToList();
            return list;
        }

        public void UpdateState(StateModel state)
        {
          _employeedb.Update(state);
            _employeedb.SaveChanges();
        }
    }
}
