﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class ClientQureyMessageRepository : IClientQueryMessageRepository
    {
        EmployeeDbContext employeeDbContext;
        public ClientQureyMessageRepository(EmployeeDbContext _employeeDbContext)
        {
            this.employeeDbContext = _employeeDbContext;

        }

        public List<ClientQuery> AllClientQueryMessage()
        {
            var list = employeeDbContext.clientQueryss.ToList();
            return list;
        }

        public void CreateCientQueryMessage(ClientQuery message)
        {
            employeeDbContext.clientQueryss.Add(message);
            employeeDbContext.SaveChanges();
        }

        public void DeleteCientQueryMessage(int id)
        {
            var delete = employeeDbContext.clientQueryss.Where(s => s.c_Id == id).FirstOrDefault();
            employeeDbContext.clientQueryss.Remove(delete);
            employeeDbContext.SaveChanges();
        }

        public ClientQuery DetailsClientQueryMessage(int id)
        {
            var detail = employeeDbContext.clientQueryss.Where(s => s.c_Id == id).FirstOrDefault();
            return detail;
        }

                    public byte[] GenerateClientQueryExcelFile(List<ClientQuery> clientQueriess)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("clientQueryss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "c_Id";
                                        worksheet.Cells[1, 2].Value = "clientFirtName";
                                        worksheet.Cells[1, 3].Value = "clientLastName";
                                        worksheet.Cells[1, 4].Value = "State";
                                        worksheet.Cells[1, 5].Value = "City";
                                        worksheet.Cells[1, 6].Value = "ContactNumber";
                                        worksheet.Cells[1, 7].Value = "clientDescription";
                                        worksheet.Cells[1, 8].Value = "Country";

                                        // Add data
                                        for (int i = 0; i < clientQueriess.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = clientQueriess[i].c_Id;
                                                  worksheet.Cells[i + 2, 2].Value = clientQueriess[i].clientFirtName;
                                                  worksheet.Cells[i + 2, 3].Value = clientQueriess[i].clientLastName;
                                                  worksheet.Cells[i + 2, 4].Value = clientQueriess[i].State;
                                                  worksheet.Cells[i + 2, 5].Value = clientQueriess[i].City;
                                                  worksheet.Cells[i + 2, 6].Value = clientQueriess[i].ContactNumber;
                                                  worksheet.Cells[i + 2, 7].Value = clientQueriess[i].clientDescription;
                                                  worksheet.Cells[i + 2, 8].Value = clientQueriess[i].Country;


                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public void UpdateCientQueryMessage(ClientQuery clientQueryMessage)
        {
            employeeDbContext.clientQueryss.Update(clientQueryMessage);
            employeeDbContext.SaveChanges();
        }
    }
}
