﻿using CRUDAPPLICATION.BLL.IRepository;
using CRUDAPPLICATION.DATABASE;
using CRUDAPPLICATION.Model;
using CRUDAPPLICATION.ModelDTO;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;

namespace CRUDAPPLICATION.BLL.Repository
{
    public class OpenPositonAppliedRepository:IOpenPositonAppliedRepository
    {
                    public EmployeeDbContext _empdb;
        public OpenPositonAppliedRepository(EmployeeDbContext empdb) 
        {
                    this._empdb = empdb;
        }

                    public void CreateOpenPositon(OpenPositonAppliedModelcs model)
                    {

                              _empdb.OpenPositonAppliedModelcss.Add(model);
                              _empdb.SaveChanges();
                    }

                    public void DeleteOpenPositon(int id)
                    { 
                              var deleteOpenInterview= _empdb.OpenPositonAppliedModelcss.Where(s => s.OpenpositionId == id).FirstOrDefault();
                              _empdb.OpenPositonAppliedModelcss.Remove(deleteOpenInterview);
                              _empdb.SaveChanges();
                    }

                    public OpenPositonAppliedModelcs DetailOpenPositon(int id)
                    {
                              var detailsOpeningPosition = _empdb.OpenPositonAppliedModelcss.Where(s => s.OpenpositionId == id).FirstOrDefault();
                              return detailsOpeningPosition;
                    }

                  

                    public byte[] GenerateOpenPositonExcelFile(List<OpenPositonAppliedModelcs> OpenPositons)
                    {
                              using (var package = new ExcelPackage())
                              {
                                        var worksheet = package.Workbook.Worksheets.Add("OpenPositonAppliedModelcss");

                                        // Add headers
                                        worksheet.Cells[1, 1].Value = "OpenpositionId";
                                        worksheet.Cells[1, 2].Value = "FirstName";
                                        worksheet.Cells[1, 3].Value = "MiddleName";
                                        worksheet.Cells[1, 4].Value = "LastName";
                                        worksheet.Cells[1, 5].Value = "EmailAddress";
                                        worksheet.Cells[1, 6].Value = "Address";
                                        worksheet.Cells[1, 7].Value = "DateOfBirth";
                                        worksheet.Cells[1, 8].Value = "Gender";
                                        worksheet.Cells[1, 9].Value = "MobileNumber";
                                        worksheet.Cells[1, 10].Value = "TotalExperience";
                                        worksheet.Cells[1, 11].Value = "RelevantExperience";
                                        worksheet.Cells[1, 12].Value = "HIGHEREDUCATION";
                                        worksheet.Cells[1, 13].Value = "HIgherPercentage";
                                        worksheet.Cells[1, 14].Value = "CurrentCTC";
                                        worksheet.Cells[1, 15].Value = "ExpectedCTC";
                                        worksheet.Cells[1, 16].Value = "Skill";
                                        worksheet.Cells[1, 17].Value = "Reasonchangethecompany";
                                        worksheet.Cells[1, 18].Value = "PANCARDNUMBER";
                                        worksheet.Cells[1, 19].Value = "image";
                                        worksheet.Cells[1, 120].Value = "Resume_CV";
                                        worksheet.Cells[1, 21].Value = "PositionFeedback";
                                      


                                        // Add data
                                        for (int i = 0; i < OpenPositons.Count; i++)
                                        {
                                                  worksheet.Cells[i + 2, 1].Value = OpenPositons[i].OpenpositionId;
                                                  worksheet.Cells[i + 2, 2].Value = OpenPositons[i].FirstName;
                                                  worksheet.Cells[i + 2, 3].Value = OpenPositons[i].MiddleName;
                                                  worksheet.Cells[i + 2, 4].Value = OpenPositons[i].LastName;
                                                  worksheet.Cells[i + 2, 5].Value = OpenPositons[i].EmailAddress;
                                                  worksheet.Cells[i + 2, 6].Value = OpenPositons[i].Address;
                                                  worksheet.Cells[i + 2, 7].Value = OpenPositons[i].DateOfBirth;
                                                  worksheet.Cells[i + 2, 8].Value = OpenPositons[i].Gender;
                                                  worksheet.Cells[i + 2, 9].Value = OpenPositons[i].MobileNumber;
                                                  worksheet.Cells[i + 2, 10].Value = OpenPositons[i].TotalExperience;
                                                  worksheet.Cells[i + 2, 11].Value = OpenPositons[i].RelevantExperience;
                                                  worksheet.Cells[i + 2, 12].Value = OpenPositons[i].HIGHEREDUCATION;
                                                  worksheet.Cells[i + 2, 13].Value = OpenPositons[i].HIgherPercentage;
                                                  worksheet.Cells[i + 2, 14].Value = OpenPositons[i].CurrentCTC;
                                                  worksheet.Cells[i + 2, 15].Value = OpenPositons[i].ExpectedCTC;
                                                  worksheet.Cells[i + 2, 16].Value = OpenPositons[i].Skill;
                                                  worksheet.Cells[i + 2, 17].Value = OpenPositons[i].Reasonchangethecompany;
                                                  worksheet.Cells[i + 2, 18].Value = OpenPositons[i].PANCARDNUMBER;
                                                  worksheet.Cells[i + 2, 19].Value = OpenPositons[i].image;
                                                  worksheet.Cells[i + 2, 20].Value = OpenPositons[i].Resume_CV;
                                                  worksheet.Cells[i + 2, 21].Value = OpenPositons[i].PositionFeedback;
                                                 

                                        }

                                        // Auto-fit columns
                                        worksheet.Cells.AutoFitColumns();

                                        return package.GetAsByteArray();
                              }
                    }

                    public List<OpenPositonAppliedModelcs> GetAllOpenPositon()
                    {
                              var lsitOpenPositoion = _empdb.OpenPositonAppliedModelcss.ToList();
                              return lsitOpenPositoion;
                    }

                    public OpenPositonAppliedModelcs SearchById(int id)
                    {
                              var searchOpening = _empdb.OpenPositonAppliedModelcss.Where(s => s.OpenpositionId == id).FirstOrDefault();
                              return searchOpening;
                    }

                    public void UpdateOpenPositon(OpenPositonAppliedModelcs models)
                    {
                              _empdb.OpenPositonAppliedModelcss.Update(models);
                              _empdb.SaveChanges();
                    }

                    //void IOpenPositonAppliedRepository.fetchall(int id)
                    //{
                    //          throw new NotImplementedException();
                    //}
          }
}
