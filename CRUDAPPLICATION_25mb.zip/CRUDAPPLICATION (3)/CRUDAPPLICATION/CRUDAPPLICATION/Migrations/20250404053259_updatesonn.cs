﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class updatesonn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BillingCurrentDate",
                table: "customerdetailsModelsss");

            migrationBuilder.DropColumn(
                name: "BillingVoucherNumber",
                table: "customerdetailsModelsss");

            migrationBuilder.AddColumn<DateOnly>(
                name: "BillingCurrentDate",
                table: "billingModelsss",
                type: "date",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BillingVoucherNumber",
                table: "billingModelsss",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BillingCurrentDate",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "BillingVoucherNumber",
                table: "billingModelsss");

            migrationBuilder.AddColumn<DateOnly>(
                name: "BillingCurrentDate",
                table: "customerdetailsModelsss",
                type: "date",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BillingVoucherNumber",
                table: "customerdetailsModelsss",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
