﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class newmodel2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_billingModelsss_customerdetailsModelsss_CustomerId",
                table: "billingModelsss");

            migrationBuilder.DropIndex(
                name: "IX_billingModelsss_CustomerId",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "DistrictName",
                table: "statess");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DistrictName",
                table: "statess",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_billingModelsss_CustomerId",
                table: "billingModelsss",
                column: "CustomerId");

            migrationBuilder.AddForeignKey(
                name: "FK_billingModelsss_customerdetailsModelsss_CustomerId",
                table: "billingModelsss",
                column: "CustomerId",
                principalTable: "customerdetailsModelsss",
                principalColumn: "CustId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
