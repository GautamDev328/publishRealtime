﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class neupdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MobileNumber1",
                table: "relationModelss");

            migrationBuilder.DropColumn(
                name: "ReferredRelation1",
                table: "relationModelss");

            migrationBuilder.DropColumn(
                name: "RefrenceRelation_Name1",
                table: "relationModelss");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "MobileNumber1",
                table: "relationModelss",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ReferredRelation1",
                table: "relationModelss",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "RefrenceRelation_Name1",
                table: "relationModelss",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
