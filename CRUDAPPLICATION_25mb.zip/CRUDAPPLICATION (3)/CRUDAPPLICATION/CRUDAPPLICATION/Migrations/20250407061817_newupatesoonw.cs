﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class newupatesoonw : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "custCurrentDate",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "BillingCurrentDate",
                table: "billingModelsss");

            migrationBuilder.AlterColumn<string>(
                name: "customerName",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "MobilNumber",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BillingVoucherNumber",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BillingCurrentDate",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(DateOnly),
                oldType: "date");

            migrationBuilder.AlterColumn<string>(
                name: "Address",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "Amount",
                table: "CommonBillingVoucherDTO",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<float>(
                name: "CGST",
                table: "CommonBillingVoucherDTO",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "IGST",
                table: "CommonBillingVoucherDTO",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductDescription",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "Qty",
                table: "CommonBillingVoucherDTO",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<decimal>(
                name: "Rate",
                table: "CommonBillingVoucherDTO",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<float>(
                name: "SGST",
                table: "CommonBillingVoucherDTO",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TotalInWords",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "OtherAmount",
                table: "billingModelsss",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateOnly>(
                name: "BillingDate",
                table: "billingModelsss",
                type: "date",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Amount",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "CGST",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "IGST",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "ProductDescription",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "Qty",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "Rate",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "SGST",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.DropColumn(
                name: "TotalInWords",
                table: "CommonBillingVoucherDTO");

            migrationBuilder.AlterColumn<string>(
                name: "customerName",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "MobilNumber",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "BillingVoucherNumber",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<DateOnly>(
                name: "BillingCurrentDate",
                table: "CommonBillingVoucherDTO",
                type: "date",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Address",
                table: "CommonBillingVoucherDTO",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<DateOnly>(
                name: "custCurrentDate",
                table: "CommonBillingVoucherDTO",
                type: "date",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "OtherAmount",
                table: "billingModelsss",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<DateTime>(
                name: "BillingDate",
                table: "billingModelsss",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateOnly),
                oldType: "date",
                oldNullable: true);

            migrationBuilder.AddColumn<DateOnly>(
                name: "BillingCurrentDate",
                table: "billingModelsss",
                type: "date",
                nullable: true);
        }
    }
}
