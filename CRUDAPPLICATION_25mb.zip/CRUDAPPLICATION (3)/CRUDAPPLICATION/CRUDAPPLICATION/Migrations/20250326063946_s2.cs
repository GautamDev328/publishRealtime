﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class s2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "addRelationShipModelss",
                columns: table => new
                {
                    Relation_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AddRelationShip = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_addRelationShipModelss", x => x.Relation_id);
                });

            migrationBuilder.CreateTable(
                name: "auot_CustomerhelpModelsss",
                columns: table => new
                {
                    CustomerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_auot_CustomerhelpModelsss", x => x.CustomerId);
                });

            migrationBuilder.CreateTable(
                name: "bankModelss",
                columns: table => new
                {
                    BankId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BankCustomerName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BankName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AccountNumber = table.Column<string>(type: "nvarchar(18)", maxLength: 18, nullable: false),
                    ConfirmAccountNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IFSCCODE = table.Column<string>(type: "nvarchar(11)", maxLength: 11, nullable: false),
                    StatusCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MICRCODE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BranchName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DistrictName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BankDescription = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_bankModelss", x => x.BankId);
                });

            migrationBuilder.CreateTable(
                name: "cityss",
                columns: table => new
                {
                    City_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    City_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StateName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cityss", x => x.City_Id);
                });

            migrationBuilder.CreateTable(
                name: "clientModelss",
                columns: table => new
                {
                    Client_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClientName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Photo = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clientModelss", x => x.Client_Id);
                });

            migrationBuilder.CreateTable(
                name: "clientQueryss",
                columns: table => new
                {
                    c_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    clientFirtName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    clientLastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContactNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    clientDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clientQueryss", x => x.c_Id);
                });

            migrationBuilder.CreateTable(
                name: "CommonBillingVoucherDTO",
                columns: table => new
                {
                    voucherid = table.Column<int>(type: "int", nullable: false),
                    customerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    custCurrentDate = table.Column<DateOnly>(type: "date", nullable: true),
                    BillingCurrentDate = table.Column<DateOnly>(type: "date", nullable: false),
                    BillingVoucherNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MobilNumber = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "countriess",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_countriess", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "customerPricess",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerExtraPrice = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CustomerExtraUser = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customerPricess", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "departments",
                columns: table => new
                {
                    Dep_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Dep_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_departments", x => x.Dep_Id);
                });

            migrationBuilder.CreateTable(
                name: "designationss",
                columns: table => new
                {
                    DesigId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DesigType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DesigName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_designationss", x => x.DesigId);
                });

            migrationBuilder.CreateTable(
                name: "districtNameModelss",
                columns: table => new
                {
                    DistrictId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DistrictName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StateName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_districtNameModelss", x => x.DistrictId);
                });

            migrationBuilder.CreateTable(
                name: "employeeProfiless",
                columns: table => new
                {
                    EmpId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Designation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Mobile = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StateName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DepartmentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DesignationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Emailid = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Age = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_employeeProfiless", x => x.EmpId);
                });

            migrationBuilder.CreateTable(
                name: "employeeQuerys",
                columns: table => new
                {
                    Emp_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmployeeQueryMessage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GetDateOnly = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_employeeQuerys", x => x.Emp_Id);
                });

            migrationBuilder.CreateTable(
                name: "genders",
                columns: table => new
                {
                    Gen_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Gen_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_genders", x => x.Gen_Id);
                });

            migrationBuilder.CreateTable(
                name: "higherQualificationModelss",
                columns: table => new
                {
                    highId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HigherQualificaiton = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_higherQualificationModelss", x => x.highId);
                });

            migrationBuilder.CreateTable(
                name: "hRProfiless",
                columns: table => new
                {
                    HR_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HR_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_ContactNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_Designation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_Department = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_LoginTIME = table.Column<DateOnly>(type: "date", nullable: false),
                    HR_LoginType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_Feedback = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HR_MailMessage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OtherRequiredData = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_hRProfiless", x => x.HR_Id);
                });

            migrationBuilder.CreateTable(
                name: "HRQUESTIONMODELss",
                columns: table => new
                {
                    HRQUESITONID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HRKEYNUMBER = table.Column<int>(type: "int", nullable: false),
                    HrQuestionKey = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HRQUESTIONMODELss", x => x.HRQUESITONID);
                });

            migrationBuilder.CreateTable(
                name: "interviewApplicationFormModelss",
                columns: table => new
                {
                    interviewApplicationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBirth = table.Column<DateOnly>(type: "date", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewerName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewSchedue = table.Column<DateOnly>(type: "date", nullable: false),
                    PositionApplied_DesignationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Department = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TotalExperience = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RelevantExperience = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Skill = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Matricthpercentage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Interpercentag = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GraduationPercentage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    POSTGRADUATEPercentage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HIGHEREDUCATION = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HighPercentage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CurrentCTC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExpectedCTC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Monthly_CTC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Monthly_Ectc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NegotiationCTC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HrQUestion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HrquestonFeedback = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HrQuestionAccept_Reject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Reject_AcceptReasonDate = table.Column<DateOnly>(type: "date", nullable: false),
                    Reasonchangethecompany = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EPFO_UANNUMBER = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ESIC_IPNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AadharNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PancardNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Resume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    photo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PositionFeedback = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_interviewApplicationFormModelss", x => x.interviewApplicationId);
                });

            migrationBuilder.CreateTable(
                name: "interviewer_applieddetailModelss",
                columns: table => new
                {
                    interviewID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HIGHEREDUCATION = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewerName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Skill = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewerAccept_Reject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewerStatus = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    lastestReschdueDate_time = table.Column<DateOnly>(type: "date", nullable: false),
                    Resume_CV = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    fEEDBACK = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_interviewer_applieddetailModelss", x => x.interviewID);
                });

            migrationBuilder.CreateTable(
                name: "itemss",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Category = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_itemss", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OpenPositonAppliedModelcss",
                columns: table => new
                {
                    OpenpositionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBirth = table.Column<DateOnly>(type: "date", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TotalExperience = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RelevantExperience = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HIGHEREDUCATION = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HIgherPercentage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CurrentCTC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExpectedCTC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Skill = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Reasonchangethecompany = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PANCARDNUMBER = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    image = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Resume_CV = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PositionFeedback = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OpenPositonAppliedModelcss", x => x.OpenpositionId);
                });

            migrationBuilder.CreateTable(
                name: "paymentCustomeExtraUserModelss",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Device_Serials = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OtherCharges = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_paymentCustomeExtraUserModelss", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "registerationFormsss",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FullName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ConformPassword = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Username = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Contact = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Photo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isActive = table.Column<bool>(type: "bit", nullable: false),
                    remainder = table.Column<bool>(type: "bit", nullable: false),
                    CreateRegisterform = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FirstLoginTime = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "GETDATE()"),
                    LastLoginTime = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "GETDATE()"),
                    FirstLogOutTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastLogOutTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_registerationFormsss", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "relationModelss",
                columns: table => new
                {
                    Relat_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RefrenceRelation_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReferenceRelation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RefrenceRelation_Name1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReferredRelation1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileNumber1 = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_relationModelss", x => x.Relat_Id);
                });

            migrationBuilder.CreateTable(
                name: "rescheduleDatess",
                columns: table => new
                {
                    RescheduleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewerName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InterviewSchedue = table.Column<DateOnly>(type: "date", nullable: false),
                    PositionApplied_DesignationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TotalExperience = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HIGHEREDUCATION = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReasonRescheduechangedatetime = table.Column<DateOnly>(type: "date", nullable: false),
                    interviewReasoncancelled = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FEEBACK = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_rescheduleDatess", x => x.RescheduleId);
                });

            migrationBuilder.CreateTable(
                name: "RoleWiseOnlyEmployeess",
                columns: table => new
                {
                    RoleWiseonlyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleWiseonlyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleWiseOnlyEmployeess", x => x.RoleWiseonlyId);
                });

            migrationBuilder.CreateTable(
                name: "roleWises",
                columns: table => new
                {
                    Role_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Role_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_roleWises", x => x.Role_ID);
                });

            migrationBuilder.CreateTable(
                name: "statess",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StateName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_statess", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "useRoleWiseModelss",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_useRoleWiseModelss", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "userTrailss",
                columns: table => new
                {
                    UsertrailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CompanyId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CompanyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CompanyAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CorporateId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Confrompassword = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PartnerId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DealerName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    photodrop = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userTrailss", x => x.UsertrailId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "addRelationShipModelss");

            migrationBuilder.DropTable(
                name: "auot_CustomerhelpModelsss");

            migrationBuilder.DropTable(
                name: "bankModelss");

            migrationBuilder.DropTable(
                name: "cityss");

            migrationBuilder.DropTable(
                name: "clientModelss");

            migrationBuilder.DropTable(
                name: "clientQueryss");

            migrationBuilder.DropTable(
                name: "CommonBillingVoucherDTO");

            migrationBuilder.DropTable(
                name: "countriess");

            migrationBuilder.DropTable(
                name: "customerPricess");

            migrationBuilder.DropTable(
                name: "departments");

            migrationBuilder.DropTable(
                name: "designationss");

            migrationBuilder.DropTable(
                name: "districtNameModelss");

            migrationBuilder.DropTable(
                name: "employeeProfiless");

            migrationBuilder.DropTable(
                name: "employeeQuerys");

            migrationBuilder.DropTable(
                name: "genders");

            migrationBuilder.DropTable(
                name: "higherQualificationModelss");

            migrationBuilder.DropTable(
                name: "hRProfiless");

            migrationBuilder.DropTable(
                name: "HRQUESTIONMODELss");

            migrationBuilder.DropTable(
                name: "interviewApplicationFormModelss");

            migrationBuilder.DropTable(
                name: "interviewer_applieddetailModelss");

            migrationBuilder.DropTable(
                name: "itemss");

            migrationBuilder.DropTable(
                name: "OpenPositonAppliedModelcss");

            migrationBuilder.DropTable(
                name: "paymentCustomeExtraUserModelss");

            migrationBuilder.DropTable(
                name: "registerationFormsss");

            migrationBuilder.DropTable(
                name: "relationModelss");

            migrationBuilder.DropTable(
                name: "rescheduleDatess");

            migrationBuilder.DropTable(
                name: "RoleWiseOnlyEmployeess");

            migrationBuilder.DropTable(
                name: "roleWises");

            migrationBuilder.DropTable(
                name: "statess");

            migrationBuilder.DropTable(
                name: "useRoleWiseModelss");

            migrationBuilder.DropTable(
                name: "userTrailss");
        }
    }
}
