﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class updatesoonmoodelstate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "pINCODE",
                table: "statess");

            migrationBuilder.AddColumn<string>(
                name: "PinCode",
                table: "employeeProfiless",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PinCode",
                table: "employeeProfiless");

            migrationBuilder.AddColumn<string>(
                name: "pINCODE",
                table: "statess",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
