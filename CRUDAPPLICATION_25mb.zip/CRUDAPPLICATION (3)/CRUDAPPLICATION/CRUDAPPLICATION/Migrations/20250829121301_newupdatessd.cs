﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class newupdatessd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_customerTypess",
                table: "customerTypess");

            migrationBuilder.RenameTable(
                name: "customerTypess",
                newName: "customerTypemodless");

            migrationBuilder.AddPrimaryKey(
                name: "PK_customerTypemodless",
                table: "customerTypemodless",
                column: "custtypeid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_customerTypemodless",
                table: "customerTypemodless");

            migrationBuilder.RenameTable(
                name: "customerTypemodless",
                newName: "customerTypess");

            migrationBuilder.AddPrimaryKey(
                name: "PK_customerTypess",
                table: "customerTypess",
                column: "custtypeid");
        }
    }
}
