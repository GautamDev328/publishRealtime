﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class FixPinCode : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ZipCode",
                table: "employeeProfiless",
                newName: "PinCode");

            migrationBuilder.AddColumn<string>(
                name: "MiddleName",
                table: "employeeProfiless",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MiddleName",
                table: "employeeProfiless");

            migrationBuilder.RenameColumn(
                name: "PinCode",
                table: "employeeProfiless",
                newName: "ZipCode");
        }
    }
}
