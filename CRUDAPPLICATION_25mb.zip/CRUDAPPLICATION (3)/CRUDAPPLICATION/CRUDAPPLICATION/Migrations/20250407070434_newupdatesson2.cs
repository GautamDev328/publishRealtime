﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUDAPPLICATION.Migrations
{
    /// <inheritdoc />
    public partial class newupdatesson2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Amount",
                table: "billingModelsss",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "CGST",
                table: "billingModelsss",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "IGST",
                table: "billingModelsss",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductDescription",
                table: "billingModelsss",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "billingModelsss",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Rate",
                table: "billingModelsss",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "SGST",
                table: "billingModelsss",
                type: "real",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Amount",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "CGST",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "IGST",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "ProductDescription",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "Rate",
                table: "billingModelsss");

            migrationBuilder.DropColumn(
                name: "SGST",
                table: "billingModelsss");
        }
    }
}
