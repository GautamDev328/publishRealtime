﻿//1st Model
using System;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class PaymentCustomerExtraUserModel
    {
        [Key]
        public int id { get; set;}
        [Required(ErrorMessage = "Please Fill the DeviceSerials")]

        public string? Device_Serials { get; set; }
        //[Required(ErrorMessage = "Please Fill the GstTax")]

        // public string? GstTax { get; set; } = null;
        //[Required(ErrorMessage = "Please Fill the OtherCharges")]

        public string OtherCharges { get; set; } 

    }
}

