﻿
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class RescheduleDateInterviewOPENINGMODEL
          {
                    [Key]
                    public int RescheduleId { get; set; }

                    [Required(ErrorMessage = "FirstName Will be Required")]
                    public string? FirstName { get; set; } = null;
                    //  [Required(ErrorMessage = "MiddleName Will be Required")]

                    public string? MiddleName { get; set; } = null;
                    [Required(ErrorMessage = "LastName Will be Required")]

                    public string? LastName { get; set; } = null;
                    [Required(ErrorMessage = "Address Will be Required")]

                    public string? Address { get; set; } = null;

                    [Required(ErrorMessage = "MobileNumber is required.")]
                    [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid MobileNumber")]
                    public string? MobileNumber { get; set; } = null;

                    [Required(ErrorMessage = "InterviewName Will be Required")]


                    public string? InterviewerName { get; set; } = null;
                    [Required(ErrorMessage = "InterviewSchedue/InterviewDate Will be Required")]


                    public DateOnly? InterviewSchedue { get; set; } = null; //  // Automatic show the  datetime  show the avaible interview
                    [Required(ErrorMessage = "PositionApplied/DesignationName Will be Required")]

                    public string? PositionApplied_DesignationName { get; set; } = null; // Desingation Applied  --PositionApplied_DesignationName

                    [Required(ErrorMessage = "TotalExperience Will be Required")]

                    public string? TotalExperience { get; set; } = null;
                    [Required(ErrorMessage = "HIGHEREDUCATION Will be Required")]

                    public string? HIGHEREDUCATION { get; set; } = null;
                    [Required(ErrorMessage = "ReasonRescheduechangedatetime Will be Required")]


                    public DateOnly? ReasonRescheduechangedatetime { get; set; } = null;
                    [Required(ErrorMessage = "interviewReasoncancelled Will be Required")]

                    public string? interviewReasoncancelled { get; set; } = null;
                    [Required(ErrorMessage = "FEEDBACK Will be Required")]

                    public string? FEEBACK { get; set; } = null;
          }
}
