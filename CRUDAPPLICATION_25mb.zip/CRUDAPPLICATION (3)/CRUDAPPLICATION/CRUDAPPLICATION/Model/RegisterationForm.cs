﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRUDAPPLICATION.Model
{
    public class RegisterationForm
    {
        [Key]
        public int id { get; set; }
        [Required(ErrorMessage = "FullName Will be required")]
        [StringLength(100)]

        public string? FullName { get; set; } = null;
        [Required]
        [EmailAddress]
        public string? Email { get; set; } = null;
        [Required]
        [StringLength(100, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public string? Password { get; set; } = null;
        [Required]
        [StringLength(100, MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string? ConformPassword { get; set; } = null;
        [Required(ErrorMessage = "UserName Will be required")]
        [StringLength(100)]
        public string? Username { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the Gender")]

        public string? Gender { get; set; } = null;
        [Required(ErrorMessage = "Contact No is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]

        public string? Contact { get; set; } = null;
                    [Required(ErrorMessage = "Please select the Photo")]

                    public string? Photo { get; set; } = null;

                    //  [Required(ErrorMessage = "Please select the Photo")]
                    public bool isActive { get; set; }

                    public bool remainder { get; set; }
                    // [Required(ErrorMessage = "Please select the Photo")]
                    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
                    public DateTime? CreateRegisterform{ get; set; } = DateTime.Now;
                    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

                    public DateTime? FirstLoginTime { get; set; } = DateTime.Now;
                    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

                    public DateTime? LastLoginTime { get; set; } = DateTime.Now;
                    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

                    public DateTime? FirstLogOutTime { get; set; } = DateTime.Now;
                    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

                    public DateTime? LastLogOutTime { get; set; } = DateTime.Now;

                    //Logintype page 
                    public string? LoginType { get; set; } = null!;



                    // Captcha fields — temporary, not stored in DB
                    [NotMapped]
                    public string? CaptchaImageBase64 { get; set; } = null;

                    [NotMapped]
                    public string? CaptchaCode { get; set; } = null;


          }

}
