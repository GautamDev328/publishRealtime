﻿
using System.ComponentModel.DataAnnotations;


namespace CRUDAPPLICATION.Model
{
          public class OpenPositonAppliedModelcs
          {
                    [Key]
                    public int OpenpositionId { get; set; }

                    [Required(ErrorMessage = "FirstName Will be Required")]
                    public string? FirstName { get; set; } = null;
                    //  [Required(ErrorMessage = "MiddleName Will be Required")]

                    public string? MiddleName { get; set; } = null;
                    [Required(ErrorMessage = "LastName Will be Required")]

                    public string? LastName { get; set; } = null;
                    [Required(ErrorMessage = "EmailAddress Will be Required")]
                    [EmailAddress]
                    public string? EmailAddress { get; set; } = null;
                    [Required(ErrorMessage = "Address Will be Required")]

                    public string? Address { get; set; } = null;
                    [Required(ErrorMessage = "DateOfBirth Will be Required")]

                    public DateOnly? DateOfBirth { get; set; } = null;
                    [Required(ErrorMessage = "Gender Will be Required")]

                    public string? Gender { get; set; } = null;
                    [Required(ErrorMessage = "Mobile  Number is required.")]
                    [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Mobile  Number")]
                    public string? MobileNumber { get; set; } = null;
                    [Required(ErrorMessage = "InterviewName Will be Required")]

                    public string? TotalExperience { get; set; } = null;
                    [Required(ErrorMessage = "RelevantExperience Will be Required")]

                    public string? RelevantExperience { get; set; } = null;
                    [Required(ErrorMessage = "HIGHEREDUCATION/Higher Qualificaiton Will be Required")]

                    public string? HIGHEREDUCATION { get; set; } = null;// Higher Qualificaiton
                    [Required(ErrorMessage = "HIgherPercentage Will be Required")]
                    [PercentageValidation(MinimumPercentage = 60, ErrorMessage = "HighPercnetage must be 60% or above.")]


                    public string? HIgherPercentage { get; set; } = null;


                    [Required(ErrorMessage = "CurrentCTC Will be Required")]

                    public string? CurrentCTC { get; set; } = null;
                    [Required(ErrorMessage = "ExpectedCTC Will be Required")]

                    public string? ExpectedCTC { get; set; } = null;




                    [Required(ErrorMessage = "TechnicalSkill  Will be Required")]


                    public string? Skill { get; set; } = null;


                    [Required(ErrorMessage = "Reasonchangethecompany Will be Required")]

                    public string? Reasonchangethecompany { get; set; } = null;

                    public string? PANCARDNUMBER { get; set; } = null;
                    [Required(ErrorMessage = "image Will be Required")]

                    public string? image { get; set; } = null;
                    [Required(ErrorMessage = "Resume_CV Will be Required")]

                    public string? Resume_CV { get; set; } = null;
                    [Required(ErrorMessage = "Feedback  Will be Required")]


                    public string? PositionFeedback { get; set; } = null;





          }
}
