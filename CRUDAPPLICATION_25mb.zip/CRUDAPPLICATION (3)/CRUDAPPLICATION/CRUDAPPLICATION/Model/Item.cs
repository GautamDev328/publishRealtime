﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class Item
          {
                    [Key]
                         public int Id { get; set; }
                    [Required(ErrorMessage ="SearchName will be required")]
                    public string? Name { get; set; } = null;
                    [Required(ErrorMessage = "SearchDescription will be required")]

                    public string? Description { get; set; } = null;
                    [Required(ErrorMessage = "SearchPrice will be required")]

                    public decimal? Price { get; set; } = null;
                    [Required(ErrorMessage = "Search will be required")]

                    public string? Category { get; set; } = null;
                    [Required(ErrorMessage = "SearchImageUrl will be required")]

                    public string? ImageUrl { get; set; } = null;
                    }

          }
