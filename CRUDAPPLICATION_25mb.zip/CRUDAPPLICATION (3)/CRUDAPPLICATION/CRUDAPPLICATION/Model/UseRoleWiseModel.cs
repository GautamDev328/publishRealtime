﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class UseRoleWiseModel
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Please fill  the UseRoleWIse")]

        public string? RoleName { get; set; } = null;
    }
}
