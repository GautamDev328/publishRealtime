﻿using CRUDAPPLICATION.DATABASE;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class BankModel 


          {
                    [Key]
                    public int BankId { get; set; }
                    [Required(ErrorMessage = "Please fill the Bank Customer Name")]
                    public string? BankCustomerName { get; set; } = null;

                    [Required(ErrorMessage = "Please fill the BankName ")]
                    public string? BankName { get; set; } = null;



                    [Required(ErrorMessage = "Please fill the Account Number")]
                    [StringLength(18, MinimumLength = 9, ErrorMessage = "Account Number should be between 9 and 18 DIGITS .")]

                    public string? AccountNumber { get; set; } = null;



                    [Required(ErrorMessage = "Please fill the IFSC Code.")]
                    [StringLength(11, MinimumLength = 11, ErrorMessage = "IFSC Code must be exactly 11 characters.")]
                    [RegularExpression("^[A-Z]{4}0[A-Z0-9]{6}$", ErrorMessage = "Please Select the IFSC Code First 4 digit chararcter and 7 digit number.")]
                    public string? IFSCCODE { get; set; } = null;


                    [Required(ErrorMessage = "Please  the Confrim Account Number")]
                   [Compare("AccountNumber", ErrorMessage = "Account numbers do not match.")]

                    public string? ConfirmAccountNumber { get; set; } = null;

                    [Required(ErrorMessage = "Please fill the StatusCode ")]
                    public string? StatusCode { get; set; } = null;

                    public string? MICRCODE { get; set; } = null;

                    [Required(ErrorMessage = "Please fill the BranchName ")]
                    public string? BranchName { get; set; } = null;

                    [Required(ErrorMessage = "Please fill the DistrictName ")]
                    public string? DistrictName { get; set; } = null;

                    [Required(ErrorMessage = "Please fill the Address ")]
                    public string? Address { get; set; } = null;

                    [Required(ErrorMessage = "Please fill the State ")]
                    public string? State { get; set; }

                    public string? BankDescription { get; set; } = null;
          }


}