﻿using System.ComponentModel.DataAnnotations;
using System.Net;

namespace CRUDAPPLICATION.Model
{
          public class GetEmailSetting
          {
                    [Key]
                    public int EmaiId {  get; set; }        
                    public string SecurityKey { get; set; }
                    public string From { get; set; }
                    public string SmtpServer { get; set; }
                    public int Port { get; set; }
                    public bool EnableSSL { get; set; }
                    public  bool Credentials { get; set; }
          }
}
