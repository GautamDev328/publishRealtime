﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class RelationModel
    {
        [Key]
        public int Relat_Id { get; set; }
        [Required(ErrorMessage = "Please fill  the RefrenceRelationName")]

        public string?  RefrenceRelation_Name { get; set; } 
        
        [Required(ErrorMessage = "Please fill  the ReferenceRelation")]


        public string? ReferenceRelation {  get; set; } 

        [Required(ErrorMessage = "Contact No is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid MobileNumber Number.")]
        public string? MobileNumber { get; set; } 
      
       




    }
}
