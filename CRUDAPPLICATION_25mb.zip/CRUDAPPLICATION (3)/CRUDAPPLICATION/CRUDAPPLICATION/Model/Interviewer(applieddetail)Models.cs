﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class Interviewer_applieddetail_Models
          {
                    [Key]
                    public int interviewID { get; set; }

                    [Required(ErrorMessage = "FirstName Will be Required")]
                    public string? FirstName { get; set; } = null;
                    //  [Required(ErrorMessage = "MiddleName Will be Required")]

                    public string? MiddleName { get; set; } = null;
                    [Required(ErrorMessage = "LastName Will be Required")]

                    public string? LastName { get; set; } = null;
                    [Required(ErrorMessage = "EmailAddress Will be Required")]
                    [EmailAddress]
                    public string? EmailAddress { get; set; } = null;
                    [Required(ErrorMessage = "Address Will be Required")]

                    public string? Address { get; set; } = null;
                    [Required(ErrorMessage = "HIGHEREDUCATION Will be Required")]

                    public string? HIGHEREDUCATION { get; set; } = null;


                    [Required(ErrorMessage = "MobileNumber is required.")]
                    [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid MobileNumber")]
                    public string? MobileNumber { get; set; } = null;
                    [Required(ErrorMessage = "InterviewName Will be Required")]


                    public string? InterviewerName { get; set; } = null;
                    [Required(ErrorMessage = "Knowledge Will be Required")]

                    public string? Skill { get; set; } = null;





                    [Required(ErrorMessage = "InterviewerAccept/Reject Will be Required")]

                    public string? InterviewerAccept_Reject { get; set; } = null;
                    //[Required(ErrorMessage = "InterviewerReJECT Will be Required")]

                    //public string? InterviewerReJECT { get; set; } = null;
                    [Required(ErrorMessage = "InterviewerStatus Will be Required")]

                    public string? InterviewerStatus { get; set; } = null;
                    [Required(ErrorMessage = "ReschdueDate_time Will be Required")]


                    public DateOnly? lastestReschdueDate_time { get; set; } = null;

                  

                    [Required(ErrorMessage = "Resume_CV Will be Required")]

                    public string? Resume_CV { get; set; } = null;
                    [Required(ErrorMessage = "fEEDBACK Will be Required")]


                    public string? fEEDBACK { get; set; } = null;


          }
}
