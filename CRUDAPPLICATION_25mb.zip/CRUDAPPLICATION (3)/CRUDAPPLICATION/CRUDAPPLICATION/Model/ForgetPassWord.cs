﻿//using System.ComponentModel.DataAnnotations;

//namespace CRUDAPPLICATION.Model
//{
//    public class ForgetPassWord
//    {
//        [Key]
//        public int id { get; set; }
//        //[Required(ErrorMessage = "Email No is required.")]
//        [Required]
//        [Display(Name = "Email or Mobile Number")]

//        [EmailAddress]

//        public string EmailOrPhone { get; set; }
//        //[Required(ErrorMessage = "Contact No is required.")]
//        //[RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]

//        //public string? MobileNumber { get; set; } = null; 
//        [Required]
//        [DataType(DataType.Password)]
//        public string NewPassword { get; set; }
//    }
//}
