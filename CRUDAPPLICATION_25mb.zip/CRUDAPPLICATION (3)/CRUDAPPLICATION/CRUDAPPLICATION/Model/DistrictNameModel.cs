﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class DistrictNameModel
          {
                    [Key]
                    public int DistrictId { get; set; }
                    public string? DistrictName { get; set; } = null;
                    public string? StateName { get; set; } = null;

          }
}
