﻿
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class CustomerdetailsModel
          {
                    [Key]
                    public int CustId { get; set; }
                    [Required(ErrorMessage = "CustomerName/VendorName will be required")]
                    //[Display(Customer will be required)]
                    public string? CustomerName { get; set; } = null;
                    [Required(ErrorMessage = "CompanyName will be required")]

                    public string? CompanyName { get; set; } = null;
                    [Required(ErrorMessage = "Customerphone/Vendorphone will be required")]
                    [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]

                    public string? Customerphone { get; set; } =null;
                    [Required(ErrorMessage = "Companyphone will be required")]

                    public string? Companyphone { get; set; } = string.Empty!;
                    [Required(ErrorMessage = "CustomerAddress/VendorAddress  will be required")]

                    public string? CustomerAddress { get; set; } = null;
                    [Required(ErrorMessage = "CompanyAddress will be required")]

                    public string? CompanyAddress { get; set; } = null;
                    [Required(ErrorMessage = "CustomerType/VendorType will be required")]

                    public string? CustomerType { get; set; } = null;
                    [Required(ErrorMessage = "customerGstno/ClientGstNo will be required")]

                    public string? customerGstRno { get; set; } = null;
                    [Required(ErrorMessage = "CompanyGstRno will be required")]

                    public string? CompanyGstRno { get; set; } = null;
                    //Print data 
                    public DateOnly?  custCurrentDate { get; set; } = null;

                   // public int customertypeid { get; set; } 
                    //public string? TypeCustomer { get; set; } = null;// customerType



          }

          //public class CustomerTypeModel
          //{

          //          [key]
          //          public int customertypeid { get; set; }
          //          public string? TypeCustomer { get; set; } = null;// customerType
          //}


}

