﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class RoleWiseModel
    {
        [Key]
        public int Role_ID { get; set; }
        [Required(ErrorMessage = "Please fill  the RoleName")]

        public string? Role_Name { get; set; } = null;
    }
}



//public class RoleMenuMaster
//{
//    public string RoleId { get; set; }
//    public string RoleName { get; set; }
//    public string EmpID { get; set; }
//    public string EmpCode { get; set; }
//    public string EmpName { get; set; }
//}


//public class RoleSideMenuBar
//{
//    public int MenuDisplaySeqNo { get; set; }
//    public int ParentMenuID { get; set; }
//    public string MenuName { get; set; }
//    public string MenuUrl { get; set; }
//    public int SubMenuDisplaySeqNo { get; set; }
//    public int ChildMenuID { get; set; }
//    public string Title { get; set; }
//    public string Controller { get; set; }
//    public string Action { get; set; }

//}