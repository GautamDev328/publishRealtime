﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class Country
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="Enter the CountryName")]
        public string? CountryName { get; set; } = null;

    }
}
