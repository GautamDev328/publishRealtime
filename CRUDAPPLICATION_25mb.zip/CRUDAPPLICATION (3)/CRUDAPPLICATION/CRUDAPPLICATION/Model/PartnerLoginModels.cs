﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class PartnerLoginModels
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Please Fill the PartnerId")]

        public string? PartnerId { get; set; } = null;
        [Required(ErrorMessage = "Please Fill the UserName")]

        public string? UserName { get; set; } = null;
        [Required(ErrorMessage = "Please Fill the UserPassword")]

        public string? UserPassword { get; set;} = null;
        [Required(ErrorMessage = "Please Fill the UserEmail")]
        [EmailAddress]
        public string? UserEmail { get; set;} = null;
        [Required(ErrorMessage = "Contact No is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]
        public string? UserPhone { get; set;} = null;

         
    }
}
