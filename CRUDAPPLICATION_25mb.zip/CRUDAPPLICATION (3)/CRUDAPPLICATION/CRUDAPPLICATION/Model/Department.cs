﻿//using System.ComponentModel.DataAnnotations;

//namespace CRUDAPPLICATION.Model
//{
//    public class Department
//    {
//        [Key]
//        public int id { get; set; }
//        [Required(ErrorMessage ="Please File the DepartmentName")]
//        public string? Dep_Name { get; set; } 

//    }
//}


using System.ComponentModel.DataAnnotations;


namespace CRUDAPPLICATION.Model
{
          public class Department
          {
                    [Key]
                   // [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
                    public int id { get; set; }

                    [Required(ErrorMessage = "Please File the DepartmentName")]
                    public string? Dep_Name { get; set; } = null;
          }
}