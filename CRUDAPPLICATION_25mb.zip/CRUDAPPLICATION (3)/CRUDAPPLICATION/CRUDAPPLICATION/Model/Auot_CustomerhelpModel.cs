﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class Auot_CustomerhelpModel
          {
                    [Key]
                    public int CustomerId { get; set; }
                    public string? CustomerName { get; set; } = null;
                    public string? Email { get; set; } = null;
                    public string? Phone { get; set; } = null;
                    public string? Address { get; set; } = null;
                    public string? Message { get; set; } = null;      
                    public DateTime? CreatedDate { get; set; } = null;
                    //public bool IsActive { get; set; }

          }
}
