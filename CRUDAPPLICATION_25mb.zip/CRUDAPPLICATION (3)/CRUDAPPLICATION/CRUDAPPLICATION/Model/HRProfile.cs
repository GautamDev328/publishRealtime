﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class HRProfile
    {
        [Key]
        public int HR_Id { get; set; }
        [Required(ErrorMessage = "HR_Name Will be required")]

        public string? HR_Name { get; set; } = null;
        [Required(ErrorMessage = "HR_Email Will be required")]
        [EmailAddress]
        public string? HR_Email { get; set; } = null;
        [Required(ErrorMessage = "HR_ContactNumber  is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid HR_ContactNumber")]
        public string? HR_ContactNumber { get; set; } = null;
        [Required(ErrorMessage = "HR_Designation Will be required")]
        public string? HR_Designation { get; set; } = null;
        [Required(ErrorMessage = "Email Will be required")]

        public string? HR_Department { get; set; } = null;
        [Required(ErrorMessage = "HR_LoginTIME Will be required")]

        public DateOnly? HR_LoginTIME { get; set; } = null;
        [Required(ErrorMessage = "HR_LoginType(Active/DisActive) Will be required")]

        public string? HR_LoginType { get; set; } = null;
        [Required(ErrorMessage = "HR_Gender Will be required")]

        public string? HR_Gender { get; set; } = null;
        [Required(ErrorMessage = "HR_Feedback(PerformanceFeedback Will be required")]

        public string? HR_Feedback { get; set; } = null;
        [Required(ErrorMessage = "HR_MailMessage(Accept/Reject) Will be required")]

        public string? HR_MailMessage { get; set; } = null;
        public string? OtherRequiredData { get; set; } = null;

    }
}
