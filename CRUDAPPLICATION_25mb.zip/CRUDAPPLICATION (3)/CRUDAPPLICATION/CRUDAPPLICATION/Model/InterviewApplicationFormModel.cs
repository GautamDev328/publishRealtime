﻿
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class InterviewApplicationFormModel
          {
                    [Key]
                    public int interviewApplicationId { get; set; }

                    [Required(ErrorMessage = "FirstName Will be Required")]
                    public string? FirstName { get; set; } = null;
                    //[Required(ErrorMessage = "MiddleName Will be Required")]

                    public string? MiddleName { get; set; } = null;
                    [Required(ErrorMessage = "LastName Will be Required")]

                    public string? LastName { get; set; } = null;
                    [Required(ErrorMessage = "EmailAddress Will be Required")]
                    [EmailAddress]
                    public string? EmailAddress { get; set; } = null;

                    [Required(ErrorMessage = "Address Will be Required")]

                    public string? Address { get; set; } = null;
                    [Required(ErrorMessage = "DateOfBirth Will be Required")]

                    public DateOnly? DateOfBirth { get; set; } = null;
                    [Required(ErrorMessage = "Gender Will be Required")]

                    public string? Gender { get; set; } = null;
                    [Required(ErrorMessage = "MobileNumber is required.")]
                    [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid MobileNumber")]
                    public string? MobileNumber { get; set; } = null;
                    [Required(ErrorMessage = "InterviewName Will be Required")]


                    public string? InterviewerName { get; set; } = null;
                    [Required(ErrorMessage = "InterviewSchedule Will be Required")]


                    public DateOnly? InterviewSchedue { get; set; } = null; //  // Automatic show the  datetime  show the avaible interview
                    [Required(ErrorMessage = "PositionApplied/DesignationName Will be Required")]

                    public string? PositionApplied_DesignationName { get; set; } = null; // Desingation Applied 

                    [Required(ErrorMessage = "Department Will be Required")]

                    public string? Department { get; set; } = null; // Desingation Applied 
                    [Required(ErrorMessage = "TotalExperience Will be Required")]

                    public string? TotalExperience { get; set; } = null;
                    [Required(ErrorMessage = "RelevantExperience Will be Required")]

                    public string? RelevantExperience { get; set; } = null;


                    [Required(ErrorMessage = "Knowledge Will be Required")]

                    public string? Skill { get; set; } = null;


                    [Required(ErrorMessage = " 10thpercentage Will be Required")]
                    [PercentageValidation(MinimumPercentage = 60, ErrorMessage = "10th Percentage must be 60% or above.")]

                    public string?   Matricthpercentage { get; set; } = null;

          
                    [Required(ErrorMessage = " 12thpercentag Will be Required")]
                    [PercentageValidation(MinimumPercentage = 60, ErrorMessage = "12th Percentage must be 60% or above.")]

                    public string?  Interpercentag { get; set; } = null;


                    [Required(ErrorMessage = "GraduationPercentage Will be Required")]
                    [PercentageValidation(MinimumPercentage = 60, ErrorMessage = "Graduation Percentage must be 60% or above.")]

                    public string? GraduationPercentage { get; set; } = null;


                   [Required(ErrorMessage = "POSTGRADUATEPercentage Will be Required")]
                    [PercentageValidation(MinimumPercentage = 60, ErrorMessage = "HIGHEREDUCATION Percentage must be 60% or above.")]

                    public string? POSTGRADUATEPercentage { get; set; } = null;
                    [Required(ErrorMessage = "HIGHEREDUCATION Will be Required")]

                    public string? HIGHEREDUCATION { get; set; } = null;// HigherQualification 
                    [Required(ErrorMessage = "HighPercentage Will be Required")]
                    [PercentageValidation(MinimumPercentage = 60, ErrorMessage = "HighPercnetage must be 60% or above.")]

                    public string? HighPercentage { get; set; } = null;// HigherQualification 


                    [Required(ErrorMessage = "CurrentCTC Will be Required")]

                    public string? CurrentCTC { get; set; } = null;
                    [Required(ErrorMessage = "ExpectedCTC Will be Required")]

                    public string? ExpectedCTC { get; set; } = null;
                    [Required(ErrorMessage = "Monthly_CTC Will be Required")]

                    public string? Monthly_CTC { get; set; } = null;
                    [Required(ErrorMessage = "Monthly_Ectc Will be Required")]


                    public string? Monthly_Ectc { get; set; } = null;
                    [Required(ErrorMessage = "NegotiationCTC Will be Required")]


                    public string? NegotiationCTC { get; set; } = null; // NegotiationCtc or fixed prices

                    [Required(ErrorMessage = "HrQUestion Will be Required")]


                    public string? HrQUestion { get; set; } = null;
                    [Required(ErrorMessage = "HrquestonFeedback Will be Required")]

                    public string? HrquestonFeedback { get; set; } = null;
                    [Required(ErrorMessage = "HrQuestionAccept/Reject Will be Required")]

                    public string? HrQuestionAccept_Reject { get; set; } = null;
                    //[Required(ErrorMessage = "HrQuestionReject Will be Required")]

                    //public string? HrQuestionReject { get; set; } = null;

                   
                    [Required(ErrorMessage = "Reject_AcceptReasonDate Will be Required")]

                    public DateOnly? Reject_AcceptReasonDate { get; set; } = null;



                    [Required(ErrorMessage = "Reasonchangethecompany Will be Required")]

                    public string? Reasonchangethecompany { get; set; } = null;


                    [Required(ErrorMessage = "12 digit EPFO_UANNUMBER / UAN NUMBER  Will be Required")]

                    public string? EPFO_UANNUMBER { get; set; } = null;//  UAN NUMBER
                   
                    [Required(ErrorMessage = "Please EESIC_IPNumber/IP  First 2 digit AreaCode and 8 digit Insurance/Employee Code    Number Will be Required")]

                    public string? ESIC_IPNumber { get; set; } = null; //IP Number

                    public string? AadharNumber { get; set; } = null;
                    public string? PancardNumber { get; set; } = null;
                    [Required(ErrorMessage = "Resume  Will be Required")]


                    public string? Resume { get; set; } = null;
                    [Required(ErrorMessage = "photo  Will be Required")]

                    public string? photo { get; set; } = null;
                    [Required(ErrorMessage = "PositionFeedback  Will be Required")]


                    public string? PositionFeedback { get; set; } = null;

                    //public OpenPositonAppliedModelcs? openmodel {get; set; } = null;





    }
}
