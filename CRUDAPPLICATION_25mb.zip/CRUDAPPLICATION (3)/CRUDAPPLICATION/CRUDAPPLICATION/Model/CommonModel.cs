﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class CommonModel
          {
                    [Key]
                    public int prop { get; set; }
                    public string? MyProperty { get; set; } = null;
          }
}
