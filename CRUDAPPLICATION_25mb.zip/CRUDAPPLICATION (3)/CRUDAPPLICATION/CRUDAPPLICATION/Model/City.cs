﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class City
    {

        [Key]
        public int City_Id { get; set; }
        [Required(ErrorMessage ="Enter the CityName")]
                  //  [Display(Name = "City Name")]
                    public string? City_Name { get; set; } = null;
        [Required(ErrorMessage = "Enter the StateName")]

        public string? StateName { get; set; } = null;
       // public string? Id { get; set; } = null;
    }
}

