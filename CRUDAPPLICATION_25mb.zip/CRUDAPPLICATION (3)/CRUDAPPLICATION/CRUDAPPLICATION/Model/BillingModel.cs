﻿using CRUDAPPLICATION.ModelDTO;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Drawing.Printing;

namespace CRUDAPPLICATION.Model
{

          public class BillingModel
          {
                    [Key]

                    public int BillingId { get; set; }

                    [Required]
                    //// [ForeignKey(nameof(Customer))] // This ensures EF Core correctly maps the foreign key
                    public int CustomerId { get; set; }

                     [Required(ErrorMessage = "Enter the FullName")]
                    public string? FullName { get; set; } = " ";
                  //  public string? FullName { get; set; } = "  ";//"N/A"; // Default "N/A"

                    [EmailAddress]
                    [Required(ErrorMessage = "Please Select the Email")]
                    public string? Email { get; set; } = " ";

                   [Required(ErrorMessage = "Enter the Address")]
                    public string? Address { get; set; } = " ";

                    [Required(ErrorMessage = "Enter the City")]
                    public string? City { get; set; } = "";
                    [Required(ErrorMessage = "StateName will be required")]
                    public string? State { get; set; } = " ";

                    [Required(ErrorMessage = "Bank name will be required")]
                    public string? BankName { get; set; } = " ";

                      [Required(ErrorMessage = "Card number will be required")]
                    public string? CardNumber { get; set; } = "";

                    public string? ExpMonth { get; set; } = "";
                    public string? ExpYear { get; set; } ="";

                    public string? CVV { get; set; } =" ";
                    [Required(ErrorMessage ="Please fill the TotalAmount")]

                    public string? OtherAmount { get; set; } = " ";

                    public DateOnly? BillingDate { get; set; } = null;

                    // public DateOnly? BillingCurrentDate { get; set; } = null;

                    // ✅ Automatically generated voucher number (e.g., "INV000123")

                    public string? BillingVoucherNumber { get; set; } = " ";// invoice  number

                    public string? Bankupi {  get; set; } = " ";

                    public string? ProductDescription { get; set; } =" ";

                    public string?   Quantity { get; set; } = " ";
                    public string? Rate { get; set; } = " ";

                    public string? Amount { get; set; } = " ";

                    public string? CGST { get; set; } = " ";
                    public string? SGST { get; set; } =" ";
                    public string? IGST { get; set; } =" ";


                    public string? TotalInWords { get; set; } =" ";

               //     public List<BillingItemDTO> BillingItems { get; set; }      


                  
                   
          }
}
