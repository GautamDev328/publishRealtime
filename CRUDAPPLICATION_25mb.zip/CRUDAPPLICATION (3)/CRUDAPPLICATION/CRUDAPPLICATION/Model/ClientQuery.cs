﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class ClientQuery
    {
     

            [Key]
        public int c_Id { get; set; }
        [Required(ErrorMessage = "FirstName will be required")]
        [StringLength(100)]

        public string? clientFirtName { get; set; } = null;

        [Required(ErrorMessage = "LastName will be requied")]

        public string? clientLastName { get; set; } = null;


        [Required(ErrorMessage = "State will be requied")]

        public string? State { get; set; } = null;
        [Required(ErrorMessage = "City will be requied")]


        public string? City { get; set; } = null;
        [Required(ErrorMessage = "ContactNumber   is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]



        public string? ContactNumber { get; set; } = null;

        [Required(ErrorMessage = "clientDescription will be requied")]


        public string? clientDescription { get; set; } = null;
        [Required(ErrorMessage = "Country will be requied")]
        public string? Country { get; set; } = null;


    }
}

