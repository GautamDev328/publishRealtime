﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class EmployeeQuery
    {
        [Key]
        public int Emp_Id { get; set; }
        [Required(ErrorMessage = "Please Fill the EmployeeName")]

        public string? EmployeeName { get; set; } = null;
        [Required(ErrorMessage = "Please Fill the EmployeeQueryMessage")]

        public string? EmployeeQueryMessage { get; set; } = null;
        [Required(ErrorMessage = "Please Fill the Date")]

        public DateTime?  GetDateOnly { get; set; } = null;
    }
}
