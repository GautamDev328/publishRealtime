﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class AddRelationShipModel
    {
        [Key]
        public int Relation_id { get; set; }
        [Required(ErrorMessage ="please Select the RelationShip")]
        public string? AddRelationShip { get; set; }
    }

}
