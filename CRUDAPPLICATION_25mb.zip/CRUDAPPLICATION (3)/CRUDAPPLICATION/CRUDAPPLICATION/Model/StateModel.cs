﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class StateModel
    {
        [Key]
        public int Id { get; set; }
       
        [Required(ErrorMessage = "Please fill the StateName ")]

        public string? StateName { get; set; } = null;

                   // public String? pINCODE { get; set; } = null;
  
       
        

    }
}
