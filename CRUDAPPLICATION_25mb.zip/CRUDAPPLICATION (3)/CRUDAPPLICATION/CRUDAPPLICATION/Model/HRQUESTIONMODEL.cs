﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class HRQUESTIONMODEL
          {
                    [Key]
                    public int HRQUESITONID { get; set; }

                    [Required(ErrorMessage = "Pleae Enter the HRKEYNUMBER")]
                    public int HRKEYNUMBER { get; set; }
                    [Required(ErrorMessage = "Please Enter HrQuestionKey")]
                    public string? HrQuestionKey { get; set; } = null;
          }
}
