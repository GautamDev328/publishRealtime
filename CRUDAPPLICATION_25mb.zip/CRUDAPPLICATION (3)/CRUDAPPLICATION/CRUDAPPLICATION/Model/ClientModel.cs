﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class ClientModel
    {
        [Key]
        public int Client_Id { get; set; }
        [Required(ErrorMessage = "ClientName Filled May be Required")]
        public string? ClientName { get; set; } = null;
        [Required(ErrorMessage = "Photo Filled May be Required")]

        public string? Photo { get; set; } = null;

    }
}
