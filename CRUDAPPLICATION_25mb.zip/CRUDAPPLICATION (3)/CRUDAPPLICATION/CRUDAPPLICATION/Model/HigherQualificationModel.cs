﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
          public class HigherQualificationModel
          {
                    [Key]
                    public int highId { get; set; }
                    [Required(ErrorMessage = "HigherQualificaiton will be required")]
                    //[Display(Name = "Higher Qualification")]
                    public string? HigherQualificaiton { get; set; } = null;
          }

}