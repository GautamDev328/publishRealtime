﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class DesignationModel
    {
        [Key]
        public int DesigId { get; set; }
                    [Required(ErrorMessage = "Please Fill the Department Name")]
                    [Display(Name = "Department Name")]
                    public string? DesigType { get; set; } = null;

                    [Required(ErrorMessage ="Please Fill the DesingationName")]
        public string? DesigName { get; set; } = null;
      


    }
}
