﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class UserTrailsModels
    {
        [Key]
        public int UsertrailId { get; set; }
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? CompanyId { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? CompanyName { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? CompanyAddress { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? EmailAddress { get; set; } = null;
        [Required(ErrorMessage = "Contact No is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]
        public string? PhoneNumber { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? CorporateId { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? UserName { get; set; } = null;
        [Required]
        [StringLength(100, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public string? Password { get; set; } = null;
        [Required]
        [StringLength(100, MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string? Confrompassword { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the PartnerId")]

        public string? PartnerId { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the DealerName")]

        public string? DealerName { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the photo")]

        public string? photodrop { get; set; } = null;


    }
}
