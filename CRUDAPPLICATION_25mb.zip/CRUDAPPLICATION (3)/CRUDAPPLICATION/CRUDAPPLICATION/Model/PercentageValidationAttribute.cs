﻿using System.ComponentModel.DataAnnotations;

public class PercentageValidationAttribute : ValidationAttribute
{
          public double MinimumPercentage { get; set; } = 60;

          protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
          {
                    if (value is string percentageString && double.TryParse(percentageString, out double percentage))
                    {
                              if (percentage >= MinimumPercentage)
                              {
                                        return ValidationResult.Success;
                              }
                              return new ValidationResult(ErrorMessage ?? $"Percentage must be greater than or equal to {MinimumPercentage}.");
                    }

                    return new ValidationResult(ErrorMessage ?? "Invalid percentage format.");
          }
}
