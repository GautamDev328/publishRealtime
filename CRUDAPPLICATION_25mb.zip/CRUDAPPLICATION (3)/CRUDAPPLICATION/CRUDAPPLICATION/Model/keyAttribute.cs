﻿namespace CRUDAPPLICATION.Model
{
    internal class keyAttribute : Attribute
    {
    }
}