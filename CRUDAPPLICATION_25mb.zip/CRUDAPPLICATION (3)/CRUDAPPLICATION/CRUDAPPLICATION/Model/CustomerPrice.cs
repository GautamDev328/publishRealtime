﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class CustomerPrice
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="please fill the CustomerExtraPrice")]
        public string? CustomerExtraPrice { get; set; } = null;
        [Required(ErrorMessage = "please fill the CustomerExtraUser")]

        public string? CustomerExtraUser { get; set; } = null;
    }
}
