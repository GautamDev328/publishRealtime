﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class EmployeeProfile
    {
                    [Key]
                    public int EmpId { get; set; }

                    [Display(Name = "Employee ID")]
                    public string FormattedEmpId
                    {
                              get
                              {
                                        return $"Emp01{EmpId}";
                              }
                    }


          [Required(ErrorMessage ="Enter the FirstName")]
        public string? FirstName { get; set; } = null;
   
        public string? MiddleName { get; set; } = null;
        [Required(ErrorMessage = "Enter the LastName")]

        public string? LastName { get; set; } = null;

        [Required(ErrorMessage = "Enter the QUALIFICAION")]


        public string? Designation { get; set; }= null; /*QUALIFICAION*/

        [Required(ErrorMessage = "Enter the Address")]

        public string? Address { get; set; }=null;
        [Required(ErrorMessage = "Enter the City")]

        public string? City { get; set; } =null;
        [Required(ErrorMessage = "Contact No is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Contact Number.")]

        public string? Mobile { get; set; } = null;
                    [Required(ErrorMessage = "PIN NUMBER /ZIP CODE FILLED ARE REQUIRED")]
                    public string? PinCode { get; set; } = null;
                    [Required(ErrorMessage="State  will be   required")]
        public string? StateName {  get; set; } = null;
                    [Required(ErrorMessage = "Please Select the DepartmentName")]

                    public string? DepartmentName { get; set; } = null;
                    [Required(ErrorMessage = "Please Select the DesignationName")]

                    public string? DesignationName { get; set; } = null;



       [Required(ErrorMessage ="Please Select the Email")]
                    [EmailAddress]



                    public string? Emailid { get; set; } = null;

        [Required(ErrorMessage = "Please Select the Gender")]



        public string? Gender { get; set; } = null;
        //[Required(ErrorMessage = "Please Select the DateOfBirth")]


        //public DateOnly DateOfBirth { get; set; } 
        [Required(ErrorMessage = "Please Select the Age")]


        public int? Age { get; set; } = null;






          }
}

