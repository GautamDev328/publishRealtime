﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAPPLICATION.Model
{
    public class RoleWiseOnlyEmployee
    {
        [Key]
        public int RoleWiseonlyId { get; set; }
        [Required(ErrorMessage = "Please fill  the RoleWiseonlyName")]

        public string? RoleWiseonlyName { get; set; } = null;
        [Required(ErrorMessage = "Please fill  the RoleName")]

        public string? Role_Name { get; set; } = null;
    }
}
