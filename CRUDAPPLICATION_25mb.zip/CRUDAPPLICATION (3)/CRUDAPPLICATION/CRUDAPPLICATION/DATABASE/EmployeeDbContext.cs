﻿using CRUDAPPLICATION.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Options;


namespace CRUDAPPLICATION.DATABASE
{
          public class EmployeeDbContext : DbContext
          {
                    public EmployeeDbContext(DbContextOptions<EmployeeDbContext> opt) : base(opt)
                    {

                    }
                    public DbSet<AddRelationShipModel> addRelationShipModelss { get; set; }
                    public DbSet<BankModel> bankModelss { get; set; }
                    public DbSet<City> cityss { get; set; }
                    public DbSet<ClientModel> clientModelss { get; set; }
                    public DbSet<ClientQuery> clientQueryss { get; set; }
                    public DbSet<Country> countriess { get; set; }
                    public DbSet<BillingModel> billingModelsss { get; set; }

                    public DbSet<CustomerdetailsModel> customerdetailsModelsss { get; set; }
                    //  public DbSet<CustomerTypeModel> customerTypemodless { get; set; }      
                    public DbSet<CustomerPrice> customerPricess { get; set; }
                    public DbSet<Department> departments { get; set; }
                    public DbSet<DesignationModel> designationss { get; set; }
                    public DbSet<EmployeeProfile> employeeProfiless { get; set; }
                    public DbSet<EmployeeQuery> employeeQuerys { get; set; }
                    public DbSet<Gender> genders { get; set; }
                    public DbSet<HRProfile> hRProfiless { get; set; }
                    public DbSet<Item> itemss { get; set; }
                    //   public DbSet<PartnerLoginModels> partnerLoginModels { get; set; }
                    public DbSet<PaymentCustomerExtraUserModel> paymentCustomeExtraUserModelss { get; set; }
                    public DbSet<HigherQualificationModel> higherQualificationModelss { get; set; }
                    public DbSet<RegisterationForm> registerationFormsss { get; set; }
                    public DbSet<RelationModel> relationModelss { get; set; }
                    public DbSet<RoleWiseModel> roleWises { get; set; }
                    public DbSet<RoleWiseOnlyEmployee> RoleWiseOnlyEmployeess { get; set; }
                    public DbSet<StateModel> statess { get; set; }
                    public DbSet<UseRoleWiseModel> useRoleWiseModelss { get; set; }
                    public DbSet<UserTrailsModels> userTrailss { get; set; }
                    public DbSet<HRQUESTIONMODEL> HRQUESTIONMODELss { get; set; }

                    // Interview Details

                    public DbSet<OpenPositonAppliedModelcs> OpenPositonAppliedModelcss { get; set; }
                    public DbSet<InterviewApplicationFormModel> interviewApplicationFormModelss { get; set; }
                    public DbSet<Interviewer_applieddetail_Models> interviewer_applieddetailModelss { get; set; }
                    public DbSet<RescheduleDateInterviewOPENINGMODEL> rescheduleDatess { get; set; }
                    public DbSet<Auot_CustomerhelpModel> auot_CustomerhelpModelsss { get; set; }
                    public DbSet<DistrictNameModel> districtNameModelss { get; set; }
                    //print 
                    //public DbSet<CommonBillingVoucherDTO> commonBillingVoucherDTOs { get; set; }
                    public DbSet<CommonModel> commonmdoes { get; set; }
                    protected override void OnModelCreating(ModelBuilder modelBuilder)
                    {

                            


                              modelBuilder.Entity<RegisterationForm>()
                                  .Property(b => b.FirstLoginTime)
                                  .HasDefaultValueSql("GETDATE()");

                              modelBuilder.Entity<RegisterationForm>()
                                  .Property(b => b.LastLoginTime)
                                  .HasDefaultValueSql("GETDATE()");


                              modelBuilder.Entity<Department>()
                                  .HasKey(d => d.id);

                              modelBuilder.Entity<Department>()
                                  .Property(d => d.id)
                                  .ValueGeneratedOnAdd();



                              modelBuilder.Entity<Item>()
    .Property(p => p.Price)
    .HasColumnType("decimal(18,2)");


                    }


                    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
                    {
                              if (!optionsBuilder.IsConfigured)
                              {
                                        optionsBuilder.ConfigureWarnings(warnings =>
                                            warnings.Ignore(RelationalEventId.PendingModelChangesWarning));
                              }
                    }


          }

}