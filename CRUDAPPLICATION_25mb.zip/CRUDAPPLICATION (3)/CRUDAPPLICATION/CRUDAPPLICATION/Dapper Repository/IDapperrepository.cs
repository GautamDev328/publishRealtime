﻿//using Entity.DTO;
//using Entity.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DALC.DapperRepository
//{
//    public interface IDapperrepository
//    {

//       // public Task UpdateAuditor(int Id);

//        //public Task<IEnumerable<gst_auditormaster>> GetAuditor();
//        public int UpdateDelflag(long Id, string tblName, string ColName);

//      //  public AuditorMasterViewDto GetAllAuditorList();
//        public Entity.DTO.AllListDTO GetAllList();

//     //   public Task<IEnumerable<AuditorMasterViewModel>> GetAuditorByDapper();

//    }
//}
