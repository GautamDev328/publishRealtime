﻿//using Dapper;
//using Entity.Models;
//using Microsoft.Extensions.Configuration;
//using System.Data;
//using Entity.DTO;
//using WEBGSTCore;

//namespace DALC.DapperRepository
//{
//    public class DapperRepository : IDapperrepository
//    {
//        private readonly string connectionstring;
//        private readonly string wgstorgconnectionstring;
//        public DapperRepository(IConfiguration _con)
//        {
//            DatabaseHelper.con = _con;
//            connectionstring = _con.GetConnectionString("WebtelConnection");
//            wgstorgconnectionstring = _con.GetConnectionString("WebtelConnection1");
//        }

//        public AllListDTO GetAllList()
//        {
//            throw new NotImplementedException();
//        }

//        public int UpdateDelflag(long Id, string tblName, string ColName)
//        {
//            var query = "UPDATE " + tblName + " SET " + ColName + " = 1 WHERE ID = @Id";
//            var param = new DynamicParameters();
//            param.Add("Id", Id, DbType.Int32);
//            using (IDbConnection con = DatabaseHelper.GetCompConnection())
//            {
//                return con.Execute(query, param);

//            }
//        }
//        //public AllListDTO GetAllList()
//        //{
//        //    using (IDbConnection connection = new MySqlConnector.MySqlConnection(wgstorgconnectionstring))
//        //    {
//        //        connection.Open();

//        //        var query = "Select State,SCode From statemas;" + "Select ReasonCode, ReasonName From reasonmaster;"
//        //            + "Select ID, CommText From commissionermaster;";

//        //        IDataReader lst = connection.ExecuteReader(query);
//        //        AllListDTO lstAll = new AllListDTO();

//        //        lstAll.lstStatemas = new List<StateMasDTO>();
//        //        lstAll.lstcommissionerMaster = new List<CommissionerMaasterDTO>();
//        //        lstAll.lstreason = new List<ReasonDTO>();
//        //        while (lst.Read())
//        //        {
//        //            StateMasDTO ObjState = new StateMasDTO();
//        //            ObjState.PremiseState = lst["State"].ToString();
//        //            ObjState.SCode = lst["SCode"].ToString();
//        //            lstAll.lstStatemas.Add(ObjState);

//        //        }

//        //        lst.NextResult();
//        //        while (lst.Read())
//        //        {
//        //            ReasonDTO ObjReason = new ReasonDTO();
//        //            ObjReason.ReasonName = lst["ReasonName"].ToString();
//        //            ObjReason.ReasonCode = lst["ReasonCode"].ToString();
//        //            lstAll.lstreason.Add(ObjReason);
//        //        }

//        //        lst.NextResult();
//        //        while (lst.Read())
//        //        {
//        //            CommissionerMaasterDTO objCom = new CommissionerMaasterDTO();
//        //            objCom.Id = Convert.ToInt64(lst["ID"]);
//        //            objCom.CommText = lst["CommText"].ToString();
//        //            lstAll.lstcommissionerMaster.Add(objCom);
//        //        }
//        //        //lst.NextResult();

//        //        connection.Close();
//        //        return lstAll;

//        //    }



//        //}

//        //public AuditorMasterViewDto GetAllAuditorList()
//        //{
//        //    using (IDbConnection connection = new MySqlConnector.MySqlConnection(connectionstring))
//        //    {
//        //        connection.Open();
//        //        var query = "Select * From gst_auditormaster;";
//        //        IDataReader lst = connection.ExecuteReader(query);
//        //        AuditorMasterViewDto objAuditor = new AuditorMasterViewDto();

//        //        objAuditor.Lstauditormaster = new List<AuditorDTO>();
//        //        objAuditor.lstStatemas = new List<StateMasterDto>();
//        //        while (lst.Read())
//        //        {
//        //            AuditorDTO objAuditorMaster = new AuditorDTO();
//        //            objAuditorMaster.Id = (Int64)lst["Id"];
//        //            objAuditorMaster.FirmName = lst["FirmName"].ToString();
//        //            objAuditorMaster.PartnerName = lst["PartnerName"].ToString();
//        //            objAuditorMaster.Designation = (int)lst["Designation"];
//        //            objAuditorMaster.AuditorType = (int)lst["AuditorType"];
//        //            objAuditorMaster.MembershipNo = lst["MembershipNo"].ToString();
//        //            objAuditorMaster.BuildingNo = lst["BuildingNo"].ToString();
//        //            objAuditorMaster.FloorNo = lst["FloorNo"].ToString();
//        //            objAuditorMaster.BuildingName = lst["BuildingName"].ToString();
//        //            objAuditorMaster.StreetName = lst["StreetName"].ToString();
//        //            objAuditorMaster.City = lst["City"].ToString();
//        //            objAuditorMaster.District = lst["District"].ToString();
//        //            objAuditorMaster.State = lst["State"].ToString();
//        //            objAuditorMaster.Pincode = (int)lst["Pincode"];
//        //            objAuditorMaster.FirmRegNo = lst["FirmRegNo"].ToString();
//        //            objAuditorMaster.FirmPAN = lst["FirmPAN"].ToString();
//        //            objAuditorMaster.PartnerPAN = lst["PartnerPAN"].ToString();
//        //            objAuditor.Lstauditormaster.Add(objAuditorMaster);
//        //        }
//        //        connection.Close();
//        //        using (IDbConnection orgConnection = new MySqlConnector.MySqlConnection(wgstorgconnectionstring))
//        //        {
//        //            orgConnection.Open();

//        //            var Statequery = "Select State,SCode From statemas;";

//        //            IDataReader OrgDataReader = orgConnection.ExecuteReader(Statequery);
//        //            while (OrgDataReader.Read())
//        //            {
//        //                StateMasterDto ObjState = new StateMasterDto();
//        //                ObjState.State = OrgDataReader["State"].ToString();
//        //                ObjState.SCode = OrgDataReader["SCode"].ToString();
//        //                objAuditor.lstStatemas.Add(ObjState);

//        //            }
//        //            connection.Close();
//        //        }
//        //        return objAuditor;

//        //    }
//        //}


//        //public Task<IEnumerable<AuditorMasterViewModel>> GetAuditorByDapper()
//        //{
//        //    throw new NotImplementedException();
//        //}

//        //public Task<IEnumerable<AuditorMasterViewModel>> GetAuditorByDapper()
//        //{
//        //    using (IDbConnection connection = new MySqlConnector.MySqlConnection(connectionstring))
//        //    {
//        //        connection.Open();

//        //        var query = "Select State,SCode From statemas;" + "Select * From gst_auditormaster;";

//        //        IDataReader lst = connection.ExecuteReader(query);
//        //        AuditorMasterViewModel lstAll = new AuditorMasterViewModel();

//        //        lstAll.lstStatemas = new List<StateMas>();
//        //        lstAll.Lstauditormaster = new List<gst_auditormaster>();
//        //        while (lst.Read())
//        //        {
//        //            StateMas ObjState = new StateMas();
//        //            ObjState.State = lst["State"].ToString();
//        //            ObjState.SCode = lst["SCode"].ToString();
//        //            lstAll.lstStatemas.Add(ObjState);

//        //        }

//        //        lst.NextResult();
//        //        while (lst.Read())
//        //        {
//        //            gst_auditormaster objAuditorMaster = new gst_auditormaster();
//        //            objAuditorMaster.FirmName = lst["FirmName"].ToString();
//        //            objAuditorMaster.PartnerName = lst["PartnerName"].ToString();
//        //            objAuditorMaster.Designation = (int)lst["Designation"];
//        //            objAuditorMaster.AuditorType = (int)lst["AuditorType"];
//        //            objAuditorMaster.MembershipNo = lst["MembershipNo"].ToString();
//        //            objAuditorMaster.BuildingNo = lst["BuildingNo"].ToString();
//        //            objAuditorMaster.FloorNo = lst["FloorNo"].ToString();
//        //            objAuditorMaster.BuildingName = lst["BuildingName"].ToString();
//        //            objAuditorMaster.StreetName = lst["StreetName"].ToString();
//        //            objAuditorMaster.City = lst["City"].ToString();
//        //            objAuditorMaster.District = lst["District"].ToString();
//        //            objAuditorMaster.State = lst["State"].ToString();
//        //            objAuditorMaster.Pincode = (int)lst["Pincode"];
//        //            objAuditorMaster.FirmRegNo = lst["FirmRegNo"].ToString();
//        //            objAuditorMaster.FirmPAN = lst["FirmPAN"].ToString();
//        //            objAuditorMaster.PartnerPAN = lst["PartnerPAN"].ToString();
//        //        }

//        //        connection.Close();
//        //        return lstAll;
//        //    }

//        //    //public Task<IEnumerable<AuditorMasterViewModel>> GetAuditorByDapper()
//        //    //{
//        //    //    using (IDbConnection connection = new MySqlConnector.MySqlConnection(connectionstring))
//        //    //    {
//        //    //        connection.Open();

//        //    //        var query = "Select State,SCode From statemas;" + "Select * From gst_auditormaster;";

//        //    //        IDataReader lst = connection.ExecuteReader(query);
//        //    //        AuditorMasterViewModel lstAll = new AuditorMasterViewModel();

//        //    //        lstAll.lstStatemas = new List<StateMas>();
//        //    //        lstAll.Lstauditormaster = new List<gst_auditormaster>();
//        //    //        while (lst.Read())
//        //    //        {
//        //    //            StateMas ObjState = new StateMas();
//        //    //            ObjState.State = lst["State"].ToString();
//        //    //            ObjState.SCode = lst["SCode"].ToString();
//        //    //            lstAll.lstStatemas.Add(ObjState);

//        //    //        }

//        //    //        lst.NextResult();
//        //    //        while (lst.Read())
//        //    //        {
//        //    //            gst_auditormaster objAuditorMaster = new gst_auditormaster();
//        //    //            objAuditorMaster.FirmName = lst["FirmName"].ToString();
//        //    //            objAuditorMaster.PartnerName = lst["PartnerName"].ToString();
//        //    //            objAuditorMaster.Designation = (int)lst["Designation"];
//        //    //            objAuditorMaster.AuditorType = (int)lst["AuditorType"];
//        //    //            objAuditorMaster.MembershipNo = lst["MembershipNo"].ToString();
//        //    //            objAuditorMaster.BuildingNo = lst["BuildingNo"].ToString();
//        //    //            objAuditorMaster.FloorNo = lst["FloorNo"].ToString();
//        //    //            objAuditorMaster.BuildingName = lst["BuildingName"].ToString();
//        //    //            objAuditorMaster.StreetName = lst["StreetName"].ToString();
//        //    //            objAuditorMaster.City = lst["City"].ToString();
//        //    //            objAuditorMaster.District = lst["District"].ToString();
//        //    //            objAuditorMaster.State = lst["State"].ToString();
//        //    //            objAuditorMaster.Pincode = (int)lst["Pincode"];
//        //    //            objAuditorMaster.FirmRegNo = lst["FirmRegNo"].ToString();
//        //    //            objAuditorMaster.FirmPAN = lst["FirmPAN"].ToString();
//        //    //            objAuditorMaster.PartnerPAN = lst["PartnerPAN"].ToString();
//        //    //        }

//        //    //        connection.Close();
//        //    //        return lstAll;

//        //    //    }
//        //    //}
//        //}
//        //public async Task UpdateAuditor(int Id)
//        //{
//        //    var query = "update gst_auditormaster set DelFlag = 1 where Id = @Id";
//        //    var param = new DynamicParameters();
//        //    param.Add("Id", Id, DbType.Int32);
//        //    // param.Add("DelFlag", Auditor.DelFlag, DbType.String);
//        //    using (IDbConnection con = new MySqlConnector.MySqlConnection(connectionstring))
//        //    {
//        //        await con.ExecuteAsync(query, param);
//        //    }
//        //}        //public async Task<IEnumerable<gst_auditormaster>> GetAuditor()
//        //{
//        //    using (IDbConnection con = new MySqlConnector.MySqlConnection(connectionstring))
//        //    {
//        //        string query = "select Id,FirmName,PartnerName from gst_auditormaster";
//        //        con.Open();
//        //        var result = await con.QueryAsync<gst_auditormaster>(query);
//        //        con.Close();
//        //        return result.ToList();
//        //    }
//        //}
//    }
//}
